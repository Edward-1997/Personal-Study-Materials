package com.tang.demo3.config.salt.config;

import org.apache.commons.collections.map.LRUMap;
import org.apache.http.client.config.CookieSpecs;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.nio.client.CloseableHttpAsyncClient;
import org.apache.http.impl.nio.client.HttpAsyncClientBuilder;
import org.apache.http.impl.nio.client.HttpAsyncClients;
import org.apache.http.impl.nio.conn.PoolingNHttpClientConnectionManager;
import org.apache.http.impl.nio.reactor.DefaultConnectingIOReactor;
import org.apache.http.nio.conn.NoopIOSessionStrategy;
import org.apache.http.nio.conn.SchemeIOSessionStrategy;
import org.apache.http.nio.conn.ssl.SSLIOSessionStrategy;
import org.apache.http.nio.reactor.ConnectingIOReactor;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.stereotype.Component;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.security.cert.X509Certificate;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2021/3/26 21:02
 **/
@Component
public class HttpFactory implements FactoryBean<CloseableHttpAsyncClient> {

    @Override
    public CloseableHttpAsyncClient getObject() throws Exception {
        SSLContext ctx = SSLContext.getInstance("TLS");

        TrustManager[] trustAllCerts = new TrustManager[]{
                new X509TrustManager() {
                    public X509Certificate[] getAcceptedIssuers() {
                        return null;
                    }
                    public void checkClientTrusted(X509Certificate[] certs, String authType) {
                        // don't check
                    }
                    public void checkServerTrusted(X509Certificate[] certs, String authType) {
                        // don't check
                    }
                }
        };


        ctx.init(null, trustAllCerts, null);
        SSLIOSessionStrategy sslioSessionStrategy = new SSLIOSessionStrategy(ctx, SSLIOSessionStrategy.ALLOW_ALL_HOSTNAME_VERIFIER);
        Registry<SchemeIOSessionStrategy> registry = RegistryBuilder.<SchemeIOSessionStrategy>create()
                .register("http", NoopIOSessionStrategy.INSTANCE)
                .register("https", sslioSessionStrategy)
                .build();

        ConnectingIOReactor ioReactor = new DefaultConnectingIOReactor();
        PoolingNHttpClientConnectionManager pool = new PoolingNHttpClientConnectionManager(ioReactor,registry);
        pool.setMaxTotal(100); // 设置最多连接数
        pool.setDefaultMaxPerRoute(20); // 设置每个host最多20个连接数
        RequestConfig requestConfig = RequestConfig.custom()
                .setConnectionRequestTimeout(0)
                .setConnectTimeout(10000)
                .setSocketTimeout(20000)
                .setCookieSpec(CookieSpecs.STANDARD)
                .build();

        CloseableHttpAsyncClient client = HttpAsyncClients.custom().setConnectionManager(pool) // 设置连接池
                .setDefaultRequestConfig(requestConfig) // 设置请求配置
                .build();

        client.start();
        return client;
    }

    @Override
    public Class<?> getObjectType() {
        return null;
    }

}
