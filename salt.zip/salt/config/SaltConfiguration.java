package com.tang.demo3.config.salt.config;

import com.tang.demo3.config.salt.model.SaltProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2021/3/27 21:46
 **/
@Configuration
@EnableConfigurationProperties(SaltProperties.class)
public class SaltConfiguration {
}
