package com.tang.demo3.config.salt.cache;

import com.tang.demo3.config.salt.model.SaltClientInfo;
import com.tang.demo3.config.salt.model.SaltProperties;
import com.tang.demo3.config.salt.service.SaltDataService;
import org.apache.commons.collections.map.LRUMap;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Random;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2021/3/26 21:08
 **/
@Component
public class SaltClientHolder implements InitializingBean {
    @Autowired
    private SaltDataService saltDataService;

    @Autowired
    private SaltProperties properties;

    private LRUMap map;

    private ReentrantReadWriteLock readWriteLock = new ReentrantReadWriteLock();

    private ReentrantReadWriteLock.ReadLock readLock = readWriteLock.readLock();

    private ReentrantReadWriteLock.WriteLock writeLock = readWriteLock.writeLock();

    public SaltClientInfo get(String identify) throws Exception {
        readLock.lock();
        SaltClientInfo o;
        try{
            o = (SaltClientInfo)map.get(identify);
        } finally {
            readLock.unlock();
        }
        if (o == null){
             o = saltDataService.findByUrl(identify);
            if (o == null){
                throw new Exception();
            }
            put(o);
        }
        return o;
    }

    public void put(SaltClientInfo client){
        writeLock.lock();
        try {
            if (!map.containsKey(client.getUrl())){
                map.put(client.getUrl(),client);
            }
        } finally {
            writeLock.unlock();
        }
    }


    @Override
    public void afterPropertiesSet() throws Exception {
        List<SaltClientInfo> clients = saltDataService.findAllSaltClient();
        int size = clients.size();
        Random random = new Random(System.currentTimeMillis());
        int threshold = (int)(properties.getLoadFactory() * size);
        map= new LRUMap(Math.max(threshold,properties.getThreshold()));

        clients.forEach(client->{
            if (random.nextInt(size) < threshold){
                put(client);
            }
        });
    }

}
