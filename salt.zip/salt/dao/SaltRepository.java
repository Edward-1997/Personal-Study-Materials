package com.tang.demo3.config.salt.dao;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2021/3/28 9:00
 **/
public class SaltRepository {
}
