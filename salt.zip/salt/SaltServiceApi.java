package com.tang.demo3.config.salt;

import com.tang.demo3.config.salt.cache.SaltClientHolder;
import com.tang.demo3.config.salt.model.SaltClientInfo;
import com.tang.demo3.config.salt.service.SaltDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2021/3/28 8:49
 **/

@Component
public class SaltServiceApi {

    @Autowired
    private SaltClientHolder holder;

    @Autowired
    private SaltDataService saltDataService;

    @Async
    public void async(){
        try {
            SaltClientInfo saltClientInfo = holder.get("");

        } catch (Exception e){

        }

    }

    public <R> R getResult(String jid){
        saltDataService.getResult(jid);
        return null;
    }
}
