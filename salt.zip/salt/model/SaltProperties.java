package com.tang.demo3.config.salt.model;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2021/3/27 21:45
 **/
@ConfigurationProperties("salt.")
public class SaltProperties {

    private float loadFactory = 0.9f;

    private int threshold = 20;

    public int getThreshold() {
        return threshold;
    }

    public void setThreshold(int threshold) {
        this.threshold = threshold;
    }

    public float getLoadFactory() {
        return loadFactory;
    }

    public void setLoadFactory(float loadFactory) {
        this.loadFactory = loadFactory;
    }
}
