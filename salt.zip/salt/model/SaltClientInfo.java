package com.tang.demo3.config.salt.model;

import com.suse.salt.netapi.client.SaltClient;
import com.suse.salt.netapi.datatypes.AuthMethod;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2021/3/26 22:03
 **/

public class SaltClientInfo {
    private final String url;

    private final SaltClient client;

    private final AuthMethod authMethod;

    public SaltClientInfo(String url, SaltClient client, AuthMethod authMethod) {
        this.url = url;
        this.client = client;
        this.authMethod = authMethod;
    }

    public SaltClient getClient() {
        return client;
    }

    public AuthMethod getAuthMethod() {
        return authMethod;
    }

    public String getUrl() {
        return url;
    }
}
