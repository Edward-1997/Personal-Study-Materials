package com.tang.demo3.config.salt.model;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2021/3/27 15:27
 **/
public class SaltResult<R> {
    private boolean isModify;

    private String id;

    private R result;

    private long createTime;

    private long awaitTimeout;

    private int retry = 3;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public R getResult() {
        return result;
    }

    public void setResult(R result) {
        this.result = result;
    }

    public long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(long createTime) {
        this.createTime = createTime;
    }

    public long getAwaitTimeout() {
        return awaitTimeout;
    }

    public void setAwaitTimeout(long awaitTimeout) {
        this.awaitTimeout = awaitTimeout;
        isModify = true;
    }

    public int getRetry() {
        return retry;
    }

    public void setRetry(int retry) {
        this.retry = retry;
    }

    public void decrement(){
        --retry;
        isModify = true;
    }

    public boolean isModify(){
        return isModify;
    }
}
