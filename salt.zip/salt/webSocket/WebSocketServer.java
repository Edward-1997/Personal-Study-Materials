package com.tang.demo3.config.salt.webSocket;

import org.springframework.stereotype.Component;

import javax.websocket.*;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;
import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2021/3/27 15:30
 **/
@ServerEndpoint("/websocket/{id}")
@Component
public class WebSocketServer {

    private AtomicInteger onlineNum = new AtomicInteger();

    private ConcurrentHashMap<String, Session> pool = new ConcurrentHashMap<>();

    private final Object lock = new Object();

    public void sendMessage(Session s,String msg){
        if(s == null){
            return;
        }

        if (s.isOpen()){
            try {
                s.getBasicRemote().sendText(msg);
            } catch (IOException ignored){

            } finally {
                try {
                    s.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    @OnOpen
    public void onOpen(Session s, @PathParam(value="id")String jid){
        if (!pool.containsKey(jid)){
            synchronized (lock){
                if (!pool.containsKey(jid)){
                    pool.put(jid,s);
                    onlineNum.incrementAndGet();
                    sendMessage(s, jid);
                }
            }
        }
    }

    @OnClose
    public void onClose(@PathParam(value = "jid") String jid){
        pool.remove(jid);
        onlineNum.decrementAndGet();
        System.out.println("断开webSocket连接！当前人数为" + onlineNum.get());
    }

    @OnError
    public void onError(Session session, Throwable throwable){
        throwable.printStackTrace();
    }

    public Session getSession(String jid){
        return pool.get(jid);
    }

}
