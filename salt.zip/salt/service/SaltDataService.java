package com.tang.demo3.config.salt.service;

import com.tang.demo3.config.salt.model.SaltClientInfo;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2021/3/26 22:13
 **/
@Component
public class SaltDataService {

    public SaltClientInfo findByUrl(String url){
        return null;
    }

    public List<SaltClientInfo> findAllSaltClient(){
        return null;
    }

    public void getResult(String jid){

    }
}
