package com.tang.demo3.config.salt.service;

import com.google.gson.reflect.TypeToken;
import com.suse.salt.netapi.calls.LocalCall;
import com.suse.salt.netapi.datatypes.target.MinionList;
import com.suse.salt.netapi.datatypes.target.Target;
import com.tang.demo3.config.salt.cache.SaltClientHolder;
import com.tang.demo3.config.salt.model.SaltClientInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2021/3/26 21:02
 **/
@Component
public class SaltApi {

    public CompletableFuture<Map<String,String>> execute(
            SaltClientInfo client, String func, List<String> target, List<String> arg, Map<String,?> kwarg) throws Exception {
        LocalCall<String> local = new LocalCall<>(func, Optional.ofNullable(arg),Optional.ofNullable(kwarg),new TypeToken<String>(){});
        Target<List<String>> t = new MinionList(target);
        return local.callSync(client.getClient(),t,client.getAuthMethod())
                .thenApply(map->{
                    Map<String,String> newMap = new HashMap<>();
                    map.forEach((key,value)->{
                        newMap.put(key,value.result().get());
                    });
                    return newMap;
                }).toCompletableFuture();
    }


}
