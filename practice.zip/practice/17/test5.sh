#!/bin/bash
function test {
	local newarry
	local sum=0
	newarray=( $(echo "$@") )
	echo "The new array value is ${newarray[*]}"
	for value in ${newarray[*]}
	do
		sum=$[ $sum + $value]
	done
	echo "The sum is $sum"
}

myarray=(1 2 3 4 5)
echo "The original array is ${myarray[*]}"

test ${myarray[*]}

