#!/bin/bash
function func1 {
	echo "This is an example of a funciton"
}

count=1
while [ $count -le 5 ]
do 
	func1
	count=$[ $count + 1]
done
echo "This is end of the loop"
func1
echo "Noe this is the end of the script"
