#!/bin/bash

function factorial {
	if [ $1 -eq 1 ]
	then
		echo 1
	else
		echo $[ $(factorial $[ $1 - 1 ]) * $1]
	fi
}
read -p "Enter the value:" value
echo "The value of 5! is $(factorial $value)"
