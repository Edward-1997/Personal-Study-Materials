#!/bin/bash
source ./myfuncs
result1='addem 10 20'
result2='multem 10 20'

echo "The result of adding them is: $reuslt1"
echo "The result of multiple thme is: $reuslt2"
