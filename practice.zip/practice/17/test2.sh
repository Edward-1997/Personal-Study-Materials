#!/bin/bash
function db {
	read -p "Enter a value:" value
	echo $[ $value * 2 ]
}

result=$(db)
echo "The new value is $result"
