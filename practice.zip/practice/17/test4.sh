#!/bin/bash

function test {
	echo "The parameter are : $@"
	array=$1
	echo "The received array is : ${array[*]}"
}

myarray=(3 1 3 4 5)
echo "The original array is: ${myarray[*]}"
echo "The function is starting ..."
test $myarray
