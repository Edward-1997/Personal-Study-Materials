#!/bin/bash
# test getopts command

while getopts :ab:cd opt
do
	case "$opt" in
	a) echo "Find -a the option";;
	b) echo "Find -b the option with the parameter $OPTARG";;
	c) echo "Find -c the option";;
	d) echo "Find -d the option";;
	*) echo "Unknow command $opt";;
	esac
done

shift $[ $OPTIND - 1 ]

count=1
for param in "$@"
do
	echo "Parameter #$count : $param"
	count=$[ $count + 1 ]
done
