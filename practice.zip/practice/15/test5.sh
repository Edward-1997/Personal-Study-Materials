#!/bin/bash
for param in "$*"
do
	echo "\$* is $param"
done
echo ""
for param in "$@"
do
	echo "the \$@ is $param"
done
