#!/bin/bash
# extract command line parameter with getopt

set -- $(getopt -q ab:cd "$@")
while [ -n "$1" ]
do
	case "$1" in
	-a) echo "Find the -a option";;
	-b) param="$2"
		echo "Find the -b option with the parameter is $param"
		shift;;
	-c) echo "Find the -c option";;
	--) shift
		break;;
	 *) echo "$1 is not a option";;
	esac
	shift
done
count=1
for param in "$@"
do
	echo "Parameter #$count: $param"
	count=$[ $count + 1]
done
