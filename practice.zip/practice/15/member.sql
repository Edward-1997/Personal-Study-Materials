	insert into member (last_name,first_name,address,city,state,zip) values
	('Blum','Richard','123 Main St.','Chicago','IL','60601');
	insert into member (last_name,first_name,address,city,state,zip) values
	('Blum','Barbara','123 Main St.','Chicago','IL','60601');
	insert into member (last_name,first_name,address,city,state,zip) values
	('Bresnahan','Christine','456 Oak Ave.','Columbus','OH','43201');
	insert into member (last_name,first_name,address,city,state,zip) values
	('Bresnahan','Timothy','456 Oak Ave.','Columbus','OH','43201');
