#!/bin/bash
# test read -p option

read -p "Please enter your name:" first last
echo "Your name is $last $first"
