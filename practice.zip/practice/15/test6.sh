#!/bin/bash
# test shift

counter=1
while [ -n "$1" ]
do
	echo "the counter = $counter,the parameter is $1"
	counter=$[ $counter+1 ]
	shift
done
