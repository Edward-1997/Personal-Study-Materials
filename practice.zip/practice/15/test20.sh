#!/bin/bash
outfile="member.sql"
IFS=','
while read last_name first_name address city state zip
do
	cat >> $outfile << EOF
	insert into member (last_name,first_name,address,city,state,zip) values
	('$last_name','$first_name','$address','$city','$state','$zip');
EOF
done < $1
