#!/bin/bash
# redirecting output to the different location

exec 2>testerror
echo "This is a normal output"

exec 1>testout
echo "The output will output the testout"
echo "error message" >&2
