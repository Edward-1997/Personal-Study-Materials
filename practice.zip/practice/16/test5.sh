#!/bin/bash

echo "This script ran at $(date +%B%d,%T)" > test5.out
echo >> test5.out
sleep 5
echo "This script is ending..." >> test5.out
