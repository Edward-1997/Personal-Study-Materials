package completion_queue;

import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

public class CompletionCase {
    private final int POOL_SIZE = Runtime.getRuntime().availableProcessors();
    private final int TOTAL_TASK = Runtime.getRuntime().availableProcessors()*10;

    public void testByQueue() throws InterruptedException, ExecutionException {
        long start = System.currentTimeMillis();
        AtomicInteger count = new AtomicInteger(0);

        //利用阻塞队列
        ExecutorService pool =Executors.newFixedThreadPool(POOL_SIZE);
        BlockingQueue<Future<Integer>> queue = new LinkedBlockingQueue<>();

        for(int i = 0;i<TOTAL_TASK;i++){
            WorkTask task = new WorkTask("ExecuteTask " + i);
            Future<Integer> future = pool.submit(task);
            queue.add(future);
        }

        for(int i = 0;i < TOTAL_TASK;i++){
            Integer integer = queue.take().get();
            System.out.println("task sleep :"+integer+"...");
            count.addAndGet(integer);
        }
        pool.shutdown();
        System.out.println("task total time :"+count.get()+"\ttask execute time :"+(System.currentTimeMillis()-start));
    }

    public void testByCompletion() throws InterruptedException, ExecutionException {
        long start = System.currentTimeMillis();
        AtomicInteger count = new AtomicInteger(0);

        ExecutorService pool =Executors.newFixedThreadPool(POOL_SIZE);
        CompletionService<Integer> service = new ExecutorCompletionService<>(pool);

        for(int i = 0;i<TOTAL_TASK;i++){
            service.submit(new WorkTask("ExecuteTask " + i));
        }

        for(int i = 0;i < TOTAL_TASK;i++){
            Integer integer = service.take().get();
            System.out.println("task sleep :"+integer+"...");
            count.addAndGet(integer);
        }

        pool.shutdown();
        System.out.println("task total time :"+count.get()+"\ttask execute time :"+(System.currentTimeMillis()-start));
    }

    public static void main(String[] args) {
        CompletionCase completionCase =new CompletionCase();
        try {
                completionCase.testByQueue();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
    }

}
