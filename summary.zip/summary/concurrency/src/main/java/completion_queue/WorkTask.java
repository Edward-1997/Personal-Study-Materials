package completion_queue;

import java.util.Random;
import java.util.concurrent.Callable;

public class WorkTask implements Callable<Integer> {
    private final String name;

    public WorkTask(String name){
        this.name = name;
    }


    @Override
    public Integer call() throws Exception {
        int sleepTime = new Random().nextInt(1000);
        Thread.sleep(sleepTime);
        return sleepTime;
    }
}
