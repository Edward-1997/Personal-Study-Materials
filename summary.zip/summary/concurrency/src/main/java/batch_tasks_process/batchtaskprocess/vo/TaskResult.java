package batch_tasks_process.batchtaskprocess.vo;

//类说明：对任务执行后的返回结果进行封装
public class TaskResult<R> {
    private final TaskResultType taskResultType;
    private final R returnValue;
    private final String reason;

    public TaskResult(TaskResultType taskResultType, R returnValue) {
        this(taskResultType,returnValue,"Success");
    }

    public TaskResult(TaskResultType taskResultType, R returnValue, String reason) {
        this.taskResultType = taskResultType;
        this.returnValue = returnValue;
        this.reason = reason;
    }

    public TaskResultType getTaskResultType() {
        return taskResultType;
    }

    public R getReturnValue() {
        return returnValue;
    }

    public String getReason() {
        return reason;
    }

    @Override
    public String toString() {
        return "TaskResult{" +
                "taskResultType=" + taskResultType +
                ", returnValue=" + returnValue +
                ", reason='" + reason + '\'' +
                '}';
    }
}
