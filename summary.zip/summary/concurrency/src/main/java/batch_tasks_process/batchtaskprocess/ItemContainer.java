package batch_tasks_process.batchtaskprocess;

import java.util.concurrent.Delayed;
import java.util.concurrent.TimeUnit;

public class ItemContainer<T> implements Delayed {
    //在延时队列里活跃的时长，单位为ms
    private long activeTime;

    private T data;

    public ItemContainer(long activeTime, T data) {
        //将传入的过期时长转换为ns，并加上当前的时长
        this.activeTime = TimeUnit.NANOSECONDS.convert(activeTime,TimeUnit.MILLISECONDS)+System.nanoTime();
        this.data = data;
    }

    public long getActiveTime() {
        return activeTime;
    }

    public T getData() {
        return data;
    }

    //返回元素的剩余时间,单位为ns
    @Override
    public long getDelay(TimeUnit unit) {
        return unit.convert(this.activeTime-System.nanoTime(),TimeUnit.NANOSECONDS);
    }

    //按照剩余时间进行排序
    @Override
    public int compareTo(Delayed o) {
        long d = getDelay(TimeUnit.NANOSECONDS)-o.getDelay(TimeUnit.NANOSECONDS);
        return (d == 0)?0:(d>0?1:-1);
    }
}
