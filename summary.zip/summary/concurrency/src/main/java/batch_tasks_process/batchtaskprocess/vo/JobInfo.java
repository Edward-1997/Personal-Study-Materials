package batch_tasks_process.batchtaskprocess.vo;


import batch_tasks_process.ITaskProcessors;
import batch_tasks_process.batchtaskprocess.CheckJobProcessor;

import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.atomic.AtomicInteger;

public class JobInfo<R> {
    //工作名称
    private final String jobName;
    //工作的任务个数
    private final int jobLength;
    //这个工作的任务处理器
    private final ITaskProcessors<?,?> iTaskProcessors;
    //过期时间
    private final long expireTime;
    //处理成功的任务数
    private AtomicInteger successCount;
    //已处理的任务数
    private AtomicInteger taskProcessorCount;
    //结果队列：从队列头拿结果，放结果从尾部放
    private LinkedBlockingDeque<TaskResult<R>> queue;


    public JobInfo(String jobName,int jobLength, ITaskProcessors<?, ?> iTaskProcessors, long expireTime) {
        this.jobName = jobName;
        this.iTaskProcessors = iTaskProcessors;
        this.expireTime = expireTime;
        this.jobLength = jobLength;

        this.queue = new LinkedBlockingDeque<>(this.jobLength);
        this.successCount = new AtomicInteger(0);
        this.taskProcessorCount = new AtomicInteger(0);
    }

    public ITaskProcessors<?, ?> getTaskProcessors() {
        return this.iTaskProcessors;
    }

    //返回jobName
    public String getJobName(){return this.jobName;};
    //返回任务成功执行的个数
    public int getSuccessCount() {
        return successCount.get();
    }
    //返回已处理的任务个数
    public int getTaskProcessorCount() {
        return taskProcessorCount.get();
    }
    //返回任务失败执行的个数
    public int getFailureCount(){
        return taskProcessorCount.get()-successCount.get();
    }

    public String getTotalProcess(){
        return "Success task:["+getSuccessCount()+"]\t"+
                "Failure task["+getFailureCount()+"]\t"+
                "Total process task["+getTaskProcessorCount()+"]\t"+
                "完成进度：【"+(getTaskProcessorCount()*100/jobLength)+"%】";
    }

    public List<TaskResult<R>> getTaskList(){
        List<TaskResult<R>> taskList = new LinkedList<>();
        TaskResult<R> taskResult;
        while((taskResult = this.queue.pollFirst()) != null){
            taskList.add(taskResult);
        }
        return taskList;
    }

    public void addTaskResult(TaskResult<R> taskResult, CheckJobProcessor checkJobProcessor){
        if(TaskResultType.Success.equals(taskResult.getTaskResultType())){
            successCount.incrementAndGet();
        }
        taskProcessorCount.incrementAndGet();
        queue.addLast(taskResult);

        if(getTaskProcessorCount() == jobLength){
            System.out.println(getTaskProcessorCount());
            System.out.println(jobLength);
            checkJobProcessor.putJob(this.jobName,this.expireTime);
        }
    }
}
