package batch_tasks_process.batchtaskprocess;


import batch_tasks_process.ITaskProcessors;
import batch_tasks_process.batchtaskprocess.vo.JobInfo;
import batch_tasks_process.batchtaskprocess.vo.TaskResult;
import batch_tasks_process.batchtaskprocess.vo.TaskResultType;

import java.util.List;
import java.util.concurrent.*;

public class PendingJobPool {
    //任务队列，采用ArrayBlockingQueue有界队列
    private static BlockingQueue<Runnable> taskQueue = new ArrayBlockingQueue<>(5000);
    //线程个数=CPU核心数*4
    private final static int THREAD_COUNT = Runtime.getRuntime().availableProcessors()*4;
    //自定义线程池，固定大小，有界队列，默认采用AbortPolicy(队列满就抛出异常)
    private static ExecutorService pool = new ThreadPoolExecutor(THREAD_COUNT,THREAD_COUNT,60, TimeUnit.SECONDS,taskQueue);
    //缓存每个jobInfo的context
    private static ConcurrentHashMap<String, JobInfo<?>> jobInfoMap = new ConcurrentHashMap<>();
    //缓存处理完成的任务一段时间，以供业务人员查询
    private static CheckJobProcessor jobProcessor = CheckJobProcessor.getInstance();

    //单例模式创建线程池，保证业务人员可以拿到同一个线程池
    private PendingJobPool(){}

    private static class PendingHolder{
        public static PendingJobPool pool = new PendingJobPool();
    }

    public static PendingJobPool getInstance(){
        return PendingHolder.pool;
    }

    public static void removeTask(String jobName){
        if(jobInfoMap.remove(jobName) == null){
            throw new RuntimeException(jobName+"不存在");
        }
    }

    //检索并返回缓存中的jobInfo
    public <R> JobInfo<R> getJob(String jobName){
        JobInfo<R> jobInfo = (JobInfo<R>) jobInfoMap.get(jobName);
        if(null == jobInfo){
            throw new RuntimeException(jobName+"");
        }
        return jobInfo;
    }

    //将任务放到pool并执行
    public <T,R> void putTask(String jobName,T task){
        JobInfo<R> jobInfo = getJob(jobName);
        PendingTask<T,R> pendingTask = new PendingTask<>(jobInfo,task);
        pool.execute(pendingTask);
    }

    //创建jobInfo并将其注册到缓存中
    public <R> void registerJobInfo(String jobName, int jobLength, ITaskProcessors<?, ?> iTaskProcessors, long expireTime){
        JobInfo<R> jobInfo = new JobInfo<>(jobName,jobLength,iTaskProcessors,expireTime);

        //如果map没有jobInfo就put，如果有则会返回先前的，然后put覆盖，则报错
        if(jobInfoMap.putIfAbsent(jobName, jobInfo) != null){
            throw new RuntimeException(jobName+"已注册!");
        }
    }

    //获取任务详细结果
    public <R> List<TaskResult<R>> getTaskDetail(String jobName){
        JobInfo<R> jobInfo = getJob(jobName);
     return jobInfo.getTaskList();
    }

    //获取任务处理结果
    public String getTotalProcess(String jobName){
        return getJob(jobName).getTotalProcess();
    }

    //对工作中的任务进行包装，提交给线程池使用
    private static class PendingTask<T,R> implements Runnable{
        private JobInfo<R> jobInfo;
        private T processData;

        public PendingTask(JobInfo<R> jobInfo, T processData) {
            this.jobInfo = jobInfo;
            this.processData = processData;
        }

        @Override
        public void run() {
            ITaskProcessors<T, R> taskProcessors = (ITaskProcessors<T, R>) jobInfo.getTaskProcessors();

            TaskResult<R> result = null ;
            try{
                result= taskProcessors.taskExecute(processData);
                //校验：当result,returnValue,reason 为null时，则认为业务执行失败
                if(result == null){
                    throw new Exception("result is null");
                }

                if(result.getReturnValue() == null){
                    if(result.getReason() == null || "".equals(result.getReason())){
                        throw new Exception("reason and returnValue are null");
                    }else{
                        throw new Exception("resultValue is null but reason is"+result.getReason());
                    }
                }
            }catch (Exception e){
                e.printStackTrace();
                result = new TaskResult<R>(TaskResultType.Exception,null,e.getMessage());
            }finally {
                jobInfo.addTaskResult(result,jobProcessor);
            }
        }
    }
}
