package batch_tasks_process.batchtaskprocess.vo;

public enum TaskResultType {
    //方法执行成功并返回业务人员需要的结果
    Success,
    //方法成功执行但是返回的是业务人员不需要的结果
    Failure,
    //方法执行抛出了异常
    Exception;
}
