package batch_tasks_process.batchtaskprocess;

import java.util.concurrent.DelayQueue;

public class CheckJobProcessor {
    private static DelayQueue<ItemContainer<String>> delayQueue = new DelayQueue<>();

    //单例模式
    private CheckJobProcessor(){}

    private static class CheckJobProcessorHolder{
        private static CheckJobProcessor getInstance = new CheckJobProcessor();
    }

    public static CheckJobProcessor getInstance(){
        return CheckJobProcessorHolder.getInstance;
    }

    //处理任务队列中到期任务的线程
    public static class FetchTask implements Runnable{

        @Override
        public void run() {
            while(true){
                try {
                    //获取已经过期的任务
                    ItemContainer<String> item = delayQueue.take();
                    String jobName = (String)item.getData();
                    PendingJobPool.removeTask(jobName);
                    System.out.println("过期任务：["+jobName+"]已经移出任务队列");
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void putJob(String jobName , long expireTime){
        ItemContainer<String> item = new ItemContainer<>(expireTime,jobName);
        if(delayQueue.offer(item)){
            System.out.println("job:["+jobName+"]已经放入队列中");
        }
    }

    static {
        Thread thread = new Thread(new FetchTask());
        thread.setDaemon(true);
        thread.start();
    }

}
