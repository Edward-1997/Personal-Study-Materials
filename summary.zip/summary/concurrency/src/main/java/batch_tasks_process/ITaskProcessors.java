package batch_tasks_process;

import batch_tasks_process.batchtaskprocess.vo.TaskResult;

public interface ITaskProcessors<T,R> {
    TaskResult<R> taskExecute(T data);
}
