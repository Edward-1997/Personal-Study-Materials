package customize_threadpool;

public class Test {
    public static void main(String[] args) {
        for(Thread thread : Thread.getAllStackTraces().keySet()){
            System.out.println("Thread Name :"+thread.getName());
        }
        System.out.println(Runtime.getRuntime().availableProcessors());
        System.out.println(Runtime.getRuntime().totalMemory()/1024/1024);
        System.out.println(Runtime.getRuntime().maxMemory()/1024/1024);
        System.out.println(Runtime.getRuntime().freeMemory()/1024/1024);
    }
}
