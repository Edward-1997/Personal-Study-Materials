package customize_threadpool;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Executor;

public class ThreadPool implements Executor {
    //线程中默认任务个数为5
    private static int WORK_NUM = 5;
    //队列默认任务个数为100
    private static int TASK_COUNT = 100;
    //工作线程组
    private WorkThread[] workThreads;

    //任务队列，作为一个缓冲
    private final BlockingQueue<Runnable> TASK_QUEUE;
    private final int WORKER_NUM;

    public ThreadPool(){
        this(WORK_NUM,TASK_COUNT);
    }

    public ThreadPool(int workerNum,int taskCount) {
        if(workerNum<=0)
            workerNum = WORK_NUM;
        if(taskCount<=0)
            taskCount = TASK_COUNT;
        this.WORKER_NUM = workerNum;
        this.TASK_QUEUE = new ArrayBlockingQueue<>(taskCount);

        this.workThreads = new WorkThread[WORKER_NUM];
        for(int i = 0;i<workThreads.length;i++){
            workThreads[i] = new WorkThread();
            workThreads[i].start();
        }
    }

    @Override
    public void execute(Runnable command) {
        try {
            this.TASK_QUEUE.put(command);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    //销毁线程池
    public void destroy(){
        System.out.println("ready close pool ...");
        //销毁工作线程
        for(int i = 0;i<workThreads.length;i++){
            workThreads[i].tryInterrupted();
            workThreads[i] = null;
        }

        //清空任务队列
        TASK_QUEUE.clear();
    }

    //打印工作线程信息，即当前任务队列大小
    @Override
    public String toString() {
        return "WorkThread number is"+WORKER_NUM+"WaitQueue thread number is"+this.TASK_QUEUE.size();
    }

    //内部类：工作线程
    public class WorkThread extends Thread{
        @Override
        public void run() {
            Runnable r = null;
            try {
                while(!isInterrupted()){
                        //该方法为阻塞方法。一旦队列有线程加入就执行
                        r = TASK_QUEUE.take();
                        if(r != null){
                            System.out.println("ready execute"+r);
                            r.run();
                        }
                        r= null;
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        public void tryInterrupted(){
            interrupt();
        }
    }
}
