package delay_container;

import java.util.concurrent.DelayQueue;


public class Test {


    public static void main(String[] args) {
        DelayQueue<ItemContainer<Order>> queue = new DelayQueue<>();
        new Thread(new PutOrder(queue)).start();
        new Thread(new GetOrder(queue)).start();

        for(int i = 0;i<10;i++){
            System.out.println(i*1000+"ms");
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
