package delay_container;

public class Order {
    //订单的编号
    private final String id;
    //订单的价格
    private final Integer price;

    public Order(String id, Integer price) {
        this.id = id;
        this.price = price;
    }

    public String getId() {
        return id;
    }

    public Integer getPrice() {
        return price;
    }

}
