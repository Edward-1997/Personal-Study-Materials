package delay_container;

import java.util.concurrent.DelayQueue;

public class GetOrder implements Runnable {
    private DelayQueue<ItemContainer<Order>> queue;

    public GetOrder(DelayQueue<ItemContainer<Order>> queue) {
        this.queue = queue;
    }

    @Override
    public void run() {
        while(true){
            try {
                ItemContainer<Order> item = queue.take();
                Order data = item.getData();
                System.out.println("get from queue:"+data.getId());
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
