package delay_container;

import java.util.concurrent.DelayQueue;

public class PutOrder implements Runnable {
    private DelayQueue<ItemContainer<Order>> queue;

    public PutOrder(DelayQueue<ItemContainer<Order>> queue) {
        this.queue = queue;
    }

    @Override
    public void run() {
        //2s到期
        Order orderTb = new Order("tang123",123);
        ItemContainer<Order> containerTb = new ItemContainer<>(2000,orderTb);
        queue.offer(containerTb);
        System.out.println("订单2秒后刷新"+orderTb.getId());

        //3s到期
        Order orderJd = new Order("jd1234",555);
        ItemContainer<Order> containerJd = new ItemContainer<>(3000,orderJd);
        queue.offer(containerJd);
        System.out.println("订单3秒后刷新"+orderJd.getId());
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
