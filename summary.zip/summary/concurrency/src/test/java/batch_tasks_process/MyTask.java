package batch_tasks_process;

import batch_tasks_process.ITaskProcessors;
import batch_tasks_process.batchtaskprocess.vo.TaskResult;
import batch_tasks_process.batchtaskprocess.vo.TaskResultType;

import java.util.Random;

/**
 *类说明：一个实际任务类，将数值加上一个随机数，并休眠随机时间
 */
public class MyTask implements ITaskProcessors<Integer,Integer> {

	@Override
	public TaskResult<Integer> taskExecute(Integer data) {
		Random r = new Random();
		int flag = r.nextInt(500);
		try {
			Thread.sleep(flag);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		if(flag<=400) {//正常处理的情况
			Integer returnValue = data.intValue()+flag;
			return new TaskResult<Integer>(TaskResultType.Success,returnValue);
		}else if(flag>401&&flag<=450) {//处理失败的情况
			return new TaskResult<Integer>(TaskResultType.Failure,-1,"Failure");
		}else {//发生异常的情况
			try {
				throw new RuntimeException("异常发生了！！");
			} catch (Exception e) {
				return new TaskResult<Integer>(TaskResultType.Exception,
						-1,e.getMessage());
			}
		}
	}

}
