package batch_tasks_process;

import batch_tasks_process.batchtaskprocess.PendingJobPool;
import batch_tasks_process.batchtaskprocess.vo.TaskResult;
import org.junit.Test;

import java.util.List;
import java.util.Random;

/**
 *
 *类说明：模拟一个应用程序，提交工作和任务，并查询任务进度
 */
public class AppTest {
	private final static String JOB_NAME = "计算数值";
	private final static int JOB_LENGTH = 1000;
	
	//查询任务进度的线程
	private static class QueryResult implements Runnable{
		private PendingJobPool pool;
		public QueryResult(PendingJobPool pool) {
			this.pool = pool;
		}

		@Override
		public void run() {
			int i=0;//查询次数
			while(i<350) {
				List<TaskResult<String>> taskDetail = pool.getTaskDetail(JOB_NAME);
				if(!taskDetail.isEmpty()) {
					System.out.println(pool.getTotalProcess(JOB_NAME));
					System.out.println(taskDetail);					
				}
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				i++;
			}
		}
		
	}

	@Test
	public void test() {
		MyTask myTask = new MyTask();
		//拿到框架的实例
		PendingJobPool pool = PendingJobPool.getInstance();
		//注册job
		pool.registerJobInfo(JOB_NAME, JOB_LENGTH, myTask,1000*5);
		Random r = new Random();
		long time1 = System.currentTimeMillis();
		for(int i=0;i<JOB_LENGTH;i++) {
			//依次推入Task
			pool.putTask(JOB_NAME, r.nextInt(1000));
		}
		System.out.println("pool 执行时间："+(System.currentTimeMillis()-time1));
		Thread t = new Thread(new QueryResult(pool));
		t.start();
		try {
			t.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
