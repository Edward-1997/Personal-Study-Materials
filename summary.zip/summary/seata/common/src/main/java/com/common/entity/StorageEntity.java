package com.common.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2021/4/24 19:04
 **/
@TableName("tab_storage")
@Data
public class StorageEntity {
    @TableId(type = IdType.ASSIGN_ID)
    private Long id;
    @TableField("product_id")
    private Long productId;

    private Integer total;

    private Integer used;

}
