package com.common.entity;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2021/4/21 8:03
 **/

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.math.BigDecimal;

@TableName("tab_order")
@Data
public class OrderEntity {
    @TableId(type=IdType.ASSIGN_ID)
    Long id;
    @TableField("user_id")
    Long userId;

    @TableField("product_id")
    Long productId;

    @TableField("count")
    Integer count;

    @TableField("money")
    BigDecimal money;

    @TableField("status")
    Integer status;
}
