package com.tang.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.common.entity.OrderEntity;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2021/4/24 18:26
 **/
@Mapper
public interface OrderMapper extends BaseMapper<OrderEntity> {

}
