package com.tang.service;

import com.common.entity.OrderEntity;
import com.tang.mapper.OrderMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2021/4/24 18:26
 **/
@Service
public class OrderService {
    @Autowired
    private OrderMapper orderMapper;

    public int createOrder(OrderEntity entity){
        int insert = orderMapper.insert(entity);
        return insert;
    }
}
