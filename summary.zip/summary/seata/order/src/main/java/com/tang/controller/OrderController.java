package com.tang.controller;

import com.common.entity.OrderEntity;
import com.tang.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2021/4/24 18:25
 **/
@RestController
public class OrderController {

    @Autowired
    private OrderService orderService;

    @PostMapping("/order")
    public int createOrder(@RequestBody OrderEntity entity){
        return orderService.createOrder(entity);
    }
}
