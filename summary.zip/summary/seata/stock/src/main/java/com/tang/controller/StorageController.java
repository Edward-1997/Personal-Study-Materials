package com.tang.controller;

import com.common.entity.StorageEntity;
import com.tang.service.StorageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2021/4/24 19:07
 **/
@RestController
public class StorageController {
    @Autowired
    private StorageService storageService;

    @PostMapping("/storage")
    public int createStorage(@RequestBody StorageEntity entity){
        return storageService.createStorage(entity);
    }
}
