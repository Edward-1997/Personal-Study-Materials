package com.tang.service;

import com.common.entity.StorageEntity;
import com.tang.mapper.StorageMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2021/4/24 19:11
 **/
@Service
public class StorageService {
    @Autowired
    private StorageMapper storageMapper;

    public int createStorage(StorageEntity entity){
        int insert = storageMapper.insert(entity);
        return insert;
    }
}
