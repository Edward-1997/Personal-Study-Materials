package com.tang.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.common.entity.StorageEntity;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2021/4/24 19:11
 **/
@Mapper
public interface StorageMapper extends BaseMapper<StorageEntity> {
}
