package com.tang.service;


import com.common.entity.StorageEntity;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2021/4/24 21:46
 **/
@FeignClient(name = "storage-service")
@Component
public interface StorageServiceClient {
    @PostMapping("/storage")
    int createStorage(@RequestBody StorageEntity e);
}
