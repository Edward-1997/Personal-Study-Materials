package com.tang.service;

import com.common.entity.OrderEntity;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
@Component
@FeignClient(name = "order-service")
public interface OrderServiceClient {
    @PostMapping("/order")
    int createOrder(@RequestBody OrderEntity e);
}
