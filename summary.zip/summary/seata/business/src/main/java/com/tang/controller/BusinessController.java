package com.tang.controller;

import com.common.entity.OrderEntity;
import com.common.entity.StorageEntity;
import com.tang.service.OrderServiceClient;
import com.tang.service.StorageServiceClient;
import io.seata.spring.annotation.GlobalTransactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2021/4/24 21:47
 **/
@RestController
public class BusinessController {

    @Autowired
    private OrderServiceClient orderServiceClient;

    @Autowired
    private StorageServiceClient storageServiceClient;
    @PostMapping("/business")
    @GlobalTransactional
    public String createBusiness(){
        OrderEntity e = new OrderEntity();
        e.setUserId(1L);
        e.setProductId(10L);
        orderServiceClient.createOrder(e);
        StorageEntity storageEntity = new StorageEntity();
        storageEntity.setProductId(10L);
        storageEntity.setUsed(10);
        storageServiceClient.createStorage(storageEntity);
        return "ok";
    }
}
