package servlet_unit_test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/7/28 21:16
 **/


@SpringBootTest
public class ServletApplicationTest {
    @Test
    void contextLoads() {
    }
}
