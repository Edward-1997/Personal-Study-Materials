package servlet_unit_test.unit_test;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/7/28 20:16
 **/
@RestController
public class DemoController {

    @GetMapping("/hello")
    public String sayHello() {
        return "hello world";
    }

}
