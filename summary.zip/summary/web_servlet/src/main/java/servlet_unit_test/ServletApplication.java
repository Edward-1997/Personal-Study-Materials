package servlet_unit_test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/7/28 21:14
 **/
@SpringBootApplication
public class ServletApplication {
    public static void main(String[] args) {
        SpringApplication.run(ServletApplication.class);
    }
}
