package com.consumer;

import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.common.PartitionInfo;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.serialization.StringDeserializer;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.*;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2021/4/18 9:05
 **/
public class ConsumerSample {
    public static void main(String[] args) {
        consumer();
    }

    private static void consumer() {
        Properties properties = new Properties();

        properties.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "192.168.3.120:9092");
        properties.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        properties.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        properties.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");
        properties.put(ConsumerConfig.GROUP_ID_CONFIG, "1");

        KafkaConsumer<String, String> consumer = new KafkaConsumer<String, String>(properties);

        List<TopicPartition> topicPartitions = new ArrayList<>();
        List<PartitionInfo> partitionInfo = consumer.partitionsFor("order");
        for (PartitionInfo info : partitionInfo) {
            topicPartitions.add(new TopicPartition(info.topic(), info.partition()));
        }
        consumer.assign(topicPartitions);
        consumer.seekToBeginning(topicPartitions);

        ConsumerRecords<String, String> poll = consumer.poll(Duration.ofSeconds(10));

        topicPartitions.forEach(p -> {

            List<ConsumerRecord<String, String>> records = poll.records(p);
            records.forEach(r -> {
                System.out.println("topic: " + r.topic() + " key: " + r.key() + " value: " + r.value() + " offset: " + r.offset() + " date:" + new Date(r.timestamp()).toLocaleString());
            });
//            long lastConsumerOffset = records.get(records.size() - 1).offset();
//            consumer.commitSync(Collections.singletonMap(p,new OffsetAndMetadata(lastConsumerOffset+1)));
        });
    }

    // 使用subscribe 设置seek方法
    public void subscribeModel(KafkaConsumer<String, String> consumer) {
        consumer.subscribe(Collections.singletonList("order"));
        Set<TopicPartition> assignment = consumer.assignment();
        while (assignment.size() == 0) {
            consumer.poll(Duration.ofSeconds(5));
            assignment = consumer.assignment();
        }

        for (TopicPartition tp : assignment) {
            consumer.seek(tp, 30);
        }
    }
}
