package com.timer;

import sun.misc.Unsafe;

import java.lang.reflect.Field;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2021/4/24 22:09
 **/
public class TimerWheel {

    private static TimerWheel instance;

    private final TimerTaskList[] wheel = new TimerTaskList[20];

    private final DelayQueue<TimerTaskList> delayQueue = new DelayQueue<>();

    public static void main(String[] args) throws NoSuchFieldException, IllegalAccessException {
        Field f = Unsafe.class.getDeclaredField("theUnsafe");
        f.setAccessible(true);
        Unsafe unsafe = (Unsafe) f.get(null);
        System.out.println(unsafe.);
    }

    private TimerWheel(){
        ConcurrentHashMap map = new ConcurrentHashMap();
//        U.getObjectVolatile();
//        map.put();
    }


    public static TimerWheel getInstance(){
        if (instance == null){
            synchronized (TimerWheel.class){
                if (instance == null){
                    instance = new TimerWheel();
                }
            }
        }
        return instance;
    }


    private void start() throws InterruptedException {
        for (;;){
            TimerTaskList t;
            if ((t = delayQueue.take()).isEmpty()){
                break;
            } else {
                synchronized (t){
                    t.schedule();
                }
            }
        }
    }

    private class TimerTaskList  implements Delayed {
        private volatile long currentTime;

        private final long expirationTime;

        private AtomicInteger len = new AtomicInteger(0);

        private final Node dummy = new Node();

        private final Node tail = new Node();

        private ExecutorService pool = Executors.newFixedThreadPool(4);

        public TimerTaskList(long currentTime,long expiareTime){
            this.currentTime = currentTime;
            this.expirationTime = expiareTime;
            tail.next = dummy;
        }

        public void setCurrentTime(long currentTime){
            this.currentTime = currentTime;
        }

        public void schedule(){
            Node n= dummy;
            while ((n = n.next) != null){
                pool.execute(n.task);
                n = n.next;
            }
        }

        public void addTail(TimerTask t){
            Node n = new Node(t);
            Node curTail = tail.next;
            curTail.next = n;
            tail.next = n;
        }

        public int getSize(){
            return len.get();
        }

        public boolean isEmpty(){
            return getSize() == 0;
        }

        @Override
        public long getDelay(TimeUnit unit) {
            return 0;
        }

        @Override
        public int compareTo(Delayed o) {
            return 0;
        }

        private class Node <T extends TimerTask>{
            private Node next;
            private T task;

            public Node(){};

            public Node(T task){
                this.task = task;
            }

            public T getTask(){
                return task;
            }
        }
    }
}
