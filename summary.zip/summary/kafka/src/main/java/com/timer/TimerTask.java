package com.timer;

import java.util.UUID;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2021/4/24 22:27
 **/
public abstract class TimerTask implements Runnable {
    String TASK_TOKEN = UUID.randomUUID().toString();
}
