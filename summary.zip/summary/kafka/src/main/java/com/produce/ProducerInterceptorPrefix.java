package com.produce;

import org.apache.kafka.clients.producer.ProducerInterceptor;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;

import java.util.Map;

/**
 * 自定义拦截器，对kafka发送的消息以及发送后响应的消息进行处理
 * @author tanglong
 * @version 1.0
 * @since 2020/8/11 21:49
 **/
public class ProducerInterceptorPrefix implements ProducerInterceptor<String,String> {
    private long success = 0;
    private long failure = 0;

    @Override
    public ProducerRecord<String, String> onSend(ProducerRecord<String, String> record) {
        String modifiedValue = "prefix-" + record.value();
        return new ProducerRecord<>(record.topic(), record.partition(), record.timestamp(), record.key(), modifiedValue, record.headers());
    }

    @Override
    public void onAcknowledgement(RecordMetadata metadata, Exception exception) {
        if (exception == null)
            success++;
        else
            failure++;
    }

    @Override
    public void close() {
        double successPercent = (double) success*100 / (success + failure);
        System.out.printf("%.2f",successPercent);
    }

    @Override
    public void configure(Map<String, ?> configs) {

    }
}
