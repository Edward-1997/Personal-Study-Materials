package com.produce;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import org.apache.kafka.common.serialization.Serializer;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/8/11 21:16
 **/
public class CustomSerializer<T> implements Serializer<T> {
    private String encoding = "utf-8";


    @Override
    public byte[] serialize(String topic, T data) {

        if (data == null) {
            return new byte[0];
        }else {
            String jsonStr = JSON.toJSONString(data);
            return jsonStr.getBytes();
        }
    }
}
