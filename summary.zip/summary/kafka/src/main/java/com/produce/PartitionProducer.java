package com.produce;

import org.apache.kafka.clients.producer.Partitioner;
import org.apache.kafka.common.Cluster;

import java.util.Map;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/8/10 21:37
 **/
public class PartitionProducer implements Partitioner {
    @Override
    public int partition(String topic, Object key, byte[] keyBytes, Object value, byte[] valueBytes, Cluster cluster) {
        int keyInt = Integer.parseInt(String.valueOf(key));
        return keyInt % 3;
    }

    @Override
    public void close() {

    }

    @Override
    public void configure(Map<String, ?> configs) {

    }
}
