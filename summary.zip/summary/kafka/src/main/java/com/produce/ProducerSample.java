package com.produce;

import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.KafkaException;
import org.apache.kafka.common.errors.AuthenticationException;

import java.security.KeyException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/8/10 20:26
 **/
public class ProducerSample {

    public static void main(String[] args) {
        producerSend();
    }
    public static void producerSend() {
        Properties properties = new Properties();

        properties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,"192.168.3.120:9092");
        properties.put(ProducerConfig.ACKS_CONFIG,"all");
        properties.put(ProducerConfig.RETRIES_CONFIG,"0");
        properties.put(ProducerConfig.BATCH_SIZE_CONFIG,"16384");
        properties.put(ProducerConfig.LINGER_MS_CONFIG,"1");
        properties.put(ProducerConfig.BUFFER_MEMORY_CONFIG,"33554432");
        properties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,"org.apache.kafka.common.serialization.StringSerializer");
        properties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,"org.apache.kafka.common.serialization.StringSerializer");
        //自定义分区选择器
        properties.put(ProducerConfig.PARTITIONER_CLASS_CONFIG,PartitionProducer.class.getName());

        //Producer主对象
        Producer<String,String> producer = new KafkaProducer<>(properties);
        //消息对象 -ProducerRecode
        try{
            while (true){
                for (int i = 0; i < 10; i++) {
                    ProducerRecord<String,String> record = new ProducerRecord<>("order", String.valueOf(i),"value"+i);
                    //异步回调
                    producer.send(record,(recordMetadata,e)->{
                        System.out.println("partition: "+recordMetadata.partition()+"topic:"+recordMetadata.topic());
                    });
                }
                Thread.sleep(30000);
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            producer.close(10, TimeUnit.SECONDS);
        }

//        //kafka生产者的两种模式：1、事务模式
//        producer.initTransactions();
//
//        try {
//            producer.beginTransaction();
//            producer.commitTransaction();
//        } catch (AuthenticationException | BufferExhaustedException e){
//            producer.close();
//        } catch (KafkaException e) {
//            producer.abortTransaction();
//        }



    }
}
