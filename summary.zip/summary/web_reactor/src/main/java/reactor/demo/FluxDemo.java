package reactor.demo;

import org.reactivestreams.Publisher;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Scheduler;
import reactor.core.scheduler.Schedulers;

import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/4/30 21:49
 **/
public class FluxDemo {
    public static void main(String[] args) throws InterruptedException {
        Random random = new Random();
        //订阅并且处理（控制台输出）
        Flux.just(1,2,3)
                .map(value->{
                    if(random.nextInt(6) == 3){//当随机数为3时抛出异常
                     throw new RuntimeException("出现异常");
                    }
                    return value;
                })
                .subscribe(
                        System.out::println,//onNext 数据处理
                        System.out::println,//onError 数据出现异常
                        ()->{System.out.println("订阅成功");}//数据成功订阅后打印
                        );
        System.out.println(Mono.just(1).subscribe(i-> System.out.println(i)));
        Flux.range(0,10)
                .publishOn(Schedulers.single())//异步单线程执行
                .subscribe(System.out::println);

        Flux.range(0,10)
                .publishOn(Schedulers.parallel())//异步并行执行
                .subscribe(System.out::println);

        Thread.sleep(1000);
    }
}
