package com.tang.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2021/4/13 20:40
 **/
@TableName("t_order")
@Data
public class OrderEntity {

    private Long orderId;

    private Integer count;

    private Integer prices;

    private Long userId;
}
