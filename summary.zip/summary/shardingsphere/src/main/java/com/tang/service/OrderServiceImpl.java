package com.tang.service;

import com.tang.entity.OrderEntity;
import com.tang.mapper.OrderMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2021/4/13 20:38
 **/
@Service
public class OrderServiceImpl implements OrderService {
    @Autowired
    private OrderMapper orderMapper;


    public Integer createOrder(OrderEntity entity){
        return orderMapper.createOrder(entity);
    }

    @Override
    public List<OrderEntity> queryAll() {
        return orderMapper.selectAll();
    }
}
