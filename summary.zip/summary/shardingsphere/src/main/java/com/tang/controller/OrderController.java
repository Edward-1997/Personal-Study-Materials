package com.tang.controller;

import com.tang.entity.OrderEntity;
import com.tang.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2021/4/13 20:37
 **/
@RestController
public class OrderController {

    @Autowired
    private OrderService orderService;

    @PostMapping("/order")
    public Integer createOrder(@RequestBody OrderEntity entity){
        return orderService.createOrder(entity);
    }

    @PostMapping("/batch")
    public Integer batchCreateOrder(){
        Random random = new Random();
        ExecutorService pool = Executors.newCachedThreadPool();
        for (int j = 0; j < 20; j++){
            pool.execute(()->{
                for (int i = 0; i < 10; i++){
                    OrderEntity e= new OrderEntity();
                    e.setUserId((long)random.nextInt(100000000));
                    e.setPrices(random.nextInt(1000));
                    e.setCount(random.nextInt(25));
                    orderService.createOrder(e);
                }
            });
        }

        return 1;
    }
    @GetMapping("/list")
    public List<OrderEntity> queryAll(){
        return orderService.queryAll();
    }
}
