package com.tang.mapper;

import com.tang.entity.OrderEntity;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2021/4/13 20:39
 **/
@Mapper
public interface OrderMapper {

    @Insert("insert into t_order (prices,user_id,count) values(#{prices},#{userId},#{count})")
    int createOrder(OrderEntity orderEntity);
    @Select("select * from t_order order by order_id limit 50,5")
    List<OrderEntity> selectAll();
}
