package com.tang.service;

import com.tang.entity.OrderEntity;

import java.util.List;

public interface OrderService {
    Integer createOrder(OrderEntity entity);

    List<OrderEntity> queryAll();
}
