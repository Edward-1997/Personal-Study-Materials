package com.tang.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2021/4/13 20:40
 **/
@TableName("t_order")
@Data
public class OrderEntity {
    @TableId(type = IdType.ASSIGN_ID)
    private Long orderId;

    private Integer count;

    private Integer prices;

    private Long userId;
}
