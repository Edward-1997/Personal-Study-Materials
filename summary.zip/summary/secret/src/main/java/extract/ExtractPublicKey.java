package extract;

import sun.misc.BASE64Encoder;

import java.io.FileInputStream;
import java.security.*;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/5/9 10:12
 **/
public class ExtractPublicKey {
    public static void main(String[] args) throws Exception {
        String cerPath="D:\\IDEA\\workspace\\demo2\\src\\main\\resources\\python-jwt.crt";
        String alias = "python";
        char[] password = "python".toCharArray();

        System.out.println("从证书中获取的公钥是："+getPublicKey(cerPath));
    }

    public static String getPublicKey(String cerPath) throws Exception{
        CertificateFactory certificateFactory = CertificateFactory.getInstance("X.509");
        FileInputStream fis = new FileInputStream(cerPath);
        X509Certificate cert = (X509Certificate) certificateFactory.generateCertificate(fis);
        PublicKey publicKey = cert.getPublicKey();
        String publicKeyString = new BASE64Encoder().encode(publicKey.getEncoded());

        return publicKeyString;
    }
}
