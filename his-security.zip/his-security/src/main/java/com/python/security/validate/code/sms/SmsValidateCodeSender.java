package com.python.security.validate.code.sms;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/4/29 16:00
 **/
public interface SmsValidateCodeSender {
    void send(String mobile, String smsCode);
}
