package com.python.security.validate.code.sms;


import com.python.security.core.properties.SecurityProperties;
import com.python.security.validate.code.ValidateCode;
import com.python.security.validate.code.ValidateCodeGenerator;
import org.springframework.beans.factory.annotation.Autowired;


/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/4/29 16:16
 **/
public class SmsValidateCodeGenerator implements ValidateCodeGenerator {
    @Autowired
    private SecurityProperties securityProperties;

    @Override
    public ValidateCode generate() {
        String code = (int)((Math.random()*9+1)*Math.pow(10,securityProperties.getCode().getSms().getLength()-1))+"";
        return new ValidateCode(code,securityProperties.getCode().getSms().getExpire());
    }
}
