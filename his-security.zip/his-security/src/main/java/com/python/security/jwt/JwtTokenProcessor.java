package com.python.security.jwt;

import com.python.security.core.properties.SecurityProperties;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.ServletWebRequest;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/5/5 22:33
 **/
@Component
public class JwtTokenProcessor {
    private static final Logger LOGGER = LoggerFactory.getLogger(JwtToken.class);
    @Autowired
    private SecurityProperties securityProperties;
    @Autowired
    private RedisJwtTokenRepository redisJwtTokenRepository;
    @Autowired
    private JwtTokenGenerator jwtTokenGenerator;
    @Autowired
    private UserDetailsService userDetailsService;

    public JwtToken create(ServletWebRequest webRequest) throws AuthenticationServiceException{
        //生成JwtToken
        JwtToken jwtToken = jwtTokenGenerator.generate(webRequest);
        //将JwtToken保存到redis中
        redisJwtTokenRepository.save(webRequest,jwtToken);

        return jwtToken;
    }

    public void validate(ServletWebRequest webRequest) throws AuthenticationServiceException{
        String authHeader = webRequest.getHeader(securityProperties.getJwt().getTokenHeader());
        String tokenHead = securityProperties.getJwt().getTokenHead();

        //用户未授权
        if (authHeader == null && !authHeader.startsWith(tokenHead)){
            throw new AuthenticationServiceException("用户未授权");
        }
        String token = authHeader.substring(tokenHead.length());

        Claims claims = parse(token);
        if(claims == null){
            throw new AuthenticationServiceException("用户授权异常，token已过期");
        }
        String username = (String) claims.get(JwtToken.CLAIM_KEY_USERNAME);
        String loadUsername = redisJwtTokenRepository.load(webRequest);

        if(username == null){
            throw new AuthenticationServiceException("用户授权异常，用户名为空");
        }
        if(!loadUsername.equals(username)){
            throw new AuthenticationServiceException("用户授权异常，用户名不匹配");
        }

        //token校验通过，设置为已登录
        UserDetails userDetails = userDetailsService.loadUserByUsername(username);
        if(userDetails == null){
            throw new AuthenticationServiceException("用户状态异常，请重新登录");
        }
        UsernamePasswordAuthenticationToken authentication=
                new UsernamePasswordAuthenticationToken(userDetails,null,userDetails.getAuthorities());
        authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(webRequest.getRequest()));
        SecurityContextHolder.getContext().setAuthentication(authentication);
    }


    //解析token
    private Claims parse(String token){
        Claims claims = null;
        try {
            claims = Jwts.parser()
                    .setSigningKey(securityProperties.getJwt().getSecret())
                    .parseClaimsJws(token)
                    .getBody();
        } catch (Exception e) {
            LOGGER.info("JWT格式验证失败:{}",token);
        }
        return claims;

    }
}
