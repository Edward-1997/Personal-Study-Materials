package com.python.security.validate.code;

import org.springframework.web.context.request.ServletWebRequest;

public interface ValidateCodeRepository {
    //保存校验码
    void save(ServletWebRequest webRequest, ValidateCode code);
    //加载校验码
    ValidateCode load(ServletWebRequest webRequest, String codeType);
    //移除校验码
    void remove(ServletWebRequest webRequest, ValidateCode code);
}
