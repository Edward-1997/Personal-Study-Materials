package com.python.security.controller;


import com.python.security.response.CommonResult;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/5/5 19:47
 **/
@RestController
public class LoginController {

    @GetMapping("/auth/require")
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    public CommonResult login(HttpServletRequest request, HttpServletResponse response) {
        return CommonResult.unauthorized("用户未授权：请授权");
    }

}
