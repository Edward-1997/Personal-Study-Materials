package com.python.security.validate.code.sms;


import com.python.security.validate.code.AbstractValidateCodeProcessor;
import com.python.security.validate.code.ValidateCode;
import org.springframework.web.context.request.ServletWebRequest;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/4/30 10:00
 **/

public class SmsValidateCodeProcessor extends AbstractValidateCodeProcessor<ValidateCode> {
    private SmsValidateCodeSender smsCodeSender;

    @Override
    protected void send(ServletWebRequest request, ValidateCode validateCode) throws Exception {
        String mobile = request.getRequest().getParameter("mobile");
        smsCodeSender.send(mobile,validateCode.getCode());
        request.getResponse().getWriter().write(validateCode.getCode());
    }

    public SmsValidateCodeSender getSmsCodeSender() {
        return smsCodeSender;
    }

    public void setSmsCodeSender(SmsValidateCodeSender smsCodeSender) {
        this.smsCodeSender = smsCodeSender;
    }
}
