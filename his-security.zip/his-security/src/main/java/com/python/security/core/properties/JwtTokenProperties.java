package com.python.security.core.properties;

import java.time.LocalDateTime;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/5/5 21:18
 **/
public class JwtTokenProperties {
    //请求头
    private String tokenHeader = "Authorization";
    //token 的头部
    private String tokenHead ="Bearer";
    //默认的密钥，用来加密解密
    private String secret = "DEFAULT_JWT_SECRET";
    //默认的过期时间为24h
    private long expiration = 24*60*60;

    public String getTokenHeader() {
        return tokenHeader;
    }

    public void setTokenHeader(String tokenHeader) {
        this.tokenHeader = tokenHeader;
    }

    public String getSecret() {
        return secret;
    }

    public void setSecret(String secret) {
        this.secret = secret;
    }

    public long getExpiration() {
        return expiration;
    }

    public void setExpiration(long expiration) {
        this.expiration = expiration;
    }

    public String getTokenHead() {
        return tokenHead;
    }

    public void setTokenHead(String tokenHead) {
        this.tokenHead = tokenHead;
    }
}
