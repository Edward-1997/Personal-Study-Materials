package com.python.security.validate.code.sms;

import org.springframework.stereotype.Component;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/4/29 16:02
 **/
public class DefaultSmsValidateCodeSend implements SmsValidateCodeSender {
    @Override
    public void send(String mobile, String smsCode) {
        System.out.println("mobile："+mobile+"短信验证码："+smsCode);
    }
}
