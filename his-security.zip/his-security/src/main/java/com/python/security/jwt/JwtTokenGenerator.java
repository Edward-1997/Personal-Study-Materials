package com.python.security.jwt;

import com.python.security.core.properties.SecurityProperties;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.ServletWebRequest;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/5/6 7:44
 **/
@Component
public class JwtTokenGenerator {
    @Autowired
    private SecurityProperties securityProperties;
    @Autowired
    private UserDetailsService userDetailsService;
    @Autowired
    private PasswordEncoder passwordEncoder;

    public JwtToken generate(ServletWebRequest webRequest) throws AuthenticationServiceException{
        String username = webRequest.getParameter("username");

        UserDetails userDetails = userDetailsService.loadUserByUsername(username);

        Map<String, Object> claims = new HashMap<>();
        claims.put(JwtToken.CLAIM_KEY_USERNAME, userDetails.getUsername()); //名字
        claims.put(JwtToken.CLAIM_KEY_CREATED, new Date(System.currentTimeMillis()
                +securityProperties.getJwt().getExpiration()*1000)); //时间
        claims.put(JwtToken.CLAIM_KEY_AUTHORIZATION,userDetails.getAuthorities());


        String token = Jwts.builder()
                .setClaims(claims)
                .setExpiration((Date)claims.get(JwtToken.CLAIM_KEY_CREATED))
                .signWith(SignatureAlgorithm.HS512, securityProperties.getJwt().getSecret())
                .compact();
        return new JwtToken(token, (Date) claims.get(JwtToken.CLAIM_KEY_CREATED));
    }

    //匹配用户登录的用户名和密码是否一致
    private boolean isMatched(ServletWebRequest webRequest,UserDetails userDetails){
        String obtainUsername = webRequest.getParameter("username");
        String obtainPassword = webRequest.getParameter("password");

        String username = userDetails.getUsername();
        String password = userDetails.getPassword();
        if(!username.equals(obtainUsername)){
            return false;
        }
        if(!passwordEncoder.matches(obtainPassword,password)){
            return false;
        }

        //如果校验成功，则在securityContext中添加该验证信息
        UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
        SecurityContextHolder.getContext().setAuthentication(authentication);
        return true;
    }
}
