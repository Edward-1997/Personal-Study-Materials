package com.python.security.core.authorize;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.python.security.core.properties.SecurityProperties;
import com.python.security.jwt.JwtToken;
import com.python.security.jwt.JwtTokenProcessor;
import com.python.security.response.CommonResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.SavedRequestAwareAuthenticationSuccessHandler;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.ServletWebRequest;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/5/2 17:32
 **/
@Component
public class DefaultAuthenticationSuccessHandler extends SavedRequestAwareAuthenticationSuccessHandler {
    private Logger logger = LoggerFactory.getLogger(getClass());
    @Autowired
    private ObjectMapper objectMapper;
    @Autowired
    private SecurityProperties securityProperties;
    @Autowired
    private JwtTokenProcessor jwtTokenProcessor;

    /*
     * 登录成功后调用这个方法,authentication封装了认证信息
     */
    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
                                        Authentication authentication) throws IOException, ServletException {

        logger.info(request.getRemoteAddr()+":"+request.getRemoteUser()+":登录成功");
        response.setContentType("application/json;charset=UTF-8");

        ServletWebRequest webRequest = new ServletWebRequest(request,response);

        JwtToken jwtToken=null;
        try{
            jwtToken =jwtTokenProcessor.create(webRequest);
        }catch (Exception e){
            response.getWriter().write(objectMapper.writeValueAsString(CommonResult.failed("创建token失败")));
            return ;
        }

        Map<String, String> tokenMap = new HashMap<>();
        tokenMap.put("token", jwtToken.getJwtToken());
        tokenMap.put("tokenHead", securityProperties.getJwt().getTokenHead());
        response.getWriter().write(objectMapper.writeValueAsString(CommonResult.success(tokenMap)));
    }
}
