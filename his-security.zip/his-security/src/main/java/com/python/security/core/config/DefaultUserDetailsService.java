package com.python.security.core.config;

import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/5/5 19:39
 **/
public class DefaultUserDetailsService implements UserDetailsService {

    private PasswordEncoder passwordEncoder;

    //private UserMapper userMapper;去数据库里查询用户名密码

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        String password = "123456";
        String encode = passwordEncoder.encode(password);

        return  new User(username,encode,
                AuthorityUtils.commaSeparatedStringToAuthorityList("admin,ROLE_USER"));
    }

    public PasswordEncoder getPasswordEncoder() {
        return passwordEncoder;
    }

    public void setPasswordEncoder(PasswordEncoder passwordEncoder) {
        this.passwordEncoder = passwordEncoder;
    }
}
