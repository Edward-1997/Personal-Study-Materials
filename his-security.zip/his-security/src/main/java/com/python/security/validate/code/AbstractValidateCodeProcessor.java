package com.python.security.validate.code;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.Assert;
import org.springframework.web.context.request.ServletWebRequest;

import java.util.Map;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/4/30 9:27
 **/
public abstract class AbstractValidateCodeProcessor<C extends ValidateCode> implements ValidateCodeProcessor {
    private Logger logger = LoggerFactory.getLogger(AbstractValidateCodeProcessor.class);
    //从spring容器中注入校验码生成器
    @Autowired
    private Map<String, ValidateCodeGenerator> validateCodeGenerators;

    @Autowired
    private ValidateCodeRepository validateCodeRepository;

    /*
     * (non-Javadoc)
     */
    @Override
    public void create(ServletWebRequest webRequest) throws Exception {
        // 校验码生成
        C validateCode = generate(webRequest);
        if(logger.isDebugEnabled()){
            logger.debug(validateCode.toString());
        }
        // 保存校验码
        save(webRequest,validateCode);
        // 发送校验码
        send(webRequest,validateCode);
    }

    /**
     * 生成校验码
     */
    @SuppressWarnings("unchecked")
    private C generate(ServletWebRequest webRequest) {
        String path = webRequest.getRequest().getRequestURI();
        int index = path.lastIndexOf("/");
        String type = path.substring(index+1).toLowerCase();

        String generatorName = type + ValidateCodeGenerator.class.getSimpleName();
        ValidateCodeGenerator codeGenerator = validateCodeGenerators.get(generatorName);
        if (codeGenerator == null) {
            throw new ValidateCodeException("验证码生成器" + generatorName + "不存在");
        }
        return (C) codeGenerator.generate();
    }

    /**
     * 保存校验码
     */
    private void save(ServletWebRequest webRequest, C validateCode) {
        ValidateCode code = new ValidateCode(validateCode.getCode(), validateCode.getExpireTime());
        validateCodeRepository.save(webRequest, validateCode);
    }

    /**
     * 发送校验码，由子类实现
     *
     * @param request
     * @param validateCode
     * @throws Exception
     */
    protected abstract void send(ServletWebRequest request, C validateCode) throws Exception;

    /**
     * 验证码的校验
     **/
    @SuppressWarnings("unchecked")
    @Override
    public void validate(ServletWebRequest webRequest) throws  ValidateCodeException{

        ValidateCode validateCode = validateCodeRepository.load(webRequest, webRequest.getParameter("type"));
        String code = webRequest.getParameter("code");
        Assert.notNull(validateCode,"校验码不为空");
        if(logger.isInfoEnabled()){
            logger.info(webRequest.getRequest().getRemoteAddr()+"校验码是："+code);
        }

        if(code == null){
            throw new ValidateCodeException("验证码为空");
        }

        if(!code.equals(validateCode.getCode())){
            throw new ValidateCodeException("验证码错误");
        }
        if(logger.isInfoEnabled()){
            logger.info(webRequest.getRequest().getRemoteAddr()+":校验码成功");
        }
        validateCodeRepository.remove(webRequest,validateCode);
    }
}
