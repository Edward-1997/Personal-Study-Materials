package com.python.security.validate.code;



public interface ValidateCodeGenerator {
    //生成图片校验码
    ValidateCode generate();
}
