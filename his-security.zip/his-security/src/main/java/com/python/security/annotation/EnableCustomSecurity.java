package com.python.security.annotation;


import com.python.security.core.config.DefaultCustomSecurityConfig;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.security.config.annotation.authentication.configuration.EnableGlobalAuthentication;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;


/**
 * security自定义注解，能够加载自定义Security配置
 * @author tanglong
 * @since 2020/5/5 20:48
 * @see
 **/
@Retention(value = java.lang.annotation.RetentionPolicy.RUNTIME)
@Target(value = { java.lang.annotation.ElementType.TYPE })
@Documented
@Import(DefaultCustomSecurityConfig.class)
@EnableGlobalAuthentication
@Configuration
public @interface EnableCustomSecurity {
}
