package com.python.security.jwt;

import com.python.security.core.properties.SecurityProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.server.ServerWebExchange;

import java.time.LocalDateTime;
import java.util.concurrent.TimeUnit;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/4/30 14:24
 **/
@Component
public class RedisJwtTokenRepository {
    private Logger logger = LoggerFactory.getLogger(RedisJwtTokenRepository.class);

    @Autowired
    private RedisTemplate redisTemplate;
    @Autowired
    private SecurityProperties securityProperties;

    private static final String REDIS_KEY = "JWT_REDIS_KEY";

    /**
     * 将jwt保存在redis缓存中，key：jwtToken+REDIS_KEY，value：用户名
     * @author tanglong
     * @param webRequest
     * @param  jwtToken
     * @return void
     * @throws
     * @since 2020/5/6 7:58
     * @see
     **/
    public void save(ServletWebRequest webRequest,JwtToken jwtToken) {

        String username = webRequest.getParameter("username");
        ValueOperations ops = redisTemplate.opsForValue();

        String deviceId = "123456";//这个由前端传过来

        if(deviceId == null){
            logger.info(LocalDateTime.now()+"  异常：用户设备ID为空");
            throw new AuthenticationServiceException("异常：用户设备ID为空");
        }
        ops.set(REDIS_KEY+":"+deviceId,username,securityProperties.getJwt().getExpiration(),
                TimeUnit.SECONDS);
    }

    public String load(ServletWebRequest webRequest) {

        String deviceId = "123456";//这个由前端传过来
        ValueOperations ops = redisTemplate.opsForValue();

        Boolean hasKey = redisTemplate.hasKey(REDIS_KEY+":"+deviceId);
        if(hasKey){
            return (String) ops.get(REDIS_KEY+":"+deviceId);
        }
        return null;
    }
}
