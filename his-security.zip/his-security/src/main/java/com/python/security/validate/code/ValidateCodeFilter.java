package com.python.security.validate.code;

import com.python.security.core.properties.SecurityProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.stereotype.Component;
import org.springframework.util.AntPathMatcher;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/4/29 10:31
 **/
@Component
public class ValidateCodeFilter extends  OncePerRequestFilter{
    @Autowired
    private AuthenticationFailureHandler failureHandler;

    private Set<String> urls = new HashSet<>();
    @Autowired
    private SecurityProperties securityProperties;

    private AntPathMatcher matcher = new AntPathMatcher();

    @Autowired
    private ValidateCodeProcessorHolder holder;

    @Override
    protected void initFilterBean() throws ServletException {
        String[] configUrls = securityProperties.getCode().getImage().getUrl().split(",");
        Arrays.stream(configUrls).forEach(string ->urls.add(string));
        urls.addAll(Arrays.asList(configUrls));
        urls.add("/auth/form");
        urls.add("/auth/mobile");
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        boolean flag = false;
        for(String url :urls){
            if(matcher.match(url,request.getRequestURI())){
                logger.info("url："+url+"需要校验码");
                flag =true;
                break;
            }
        }

        if(flag && "POST".equals(request.getMethod())){
            try{
                String type = request.getParameter("type");
                holder.findValidateCodeProcessor(type).validate(new ServletWebRequest(request,response));
            }catch (ValidateCodeException ex){
                failureHandler.onAuthenticationFailure(request,response,ex);
            }
        }
        filterChain.doFilter(request,response);
    }

}
