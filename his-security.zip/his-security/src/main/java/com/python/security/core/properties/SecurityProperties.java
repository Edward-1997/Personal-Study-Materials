package com.python.security.core.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/4/28 7:50
 **/
@ConfigurationProperties(prefix = "com.python.security")
public class SecurityProperties {

    //默认不用鉴权的url表
    private String[] excluded = {"/auth/**","/code/**"};
    //JwtToken配置类
    private JwtTokenProperties jwt = new JwtTokenProperties();
    //校验码配置类
    private ValidateCodeProperties code = new ValidateCodeProperties();

    public JwtTokenProperties getJwt() {
        return jwt;
    }

    public void setJwt(JwtTokenProperties jwt) {
        this.jwt = jwt;
    }

    public String[] getExcluded() {
        return excluded;
    }

    public void setExcluded(String[] excluded) {
        this.excluded = excluded;
    }

    public ValidateCodeProperties getCode() {
        return code;
    }

    public void setCode(ValidateCodeProperties code) {
        this.code = code;
    }


}
