package com.python.security.jwt;



import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * JwtToken生成的工具类
 * JWT token的格式：header.payload.signature
 * header的格式（算法、token的类型）：
 * {"alg": "HS512","typ": "JWT"}
 * payload的格式（用户名、创建时间、生成时间）：
 * {"sub":"wang","created":1489079981393,"exp":1489684781}
 * signature的生成算法：
 * HMACSHA512(base64UrlEncode(header) + "." +base64UrlEncode(payload),secret)
 * Created by macro on 2018/4/26.
 */

public class JwtToken {

    protected static final String CLAIM_KEY_USERNAME = "USERNAME";
    protected static final String CLAIM_KEY_CREATED = "CREATED";
    protected static final String CLAIM_KEY_AUTHORIZATION ="AUTHORIZATION";

    private Date expireTime;

    private String jwtToken;

    public JwtToken(String jwtToken,Date expireTime) {
        this.expireTime = expireTime;
        this.jwtToken = jwtToken;
    }

    public Date getExpireTime() {
        return expireTime;
    }

    public void setExpireTime(Date expireTime) {
        this.expireTime = expireTime;
    }

    public String getJwtToken() {
        return jwtToken;
    }

    public void setJwtToken(String jwtToken) {
        this.jwtToken = jwtToken;
    }


}
