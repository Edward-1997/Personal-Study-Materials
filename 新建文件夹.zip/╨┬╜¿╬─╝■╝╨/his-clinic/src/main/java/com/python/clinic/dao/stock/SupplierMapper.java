package com.python.clinic.dao.stock;

import com.python.clinic.entity.stock.Supplier;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 供应商表 Mapper 接口
 * </p>
 *
 * @author hm
 * @since 2020-05-22
 */
public interface SupplierMapper extends BaseMapper<Supplier> {

}
