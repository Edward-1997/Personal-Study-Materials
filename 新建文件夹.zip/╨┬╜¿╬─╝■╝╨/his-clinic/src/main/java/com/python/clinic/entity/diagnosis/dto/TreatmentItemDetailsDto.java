package com.python.clinic.entity.diagnosis.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Date;

/**
 * 患者/执行记录中治疗项目的执行记录详细细节
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/5/27 16:43
 **/
@Data
public class TreatmentItemDetailsDto {

    @ApiModelProperty(value = "治疗理疗项目的id")
    private Integer id;
    @ApiModelProperty(value = "项目名称")
    private String itemName;
    @ApiModelProperty(value = "项目状态：0 待执行，1 已执行，2 已退")
    private Integer status;
    @ApiModelProperty(value = "开单日期")
    private Date diagnosisTime;
    @ApiModelProperty(value = "诊所id")
    private Integer clinicId;
    @ApiModelProperty
    private String clinicName;
}
