package com.python.clinic.dao.stock;

import com.python.clinic.entity.stock.RelationBill;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 关联单据id Mapper 接口
 * </p>
 *
 * @author hm
 * @since 2020-05-29
 */
public interface RelationBillMapper extends BaseMapper<RelationBill> {

    /**
     * 查询关联单据
     * @param settlementId 结算申请id
     * @return
     */
    List<RelationBill> listRelationBillBySettlementId(@Param("settlementId")Integer settlementId);

    /**
     * 批量插入关联单据
     * @param list
     * @param settlementId
     * @return
     */
    int saveBatch(@Param("list") List<RelationBill> list, @Param("settlementId") Integer settlementId);

}
