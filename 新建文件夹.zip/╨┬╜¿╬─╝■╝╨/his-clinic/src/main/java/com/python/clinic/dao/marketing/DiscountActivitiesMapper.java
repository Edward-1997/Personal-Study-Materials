package com.python.clinic.dao.marketing;

import com.python.clinic.entity.marketing.DiscountActivities;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 折扣活动表 Mapper 接口
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-02
 */
public interface DiscountActivitiesMapper extends BaseMapper<DiscountActivities> {

}
