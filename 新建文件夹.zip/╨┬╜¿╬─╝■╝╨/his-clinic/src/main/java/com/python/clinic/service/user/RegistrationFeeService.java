package com.python.clinic.service.user;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.python.clinic.entity.user.RegistrationFee;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 挂号费表 服务类
 * </p>
 *
 * @author hm
 * @since 2020-06-06
 */
public interface RegistrationFeeService extends IService<RegistrationFee> {

    /**
     *获取医生挂号费(每个医生每个诊室为一条数据)
     * @param page
     * @param departmentId 诊室id,为null表示全部，为0表示其他
     * @param userName  用户名称
     * @return
     */
    IPage<Map<String,Object>> listDoctorRegistrationFee(IPage<RegistrationFee> page, Integer departmentId,String userName);

    /**
     * 添加或修改挂号费
     * @param registrationFee
     * @return
     */
    boolean saveOrUpdateRegistrationFee(RegistrationFee registrationFee);

}
