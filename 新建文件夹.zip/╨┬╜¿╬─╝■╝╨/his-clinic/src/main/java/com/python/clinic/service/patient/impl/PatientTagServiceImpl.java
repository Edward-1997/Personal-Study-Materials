package com.python.clinic.service.patient.impl;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.python.clinic.dao.patient.PatientTagMapper;
import com.python.clinic.entity.patient.PatientTag;
import com.python.clinic.entity.patient.Tags;
import com.python.clinic.service.patient.PatientTagService;
import com.python.common.response.CommonResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * <p>
 * 患者标签表 服务实现类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-20
 */
@Service
public class PatientTagServiceImpl extends ServiceImpl<PatientTagMapper, PatientTag> implements PatientTagService {
    @Autowired
    private PatientTagMapper patientTagMapper;

    @Override
    public CommonResult insertPatientTag(PatientTag patientTag) {
        int flag = patientTagMapper.insert(patientTag);
        if(flag == 1){
            return CommonResult.success(null,"添加患者标签成功");
        }
        return CommonResult.failed("添加患者标签失败");
    }

    @Override
    public CommonResult deletePatientTag(PatientTag patientTag) {
        QueryWrapper<PatientTag> wrapper = new QueryWrapper<>(patientTag);
        int flag = patientTagMapper.delete(wrapper);
        if(flag == 1){
            return CommonResult.success(null,"删除患者标签成功");
        }
        return CommonResult.success(null,"删除患者标签失败");
    }

    @Override
    public CommonResult getPatientTags(Integer patientId) {

        List<PatientTag> patientTags = patientTagMapper.selectTagListByPatientId(patientId);

        List<Tags> tagsList = patientTags.stream()
                .map(PatientTag::getTag)
                .collect(Collectors.toList());

        Map<String,List> map = new HashMap<>();
        map.put("tags",tagsList);
        return CommonResult.success(map,"查询成功");
    }


}
