package com.python.clinic.entity.stock;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 科室出库详情批次
 * </p>
 *
 * @author hm
 * @since 2020-05-23
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_out_of_stock_batch")
@ApiModel(value="OutOfStockBatch对象", description="出库详情批次")
public class OutOfStockBatch extends Model<OutOfStockBatch> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "出库详情id")
    private Integer stockDetailsId;

    @ApiModelProperty(value = "批次id")
    private Integer batchId;

    @ApiModelProperty(value = "整装数量")
    private Integer packageCount;

    @ApiModelProperty(value = "散装数量")
    private Integer pieceCount;

    @ApiModelProperty(value = "整装数量")
    private String packageUnit;

    @ApiModelProperty(value = "散装数量")
    private String pieceUnit;

    @ApiModelProperty(value = "金额")
    private BigDecimal amount;

    public OutOfStockBatch(Integer stockDetailsId, Integer batchId, Integer packageCount, Integer pieceCount, String packageUnit, String pieceUnit, BigDecimal amount) {
        this.stockDetailsId = stockDetailsId;
        this.batchId = batchId;
        this.packageCount = packageCount;
        this.pieceCount = pieceCount;
        this.packageUnit = packageUnit;
        this.pieceUnit = pieceUnit;
        this.amount = amount;
    }

    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
