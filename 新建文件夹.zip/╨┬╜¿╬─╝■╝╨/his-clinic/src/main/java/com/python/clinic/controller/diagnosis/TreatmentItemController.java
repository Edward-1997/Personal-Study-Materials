package com.python.clinic.controller.diagnosis;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.python.clinic.entity.diagnosis.TreatmentItem;
import com.python.clinic.entity.diagnosis.dto.TreatmentItemDetailsDto;
import com.python.clinic.entity.diagnosis.vo.SetMealVo;
import com.python.clinic.service.diagnosis.TreatmentItemService;
import com.python.common.response.CommonResult;
import io.swagger.annotations.ApiOperation;
import io.swagger.models.auth.In;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 治疗项目表 前端控制器
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-26
 */
@RestController
@RequestMapping("/treatmentItem")
public class TreatmentItemController {
    @Autowired
    private TreatmentItemService treatmentItemService;

    @ApiOperation(value = "查询患者执行记录/患者档案",notes = "分页查询，默认一页5条患者记录，按照时间降序，" +
            "传入patientId，患者id，pageSize:数量 默认为5，pageNum:起始位置 默认为1")
    @GetMapping("/records/{patientId}")
    public CommonResult getTreatmentItemRecords(@PathVariable Integer patientId,
                                                @RequestParam(defaultValue = "1") Integer pageNum,
                                                @RequestParam(defaultValue = "5") Integer pageSize){
        IPage<TreatmentItemDetailsDto> page = treatmentItemService.getPatientTreatmentItemList(patientId, pageNum, pageSize);
        Map<String,Object> map = new HashMap<>();
        map.put("executionRecords",page);
        return CommonResult.success(map);
    }

    @PostMapping("/saveTreatmentItem")
    @ApiOperation("添加治疗项目")
    public CommonResult saveTreatmentItem(@Validated @RequestBody TreatmentItem treatmentItem){
        return CommonResult.result(treatmentItemService.saveTreatmentItem(treatmentItem));
    }

    @PutMapping("/updateTreatmentItem")
    @ApiOperation("修改治疗项目")
    public CommonResult updateTreatmentItem(@RequestBody TreatmentItem treatmentItem){
        return CommonResult.result(treatmentItemService.updateTreatmentItem(treatmentItem));
    }

    @PutMapping("/updateTreatmentItemStatus/{id}/{status}")
    @ApiOperation(value = "修改治疗项目状态",notes = "status:0：停用，1：启用，2：删除")
    public CommonResult deleteTreatmentItem(@PathVariable Integer id, @PathVariable Integer status){
        TreatmentItem treatmentItem = new TreatmentItem();
        treatmentItem.setId(id);
        treatmentItem.setStatus(status);
        return CommonResult.result(treatmentItemService.updateById(treatmentItem));
    }

    @GetMapping("/listTreatmentItem")
    @ApiOperation(value = "获取治疗项目列表",notes = "type(3:检查检验；4：治疗理疗；5：套餐；6：其他费用),subType(0:检查，1：检验，2：治疗，3：理疗)," +
            "itemName 项目名称，clinicId 诊所id")
    public CommonResult listTreatmentItem(@RequestParam(defaultValue = "1") Integer pageNum,
                                          @RequestParam(defaultValue = "10") Integer pageSize,
                                          @RequestParam(required = true)Integer type, Integer subType,
                                          Integer itemName,@RequestParam(required = true) Integer clinicId){
        IPage<TreatmentItem> page = new Page<>(pageNum,pageSize);
        return CommonResult.success(treatmentItemService.listTreatmentItem(page,type,subType,itemName,clinicId));
    }

    @GetMapping("/listSetMeal")
    @ApiOperation(value = "获取套餐列表",notes = "itemName:项目名称，clinicId:诊所id")
    public CommonResult listSetMeal(@RequestParam(defaultValue = "1") Integer pageNum,
                                          @RequestParam(defaultValue = "10") Integer pageSize,
                                          Integer itemName,@RequestParam(required = true) Integer clinicId){
        IPage<SetMealVo> page = new Page<>(pageNum,pageSize);
        return CommonResult.success(treatmentItemService.listSetMeal(page,itemName,clinicId));
    }

    @GetMapping("/getSetMeal/{setMealId}")
    @ApiOperation(value = "获取套餐详情",notes = "setMealId:套餐id")
    public CommonResult getSetMeal(@PathVariable Integer setMealId){
        return CommonResult.success(treatmentItemService.getSetMeal(setMealId));
    }

}
