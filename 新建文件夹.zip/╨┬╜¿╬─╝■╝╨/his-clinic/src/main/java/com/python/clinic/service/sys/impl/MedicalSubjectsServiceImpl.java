package com.python.clinic.service.sys.impl;

import com.python.clinic.entity.sys.MedicalSubjects;
import com.python.clinic.dao.sys.MedicalSubjectsMapper;
import com.python.clinic.service.sys.MedicalSubjectsService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 设备类别表 服务实现类
 * </p>
 *
 * @author hm
 * @since 2020-06-02
 */
@Service
public class MedicalSubjectsServiceImpl extends ServiceImpl<MedicalSubjectsMapper, MedicalSubjects> implements MedicalSubjectsService {

}
