package com.python.clinic.service.stock.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.python.clinic.dao.stock.EarlyWarningMapper;
import com.python.clinic.dao.sys.SysConfigMapper;
import com.python.clinic.entity.stock.EarlyWarning;
import com.python.clinic.entity.sys.SysConfig;
import com.python.clinic.service.stock.EarlyWarningService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * <p>
 * 库存预警设置 服务实现类
 * </p>
 *
 * @author hm
 * @since 2020-05-19
 */
@Service
public class EarlyWarningServiceImpl extends ServiceImpl<EarlyWarningMapper, EarlyWarning> implements EarlyWarningService {

    @Resource
    private EarlyWarningMapper earlyWarningMapper;
    @Resource
    private SysConfigMapper sysConfigMapper;

    /*@Override
    public EarlyWarning getEarlyWarning(Integer goodsId, Integer clinicId) {
        QueryWrapper wrapper = new QueryWrapper();
        wrapper.eq("goods_id",goodsId);
        EarlyWarning earlyWarning = earlyWarningMapper.selectOne(wrapper);

        QueryWrapper queryWrapper = new QueryWrapper();
        queryWrapper.eq("clinic_id",clinicId);
        SysConfig sysConfig = sysConfigMapper.selectOne(queryWrapper);

        //商品未设置预警，默认诊所预警设置
        if (earlyWarning == null){
            return new EarlyWarning(sysConfig.getStockWarnGoodsTurnoverDays(),sysConfig.getStockWarnGoodsWillExpiredMonth());
        }
        //商品库存预警为系统默认
        if (earlyWarning.getInventoryAlertSetting() == 0){
            earlyWarning.setInventoryAlert(sysConfig.getStockWarnGoodsTurnoverDays());
        }
        //商品有效期预警为系统默认
        if (earlyWarning.getValidityWarningSetting() == 0){
            earlyWarning.setValidityWarning(sysConfig.getStockWarnGoodsWillExpiredMonth());
        }
        return earlyWarning;
    }*/
}
