package com.python.clinic.entity.diagnosis;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 随访表
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-22
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_follow_up")
@ApiModel(value="FollowUp对象", description="随访表")
public class FollowUp extends Model<FollowUp> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "随访类型 0：诊后随访")
    private Integer type;

    @ApiModelProperty(value = "患者id")
    private Integer patientId;

    @ApiModelProperty(value = "诊断表id")
    private Integer diagnosisId;

    @ApiModelProperty(value = "随访目标")
    private String objectives;

    @ApiModelProperty(value = "随访状态  0：待执行，1:已执行，2:已终止")
    private Integer status;

    @ApiModelProperty(value = "随访人")
    private Integer followUpPeople;

    @ApiModelProperty(value = "随访时间")
    private Date followUpTime;

    @ApiModelProperty(value = "随访方式，0：微信；1：短信；2：电话；3：面对面；4：其他")
    private Integer mode;

    @ApiModelProperty(value = "随访结果")
    private String result;

    @ApiModelProperty(value = "随访附件")
    private String enclosure;

    @ApiModelProperty(value = "终止原因，0：未联系到客户；1：计划取消；2：计划延迟；3：其他")
    private Integer terminationResult;

    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
