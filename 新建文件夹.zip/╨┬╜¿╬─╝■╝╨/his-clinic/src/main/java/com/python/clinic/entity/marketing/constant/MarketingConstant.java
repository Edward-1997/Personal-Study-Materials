package com.python.clinic.entity.marketing.constant;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/6/3 9:20
 **/
public interface MarketingConstant {

    //活动范围 0：所有患者 1：指定会员
    Integer ALL_PATIENT =0;

    //折扣活动
    interface DiscountActivities{
        String DISCOUNT_LIST = "会员折扣列表";
    }

    //折扣类型
    interface DiscountType{
        //挂号，西药，中药，检验，检查，治疗，理疗，材料，商品，套餐
        Integer REGISTER=0;

        Integer WESTERN_MEDICINE=1;

        Integer TRADITIONAL_CHINESE_MEDICINE = 2;

        Integer EXAMINATION = 3;

        Integer CHECKOUT = 4;

        Integer TREATMENT = 5;

        Integer PHYSIOTHERAPY = 6;

        Integer MATERIAL = 7;

        Integer COMMODITY = 8;

        Integer MEAL = 9;

        String DISCOUNT_UNIT = "折";
    }
    //满减返优惠券常量
    interface GiftCoupon{
        //关联类型： 0 表示优惠券 1：表示赠品
        Integer  COUPON_TYPE= 0;

        Integer GOODS_TYPE = 1;
    }

    //满减返常量
    interface GiftRulePromotion{
        //活动状态 0：进行中 1：未开始 2：已结束
        Integer ONGOING_STATUS = 0;

        Integer NOT_START_STATUS = 1;

        Integer FINISHED_STATUS = 2;

    }

    //使用范围
    interface UseScope{
        //优惠券类型
        Integer COUPON_TYPE = 1;
        //满减返
        Integer GIFT_TYPE = 0;
    }
}
