package com.python.clinic.entity.stock;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * <p>
 * 入库日志详情表
 * </p>
 *
 * @author hm
 * @since 2020-05-19
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_stock_log_details")
@ApiModel(value="StockLogDetails对象", description="入库日志详情表")
public class StockLogDetails extends Model<StockLogDetails> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "修改项")
    private String item;

    @ApiModelProperty(value = "修改后的值")
    private String after;

    @ApiModelProperty(value = "修改前")
    private String before;

    @ApiModelProperty(value = "入库日志id")
    private Integer logId;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
