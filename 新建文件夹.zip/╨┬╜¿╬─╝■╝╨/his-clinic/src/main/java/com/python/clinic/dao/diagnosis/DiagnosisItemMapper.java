package com.python.clinic.dao.diagnosis;

import com.python.clinic.entity.diagnosis.DiagnosisItem;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 门诊检查项目表 Mapper 接口
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-26
 */
public interface DiagnosisItemMapper extends BaseMapper<DiagnosisItem> {

}
