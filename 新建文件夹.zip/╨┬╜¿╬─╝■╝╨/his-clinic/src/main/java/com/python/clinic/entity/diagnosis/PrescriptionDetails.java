package com.python.clinic.entity.diagnosis;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 处方详情表
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-26
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_prescription_details")
@ApiModel(value="PrescriptionDetails对象", description="处方详情表")
public class PrescriptionDetails extends Model<PrescriptionDetails> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "处方id")
    private Integer prescriptionId;

    @ApiModelProperty(value = "药品id")
    private Integer goodsId;

    @ApiModelProperty(value = "用法")
    private String usageMethod;

    @ApiModelProperty(value = "皮试，0：false，1：true")
    private Integer skinTest;

    @ApiModelProperty(value = "剂量")
    private Double dosage;

    @ApiModelProperty(value = "剂量单位")
    private String dosageUnit;

    @ApiModelProperty(value = "总量")
    private Double total;

    @ApiModelProperty(value = "总量单位")
    private String totalUnit;

    @ApiModelProperty(value = "频率")
    private String freq;

    @ApiModelProperty(value = "天数")
    private Integer days;

    @ApiModelProperty(value = "状态  0：待发，1：已发，2：已退")
    private Integer status;

    @ApiModelProperty(value = "单价，为空时使用商品价格")
    private BigDecimal unitPrice;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
