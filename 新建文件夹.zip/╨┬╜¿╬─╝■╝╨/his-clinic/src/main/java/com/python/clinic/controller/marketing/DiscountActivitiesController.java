package com.python.clinic.controller.marketing;


import com.python.clinic.entity.marketing.constant.MarketingConstant;
import com.python.clinic.service.marketing.DiscountActivitiesService;
import com.python.common.response.CommonResult;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * 折扣活动表 前端控制器
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-02
 */
@RestController
@RequestMapping("/discount_activities")
public class DiscountActivitiesController {

    @Autowired
    private DiscountActivitiesService discountActivitiesService;

    @ApiOperation(value = "查询折扣活动详情",notes = "根据id查询折扣活动详情")
    @GetMapping("/details/{id}")
    public CommonResult getDiscountActivityDetails(@PathVariable Integer id){
        Map<String,Object> map = new HashMap<>();
        map.put("discountActivityDetails",discountActivitiesService.getDiscountActivityDetails(id));
        return CommonResult.success(map);
    }

    @ApiOperation(value = "分页查询折扣活动列表",notes = "分页查询折扣活动列表，默认一页10条可根据前端传来字段改变")
    @GetMapping("/list")
    public CommonResult getDiscountActivities(@RequestParam(defaultValue = "") Integer pageNum,
                                              @RequestParam(defaultValue = "") Integer pageSize){
        return null;
    }
}
