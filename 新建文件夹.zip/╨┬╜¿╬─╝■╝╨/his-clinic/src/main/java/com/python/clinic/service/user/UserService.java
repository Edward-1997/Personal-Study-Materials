package com.python.clinic.service.user;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.python.clinic.entity.user.User;
import com.baomidou.mybatisplus.extension.service.IService;
import com.python.clinic.entity.user.dto.UserDTO;
import com.python.clinic.entity.user.vo.SchedulingVo;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 诊所用户表 服务类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-21
 */
public interface UserService extends IService<User> {

    /**
     * 添加用户
     * @param userDTO
     * @return
     */
    boolean saveUser(UserDTO userDTO);

    /**
     * 修改用户信息
     * @param userDTO
     * @return
     */
    boolean updateUser(UserDTO userDTO);

}
