package com.python.clinic.dao.stock;

import com.python.clinic.entity.stock.OutOfStockDetails;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 出库详情表 Mapper 接口
 * </p>
 *
 * @author hm
 * @since 2020-05-23
 */
public interface OutOfStockDetailsMapper extends BaseMapper<OutOfStockDetails> {

    /**
     * 根据出库id查询出库详情
     * @param outStockId
     * @return
     */
    List<OutOfStockDetails> listStockDetailsByOutStockId(@Param("outStockId")Integer outStockId);

}
