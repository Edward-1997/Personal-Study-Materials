package com.python.clinic.service.stock;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.python.clinic.entity.stock.PurchaseApply;
import com.baomidou.mybatisplus.extension.service.IService;
import com.python.clinic.entity.stock.dto.PurchaseApplyDTO;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;

/**
 * <p>
 * 采购申请表 服务类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-21
 */
public interface PurchaseApplyService extends IService<PurchaseApply> {

    /**
     * 带条件查询采购申请
     * @param status 状态
     * @param dateType  时间添加类型，0：申请日期，1：审核日期
     * @param startTime 开始时间
     * @param endTime   结束时间
     * @param goodsId   商品id
     * @return
     */
    IPage<PurchaseApply> listPurchaseApply(IPage<PurchaseApply> page,Integer status,Integer dateType,
                                           Date startTime, Date endTime, String goodsId);

    /**
     * 添加采购申请
     * @param purchaseApplyDTO
     * @return
     */
    boolean savePurchaseApply(PurchaseApplyDTO purchaseApplyDTO);

}
