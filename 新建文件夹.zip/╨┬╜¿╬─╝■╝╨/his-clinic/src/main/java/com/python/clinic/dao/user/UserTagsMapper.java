package com.python.clinic.dao.user;

import com.python.clinic.entity.user.UserTags;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author hm
 * @since 2020-06-02
 */
public interface UserTagsMapper extends BaseMapper<UserTags> {

    /**
     * 批量插入用户标签
     * @param list
     * @param userInfoId
     * @return
     */
    int saveBatch(@Param("list") List<UserTags> list, @Param("userInfoId")Integer userInfoId);

}
