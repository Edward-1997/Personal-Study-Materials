package com.python.clinic.controller.stock;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 库存日志表，包含药品/物资、入库、出库操作记录 前端控制器
 * </p>
 *
 * @author hm
 * @since 2020-05-19
 */
@RestController
@RequestMapping("/stock-log")
public class StockLogController {

}
