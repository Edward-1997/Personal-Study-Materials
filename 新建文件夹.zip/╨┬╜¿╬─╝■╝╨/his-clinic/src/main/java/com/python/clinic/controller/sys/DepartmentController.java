package com.python.clinic.controller.sys;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.python.clinic.entity.sys.Department;
import com.python.clinic.entity.sys.DepartmentUser;
import com.python.clinic.service.sys.DepartmentService;
import com.python.clinic.service.sys.DepartmentUserService;
import com.python.common.response.CommonResult;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 科室表 前端控制器
 * </p>
 *
 * @author hm
 * @since 2020-06-02
 */
@RestController
@RequestMapping("/department")
public class DepartmentController {

    @Autowired
    private DepartmentService departmentService;
    @Autowired
    private DepartmentUserService departmentUserService;

    @GetMapping("/listDepartment")
    @ApiOperation("获取科室列表")
    public CommonResult listDepartment(){
        return CommonResult.success(departmentService.listDepartment());
    }

    @PostMapping("/saveDepartment")
    @ApiOperation("添加科室")
    public CommonResult saveDepartment(@RequestBody Department department){
        //判断名称是否重复
        int count = departmentService.count(new QueryWrapper<Department>().eq("department_name", department.getDepartmentName()));
        if (count > 0){
            return CommonResult.failed("科室名称重复，请重新输入");
        }
        return CommonResult.result(departmentService.saveDepartment(department));
    }

    @PutMapping("/updateDepartment")
    @ApiOperation("修改科室")
    public CommonResult updateDepartment(@RequestBody Department department){
        //判断名称是否重复
        int count = departmentService.count(new QueryWrapper<Department>().eq("department_name", department.getDepartmentName())
                .ne("id", department.getId()));
        if (count > 0){
            return CommonResult.failed("科室名称重复，请重新输入");
        }
        return CommonResult.result(departmentService.updateDepartment(department));
    }

    @DeleteMapping("/deleteDepartment")
    @ApiOperation("删除科室")
    public CommonResult deleteDepartment(@RequestParam(required = true)Integer id){
        //科室有成员则不允许删除
        QueryWrapper<DepartmentUser> wrapper = new QueryWrapper<>();
        wrapper.eq("department_id",id);
        List<DepartmentUser> list = departmentUserService.list(wrapper);
        if (list == null || list.isEmpty()){
            return CommonResult.result(departmentService.removeById(id));
        }
        return CommonResult.failed("科室中已有成员，需要将成员移出科室才可删除");
    }

    @GetMapping("/getDepartment")
    @ApiOperation(value = "查看科室详情",notes = "id：科室id")
    public CommonResult getDepartment(@RequestParam(required = true)Integer id){
        return CommonResult.success(departmentService.getDepartment(id));
    }

}
