package com.python.clinic.entity.stock;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import javax.validation.constraints.Max;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 * <p>
 * 药品/物资表
 * </p>
 *
 * @author hm
 * @since 2020-05-19
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_goods")
@ApiModel(value="Goods对象", description="药品/物资表")
public class Goods extends Model<Goods> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "药品通用名称")
    private String medicineCadn;

    @ApiModelProperty(value = "类型，0：药品，1：物资，2：商品")
    private Integer type;

    @ApiModelProperty(value = "附属类型 ")
    private Integer subType;

    @ApiModelProperty(value = "药物剂型")
    private String medicineDosageForm;

    @ApiModelProperty(value = "名称")
    private String name;

    @ApiModelProperty(value = "生产厂家")
    private String manufacturer;

    @ApiModelProperty(value = "国药准字")
    private String medicineNmpn;

    @ApiModelProperty(value = "条形码")
    private String barCode;

    @ApiModelProperty(value = "剂量")
    private Double dosage;

    @ApiModelProperty(value = "剂量单位")
    private String dosageUnit;

    @ApiModelProperty(value = "药品制剂/物资包装数量")
    private Integer preparation;

    @ApiModelProperty(value = "药品制剂单位/物资最小单位")
    private String preparationUnit;

    @ApiModelProperty(value = "包装单位")
    private String packageUnit;

    @ApiModelProperty(value = "允许对外销售，0：false，1：true")
    private Integer sell;

    @ApiModelProperty(value = "零售价格")
    private BigDecimal sellPrice;

    @ApiModelProperty(value = "允许拆零销售，0：false，1：true")
    private Integer splitSales;

    @ApiModelProperty(value = "拆零销售价格")
    private BigDecimal piecePrice;

    @ApiModelProperty(value = "药品编码")
    private String drugCode;

    @ApiModelProperty(value = "社保编码")
    private String socialSecurityCode;

    @ApiModelProperty(value = "本位码")
    private String bitcode;

    @ApiModelProperty(value = "等级")
    private String level;

    @ApiModelProperty(value = "智能发货,0：false，1：true")
    private Integer smartShipping;

    @ApiModelProperty(value = "规格")
    private String specifications;

    @ApiModelProperty(value = "柜号")
    private String containerNo;

    @ApiModelProperty(value = "物资来源，进口/国产")
    private String origin;

    @ApiModelProperty(value = "注册证名称")
    private String certificateName;

    @ApiModelProperty(value = "注册证编码")
    private String certificateNo;

    @ApiModelProperty(value = "进项税率")
    private BigDecimal inTaxRat;

    @ApiModelProperty(value = "销项税率")
    private BigDecimal outTaxRat;

    @ApiModelProperty(value = "拼音")
    private String py;

    @ApiModelProperty(value = "诊所id")
    private Integer clinicId;

    @ApiModelProperty(value = "状态，1：正常，0：下架")
    private Integer status;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
