package com.python.clinic.service.marketing.impl;

import com.python.clinic.entity.marketing.DiscountStore;
import com.python.clinic.dao.marketing.DiscountStoreMapper;
import com.python.clinic.service.marketing.DiscountStoreService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 折扣门店表 服务实现类
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-02
 */
@Service
public class DiscountStoreServiceImpl extends ServiceImpl<DiscountStoreMapper, DiscountStore> implements DiscountStoreService {

}
