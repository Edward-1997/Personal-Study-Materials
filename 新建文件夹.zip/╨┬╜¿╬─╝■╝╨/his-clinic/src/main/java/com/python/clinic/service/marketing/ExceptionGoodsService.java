package com.python.clinic.service.marketing;

import com.python.clinic.entity.marketing.ExceptionGoods;
import com.baomidou.mybatisplus.extension.service.IService;
import com.python.clinic.entity.stock.Goods;

import java.util.List;

/**
 * <p>
 * 优惠券例外商品 服务类
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-05
 */
public interface ExceptionGoodsService extends IService<ExceptionGoods> {


    List<Goods> getExceptionGoodsList(Integer useScopeId);
}
