package com.python.clinic.service.sys.impl;

import com.python.clinic.entity.sys.SysConfig;
import com.python.clinic.dao.sys.SysConfigMapper;
import com.python.clinic.service.sys.SysConfigService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 系统配置 服务实现类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-21
 */
@Service
public class SysConfigServiceImpl extends ServiceImpl<SysConfigMapper, SysConfig> implements SysConfigService {

}
