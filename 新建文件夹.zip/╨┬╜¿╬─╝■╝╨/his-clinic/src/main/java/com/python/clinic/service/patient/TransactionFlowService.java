package com.python.clinic.service.patient;

import com.python.clinic.entity.patient.TransactionFlow;
import com.baomidou.mybatisplus.extension.service.IService;
import com.python.common.response.CommonResult;

/**
 * <p>
 * 交易流水表 服务类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-20
 */
public interface TransactionFlowService extends IService<TransactionFlow> {

    /**
     * 查询患者会员卡的交易流水
     * @author tanglong
     * @param patientCardId 患者会员卡id
     * @param pageSize 分页尺寸大小
     * @param pageNum 分页起始位置
     * @return com.python.common.response.CommonResult
     * @since 2020/5/22 10:43
     **/
     CommonResult getTransactionList(Integer patientCardId, Integer pageSize, Integer pageNum);


}
