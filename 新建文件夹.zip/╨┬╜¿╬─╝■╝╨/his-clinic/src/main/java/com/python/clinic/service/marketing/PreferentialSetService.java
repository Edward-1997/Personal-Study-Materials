package com.python.clinic.service.marketing;

import com.python.clinic.entity.marketing.PreferentialSet;
import com.baomidou.mybatisplus.extension.service.IService;
import com.python.clinic.entity.marketing.dto.GiftRulesDto;
import com.python.common.response.CommonResult;

import java.util.List;

/**
 * <p>
 * 优惠设置表 服务类
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-05
 */
public interface PreferentialSetService extends IService<PreferentialSet> {

    /**
     * 获取满减返还赠品详细规则，返还的规则包括返还赠品和优惠券
     * @author tanglong
     * @param giftId 满减返活动id
     * @return java.util.List<com.python.clinic.entity.marketing.vo.GiftRulesVo>
     * @since 2020/6/8 11:25
     **/
    List<GiftRulesDto> getGiftRulesVoList(Integer giftId);

    /**
     * 新增优惠列表
     * @author tanglong
     * @param giftRulesList 满减活动列表
     * @return com.python.common.response.CommonResult
     * @since 2020/6/9 17:24
     **/
    CommonResult insertGiftPreferential(List<GiftRulesDto> giftRulesList);

    /**
     * 删除优惠列表
     * @author tanglong
     * @return com.python.common.response.CommonResult
     * @since 2020/6/9 17:27
     **/
    CommonResult deleteGiftPreferential(Integer giftId);
}
