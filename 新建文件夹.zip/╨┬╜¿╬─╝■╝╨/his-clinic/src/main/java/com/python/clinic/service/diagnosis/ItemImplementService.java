package com.python.clinic.service.diagnosis;

import com.python.clinic.entity.diagnosis.ItemImplement;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 * 治疗项目执行记录表 服务类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-28
 */
public interface ItemImplementService extends IService<ItemImplement> {

    /**
     * 根据项目id查询患者执行记录
     * @author tanglong
     * @return java.util.List<com.python.clinic.entity.diagnosis.ItemImplement>
     * @since 2020/5/28 10:12
     **/
    List<ItemImplement> getItemImplementList(Integer itemId);
}
