package com.python.clinic.entity.patient;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 患者表
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-20
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_patient")
@ApiModel(value="Patient对象", description="患者表")
public class Patient extends Model<Patient> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "患者主键")
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "患者姓名")
    private String patientName;

    @ApiModelProperty(value = "性别 0：男  1：女")
    private Integer gender;

    @ApiModelProperty(value = "手机")
    private String phone;

    @ApiModelProperty(value = "年龄, 小于128")
    private Integer age;

    @ApiModelProperty(value = "生日")
    private Date birthday;

    @ApiModelProperty(value = "身份证号码")
    private String idCard;

    @ApiModelProperty(value = "来源")
    private String source;

    @ApiModelProperty(value = "推荐人id")
    private Integer sourceFrom;

    @ApiModelProperty(value = "住址")
    private String address;

    @ApiModelProperty(value = "微信号")
    private String wechat;

    @ApiModelProperty(value = "既往史")
    private String pastHistory;

    @ApiModelProperty(value = "创建时间")
    private Date createTime;

    @ApiModelProperty(value = "创建人")
    private Integer createId;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
