package com.python.clinic.controller.stock;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.python.clinic.entity.stock.PurchaseApply;
import com.python.clinic.entity.stock.dto.PurchaseApplyDTO;
import com.python.clinic.service.stock.PurchaseApplyService;
import com.python.common.response.CommonResult;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Date;

/**
 * <p>
 * 采购申请表 前端控制器
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-21
 */
@RestController
@RequestMapping("/purchaseApply")
public class PurchaseApplyController {

    @Autowired
    private PurchaseApplyService purchaseApplyService;

    @GetMapping("/listPurchaseApply")
    @ApiOperation(value = "查询采购申请列表",notes = "status：状态，dateType：日期类型(0：申请日期，1：审核日期)，goodsId：商品id")
    public CommonResult listPurchaseApply(@RequestParam(defaultValue = "1") Integer pageNo,
                                          @RequestParam(defaultValue = "10") Integer pageSize,
                                          Integer status, Integer dateType, Date startTime, Date endTime, String goodsId){
        IPage<PurchaseApply> page = new Page<>(pageNo,pageSize);
        return CommonResult.success(purchaseApplyService.listPurchaseApply(page,status,dateType,startTime,endTime,goodsId));
    }

    @PostMapping("/savePurchaseApply")
    @ApiOperation("添加采购申请")
    public CommonResult savePurchaseApply(@RequestBody PurchaseApplyDTO purchaseApplyDTO){
        purchaseApplyService.savePurchaseApply(purchaseApplyDTO);
        return CommonResult.result(true);
    }

}
