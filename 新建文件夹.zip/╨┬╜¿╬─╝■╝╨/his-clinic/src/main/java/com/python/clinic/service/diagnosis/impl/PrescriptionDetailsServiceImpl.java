package com.python.clinic.service.diagnosis.impl;

import com.python.clinic.entity.diagnosis.PrescriptionDetails;
import com.python.clinic.dao.diagnosis.PrescriptionDetailsMapper;
import com.python.clinic.service.diagnosis.PrescriptionDetailsService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 处方详情表 服务实现类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-26
 */
@Service
public class PrescriptionDetailsServiceImpl extends ServiceImpl<PrescriptionDetailsMapper, PrescriptionDetails> implements PrescriptionDetailsService {

}
