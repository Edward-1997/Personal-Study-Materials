package com.python.clinic.service.sys.impl;

import com.python.clinic.entity.sys.Dispensing;
import com.python.clinic.dao.sys.DispensingMapper;
import com.python.clinic.service.sys.DispensingService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 发药设置 服务实现类
 * </p>
 *
 * @author hm
 * @since 2020-06-05
 */
@Service
public class DispensingServiceImpl extends ServiceImpl<DispensingMapper, Dispensing> implements DispensingService {

}
