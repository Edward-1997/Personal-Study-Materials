package com.python.clinic.service.stock;

import com.python.clinic.entity.stock.Invoice;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 发票表 服务类
 * </p>
 *
 * @author hm
 * @since 2020-05-28
 */
public interface InvoiceService extends IService<Invoice> {

}
