package com.python.clinic.service.diagnosis;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.python.clinic.entity.diagnosis.TreatmentItem;
import com.baomidou.mybatisplus.extension.service.IService;
import com.python.clinic.entity.diagnosis.dto.TreatmentItemDetailsDto;
import com.python.clinic.entity.diagnosis.vo.SetMealVo;


/**
 * <p>
 * 治疗项目表 服务类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-26
 */
public interface TreatmentItemService extends IService<TreatmentItem> {

    /**
     * 查询患者诊疗项目中治疗理疗的记录
     * @author tanglong
     * @return java.util.List<com.python.clinic.entity.diagnosis.dto.TreatmentItemDetailsDto>
     * @since 2020/5/27 15:26
     **/
    IPage<TreatmentItemDetailsDto> getPatientTreatmentItemList(Integer patientId, Integer pageNum, Integer pageSize);

    /**
     * 添加治疗项目
     * @param treatmentItem
     * @return
     */
    boolean saveTreatmentItem(TreatmentItem treatmentItem);


    /**
     * 修改治疗项目
     * @param treatmentItem
     * @return
     */
    boolean updateTreatmentItem(TreatmentItem treatmentItem);

    /**
     * 查询治疗项目列表
     * @param type  类型  3:检查检验；4：治疗理疗；5：套餐；6：其他费用
     * @param subType  子类型 0:检查，1：检验，2：治疗，3：理疗
     * @param itemName 项目名称
     * @param clinicId 诊所id
     * @param page
     * @return
     */
    IPage<TreatmentItem> listTreatmentItem(IPage<TreatmentItem> page,Integer type, Integer subType, Integer itemName, Integer clinicId);

    /**
     * 查询套餐列表
     * @param itemName  套餐名称
     * @param clinicId  诊所id
     * @param page
     * @return
     */
    IPage<SetMealVo> listSetMeal(IPage<SetMealVo> page,Integer itemName, Integer clinicId);

    /**
     * 获取套餐详情
     * @param setMealId
     * @return
     */
    SetMealVo getSetMeal(Integer setMealId);
}
