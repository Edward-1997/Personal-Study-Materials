package com.python.clinic.service.user;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.python.clinic.entity.user.Scheduling;
import com.baomidou.mybatisplus.extension.service.IService;
import com.python.clinic.entity.user.User;
import com.python.clinic.entity.user.vo.SchedulingVo;
import com.python.common.response.CommonResult;

import java.util.List;

/**
 * <p>
 * 排班详情表 服务类
 * </p>
 *
 * @author hm
 * @since 2020-06-05
 */
public interface SchedulingService extends IService<Scheduling> {

    /**
     * 添加排班
     * @param schedulingList
     * @return
     */
    CommonResult saveScheduling(List<Scheduling> schedulingList);

    /**
     * 查询某诊室当前时间之后的排班数量
     * @param roomId
     * @return
     */
    boolean getNowAfterSchedulingCountByRoomId(Integer roomId);

    /**
     * 查询用户列表以及排班信息
     * @param role 角色 医生:doctor，员工:staff
     * @param departmentId 科室id，为null表示全部科室，为0表示其他
     * @return id，user_name:用户名
     */
    IPage<SchedulingVo> listUserScheduling(IPage<User> page, String role, Integer departmentId, String startTime);

}
