package com.python.clinic.entity.marketing;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 优惠信息表
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-05
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_preferential")
@ApiModel(value="Preferential对象", description="优惠信息表")
public class Preferential extends Model<Preferential> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "优惠类型，0：会员，1；折扣，2：议价")
    private Integer type;

    @ApiModelProperty(value = "活动/会员卡名称")
    private String activityName;

    @ApiModelProperty(value = "手机号")
    private String phone;

    @ApiModelProperty(value = "价格变化")
    private BigDecimal priceChange;

    @ApiModelProperty(value = "折扣id")
    private Integer discountId;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
