package com.python.clinic.controller.stock;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.python.clinic.entity.stock.Supplier;
import com.python.clinic.service.stock.SupplierService;
import com.python.common.response.CommonResult;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 * 供应商表 前端控制器
 * </p>
 *
 * @author hm
 * @since 2020-05-22
 */
@RestController
@RequestMapping("/supplier")
@Api(tags = "供应商")
public class SupplierController {

    @Autowired
    private SupplierService supplierService;

    @GetMapping("/listSupplier")
    @ApiOperation(value = "获取所有供应商列表",notes = "供应商名称模糊查询")
    public CommonResult listSupplier(@RequestParam(defaultValue = "1") Integer pageNo,
                                     @RequestParam(defaultValue = "10") Integer pageSize,
                                    String supplierName){
        QueryWrapper wrapper = new QueryWrapper();
        wrapper.like(!StringUtils.isEmpty(supplierName),"supplier_name",supplierName);
        wrapper.orderByDesc("status","id");
        IPage<Supplier> page = new Page<>(pageNo,pageSize);
        return CommonResult.success(supplierService.page(page,wrapper));
    }

    @GetMapping("/selectSupplier")
    @ApiOperation(value = "获取可用供应商列表",notes = "用于下拉列表选择")
    public CommonResult selectSupplier(){
        QueryWrapper wrapper = new QueryWrapper();
        wrapper.eq("status",1);
        wrapper.select("id","supplier_name");
        wrapper.orderByDesc("id");
        return CommonResult.success(supplierService.list(wrapper));
    }

    @PostMapping("/saveSupplier")
    @ApiOperation("添加供应商")
    public CommonResult saveSupplier(@RequestBody @Validated Supplier supplier){
        return CommonResult.result(supplierService.save(supplier));
    }

    @PutMapping("/updateSupplier")
    @ApiOperation("修改供应商信息")
    public CommonResult updateSupplier(@RequestBody Supplier supplier){
        return CommonResult.result(supplierService.updateById(supplier));
    }

}
