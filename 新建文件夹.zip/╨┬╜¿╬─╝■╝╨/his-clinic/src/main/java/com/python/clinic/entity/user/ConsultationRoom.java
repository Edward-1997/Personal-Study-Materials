package com.python.clinic.entity.user;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

/**
 * <p>
 * 诊室表
 * </p>
 *
 * @author hm
 * @since 2020-06-03
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_consultation_room")
@ApiModel(value="ConsultationRoom对象", description="诊室表")
public class ConsultationRoom extends Model<ConsultationRoom> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "诊室主键")
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "诊室名称")
    @NotEmpty(message = "诊室名称不能为空")
    private String roomName;

    @ApiModelProperty(value = "诊所id")
    @NotNull(message = "关联诊所不能为空")
    private Integer clinicId;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
