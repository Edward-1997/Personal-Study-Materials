package com.python.clinic.controller.sys;


import com.python.clinic.entity.sys.Calling;
import com.python.clinic.service.sys.CallingService;
import com.python.common.response.CommonResult;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 * 叫号设置 前端控制器
 * </p>
 *
 * @author hm
 * @since 2020-06-05
 */
@RestController
@RequestMapping("/calling")
public class CallingController {

    @Autowired
    private CallingService callingService;

    @PutMapping("/updateCalling")
    @ApiOperation("修改叫号设置")
    public CommonResult updateCall(@RequestBody Calling calling){
        return CommonResult.result(callingService.updateCall(calling));
    }

    @GetMapping("/getCalling")
    @ApiOperation("获取叫号设置")
    public CommonResult getCalling(){
        return CommonResult.success(callingService.getOne(null));
    }

}
