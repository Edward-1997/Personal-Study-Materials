package com.python.clinic.dao.user;

import com.python.clinic.entity.user.ShiftManagement;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.time.LocalTime;
import java.util.Map;

/**
 * <p>
 * 班次管理 Mapper 接口
 * </p>
 *
 * @author hm
 * @since 2020-06-03
 */
public interface ShiftManagementMapper extends BaseMapper<ShiftManagement> {

    /**
     * 通过id查询班次开始结束时间
     * @param id
     * @return
     */
    ShiftManagement getShiftManagementById(Integer id);

}
