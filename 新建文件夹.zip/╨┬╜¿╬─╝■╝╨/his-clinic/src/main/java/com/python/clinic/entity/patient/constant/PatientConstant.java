package com.python.clinic.entity.patient.constant;

/**
 * 患者常量
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/6/1 9:41
 **/
public interface PatientConstant {

    interface Transaction{
        //交易类型：0 消费 1 充值 2 退款 3 退储蓄金
        Integer consume = 0;
        Integer fillCapital = 1;
        Integer refund = 2;
        Integer refundCapital = 3;
    }
}
