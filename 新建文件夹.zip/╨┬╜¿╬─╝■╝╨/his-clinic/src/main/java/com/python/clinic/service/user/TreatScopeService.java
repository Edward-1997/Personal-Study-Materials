package com.python.clinic.service.user;

import com.python.clinic.entity.user.TreatScope;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 理疗范围 服务类
 * </p>
 *
 * @author hm
 * @since 2020-06-02
 */
public interface TreatScopeService extends IService<TreatScope> {

}
