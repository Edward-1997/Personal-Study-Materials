package com.python.clinic.service.sys.impl;

import com.python.clinic.dao.sys.SysConfigMapper;
import com.python.clinic.entity.sys.Calling;
import com.python.clinic.dao.sys.CallingMapper;
import com.python.clinic.entity.sys.SysConfig;
import com.python.clinic.service.sys.CallingService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;

/**
 * <p>
 * 叫号设置 服务实现类
 * </p>
 *
 * @author hm
 * @since 2020-06-05
 */
@Service
public class CallingServiceImpl extends ServiceImpl<CallingMapper, Calling> implements CallingService {

    @Resource
    private CallingMapper callingMapper;
    @Resource
    private SysConfigMapper sysConfigMapper;

    @Override
    @Transactional(propagation= Propagation.REQUIRED,isolation= Isolation.DEFAULT,rollbackFor= RuntimeException.class)
    public boolean updateCall(Calling calling) {
        boolean flag = callingMapper.updateById(calling) > 0;
        if (flag && calling.getEnableCalling()){
            SysConfig sysConfig = new SysConfig();
            sysConfig.setSetRoom(true);
            sysConfigMapper.update(sysConfig,null);
        }
        return flag;
    }
}
