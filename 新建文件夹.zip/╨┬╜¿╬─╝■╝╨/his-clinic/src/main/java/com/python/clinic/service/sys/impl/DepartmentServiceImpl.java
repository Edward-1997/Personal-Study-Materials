package com.python.clinic.service.sys.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.python.clinic.dao.sys.DepartmentUserMapper;
import com.python.clinic.entity.sys.Department;
import com.python.clinic.dao.sys.DepartmentMapper;
import com.python.clinic.entity.sys.DepartmentUser;
import com.python.clinic.entity.user.User;
import com.python.clinic.service.sys.DepartmentService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 * 科室表 服务实现类
 * </p>
 *
 * @author hm
 * @since 2020-06-02
 */
@Service
public class DepartmentServiceImpl extends ServiceImpl<DepartmentMapper, Department> implements DepartmentService {

    @Resource
    private DepartmentMapper departmentMapper;
    @Resource
    private DepartmentUserMapper departmentUserMapper;

    @Override
    public List<Department> listDepartment() {
        return departmentMapper.listDepartment();
    }

    @Override
    @Transactional(propagation= Propagation.REQUIRED,isolation= Isolation.DEFAULT,rollbackFor= RuntimeException.class)
    public boolean saveDepartment(Department department) {
        departmentMapper.insert(department);
        List<User> userList = department.getUserList();
        if (userList != null && !userList.isEmpty()){
            departmentUserMapper.saveBatch(userList,department.getId());
        }
        return true;
    }

    @Override
    @Transactional(propagation= Propagation.REQUIRED,isolation= Isolation.DEFAULT,rollbackFor= RuntimeException.class)
    public boolean updateDepartment(Department department) {
        departmentMapper.updateById(department);
        //先删除科室成员，再添加
        QueryWrapper<DepartmentUser> wrapper = new QueryWrapper();
        wrapper.eq("department_id",department.getId());
        departmentUserMapper.delete(wrapper);
        List<User> userList = department.getUserList();
        if (userList != null && !userList.isEmpty()){
            departmentUserMapper.saveBatch(userList,department.getId());
        }
        return true;
    }

    @Override
    public Department getDepartment(Integer id) {
        Department department = departmentMapper.selectById(id);
        if (department != null){
            department.setUserList(departmentUserMapper.listDepartmentMembers(id));
        }
        return department;
    }
}
