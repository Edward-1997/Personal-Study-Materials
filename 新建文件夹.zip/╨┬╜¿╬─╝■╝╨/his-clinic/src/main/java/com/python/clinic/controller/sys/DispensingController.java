package com.python.clinic.controller.sys;


import com.python.clinic.entity.sys.Dispensing;
import com.python.clinic.service.sys.DispensingService;
import com.python.common.response.CommonResult;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 发药设置 前端控制器
 * </p>
 *
 * @author hm
 * @since 2020-06-05
 */
@RestController
@RequestMapping("/dispensing")
public class DispensingController {

    @Autowired
    private DispensingService dispensingService;

    @GetMapping("/getDispensing")
    @ApiOperation("获取发药设置")
    public CommonResult getDispensing(){
        return CommonResult.success(dispensingService.getOne(null));
    }

    @GetMapping("/updateDispensing")
    @ApiOperation("修改发药设置")
    public CommonResult updateDispensing(@RequestBody Dispensing dispensing){
        return CommonResult.result(dispensingService.updateById(dispensing));
    }

}
