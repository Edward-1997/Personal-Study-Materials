package com.python.clinic.dao.stock;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.python.clinic.entity.stock.EarlyWarning;

/**
 * <p>
 * 库存预警设置 Mapper 接口
 * </p>
 *
 * @author hm
 * @since 2020-05-19
 */
public interface EarlyWarningMapper extends BaseMapper<EarlyWarning> {

}
