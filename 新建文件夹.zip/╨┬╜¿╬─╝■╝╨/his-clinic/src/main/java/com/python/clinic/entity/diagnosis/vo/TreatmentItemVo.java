package com.python.clinic.entity.diagnosis.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/5/26 10:41
 **/
@Data
public class TreatmentItemVo {
    @ApiModelProperty(value = "诊疗项目id")
    private Integer id;

    @ApiModelProperty(value = "项目名称")
    private String itemName;

    @ApiModelProperty(value = "项目类型，0：检查检验 1：治疗理疗 3：其他费用 4：套餐 5：材料商品")
    private Integer type;

    @ApiModelProperty(value = "数量")
    private Integer num;

    @ApiModelProperty(value = "单位")
    private String unit;

    @ApiModelProperty(value = "价格")
    private BigDecimal price;

    @ApiModelProperty(value = "项目状态：0 待执行，1 已执行，2 已退")
    private Integer status;
}
