package com.python.clinic.entity.diagnosis.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/5/25 17:16
 **/
@Data
public class FollowUpRecordsVo {

    @ApiModelProperty(value = "患者id")
    private Integer patientId;
    @ApiModelProperty(value = "患者名称")
    private String patientName;
    @ApiModelProperty(value = "随访状态，0：待执行，1：已执行，2：已终止")
    private Integer status;

}
