package com.python.clinic.entity.marketing.dto;

import com.python.clinic.entity.marketing.DiscountSetting;
import com.python.clinic.entity.marketing.MemberCard;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/6/2 16:16
 **/
@Data
public class MemberCardDto {
    @ApiModelProperty(value = "会员卡基本信息")
    private MemberCard memberCard;

    @ApiModelProperty(value = "患者会员卡折扣列表")
    private List<DiscountSetting> discountSettingList;

    @ApiModelProperty(value = "折扣权益")
    private String discountBenefits;

    @ApiModelProperty(value = "拥有该会员卡的会员人数")
    private Integer memberNum;
}
