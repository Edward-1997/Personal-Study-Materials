package com.python.clinic.controller.user;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.python.clinic.entity.user.ConsultationRoom;
import com.python.clinic.service.user.ConsultationRoomService;
import com.python.clinic.service.user.SchedulingService;
import com.python.common.response.CommonResult;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * <p>
 * 诊室表 前端控制器
 * </p>
 *
 * @author hm
 * @since 2020-06-03
 */
@RestController
@RequestMapping("/consultationRoom")
public class ConsultationRoomController {

    @Autowired
    private ConsultationRoomService consultationRoomService;
    @Autowired
    private SchedulingService schedulingService;


    @GetMapping("/listRoom/{clinicId}")
    @ApiOperation("获取诊室列表")
    public CommonResult listRoom(@PathVariable Integer clinicId){
        return CommonResult.success(consultationRoomService.list(new QueryWrapper<ConsultationRoom>().eq("clinic_id",clinicId)));
    }

    @PostMapping("/saveRoom")
    @ApiOperation("添加诊室")
    public CommonResult saveRoom(@Validated @RequestBody ConsultationRoom consultationRoom){
        //判断名称是否重复
        int count = consultationRoomService.count(new QueryWrapper<ConsultationRoom>().eq("room_name", consultationRoom.getRoomName()));
        if (count > 0){
            return CommonResult.failed("诊室名称重复");
        }
        return CommonResult.result(consultationRoomService.save(consultationRoom));
    }

    @PutMapping("/updateRoom")
    @ApiOperation("修改诊室")
    public CommonResult updateRoom(@RequestBody ConsultationRoom consultationRoom){
        //判断名称是否重复
        QueryWrapper<ConsultationRoom> wrapper = new QueryWrapper<>();
        wrapper.eq("room_name", consultationRoom.getRoomName()).ne("id",consultationRoom.getId());
        int count = consultationRoomService.count(wrapper);
        if (count > 0){
            return CommonResult.failed("诊室名称重复");
        }
        return CommonResult.result(consultationRoomService.updateById(consultationRoom));
    }

    @DeleteMapping("/deleteRoom/{id}")
    @ApiOperation(value = "删除诊室名称")
    public CommonResult deleteRoom(@PathVariable Integer id){
        //判断是否有医生排班该诊室（不考虑当前时间以前的数据）
        boolean flag = schedulingService.getNowAfterSchedulingCountByRoomId(id);
        if (flag) {
            return CommonResult.failed("该诊室已有医生排班，删除诊室将导致无法叫号");
        }
        return CommonResult.result(consultationRoomService.removeById(id));
    }

}
