package com.python.clinic.entity.stock;

import java.math.BigDecimal;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import java.util.List;

import com.python.clinic.entity.stock.vo.StockLogVo;
import com.python.clinic.entity.sys.Clinic;
import com.python.clinic.entity.user.User;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 盘点表
 * </p>
 *
 * @author hm
 * @since 2020-05-27
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_inventory")
@ApiModel(value="Inventory对象", description="盘点表")
public class Inventory extends Model<Inventory> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "盘点人id")
    private Integer createId;

    @ApiModelProperty(value = "创建时间")
    private Date createTime;

    @ApiModelProperty(value = "盘点门店")
    private Integer clinicId;

    @ApiModelProperty(value = "品种")
    private Integer kindCount;

    @ApiModelProperty(value = "盈亏数量")
    private Double numChange;

    @ApiModelProperty(value = "盈亏总金额(进价)")
    private BigDecimal totalCostPriceChange;

    @ApiModelProperty(value = "盈亏总金额(售价)")
    private BigDecimal totalPriceChange;

    @ApiModelProperty(value = "盘点单号")
    private String orderNo;

    @ApiModelProperty(value = "备注")
    private String remark;

    @ApiModelProperty(value = "盘点类型 0：全量盘点，1：临时盘点")
    private Integer type;

    @TableField(exist = false)
    private User creator;

    @TableField(exist = false)
    private Clinic clinic;

    @TableField(exist = false)
    private List<InventoryDetails> detailsList;

    @TableField(exist = false)
    private List<StockLogVo> logList;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
