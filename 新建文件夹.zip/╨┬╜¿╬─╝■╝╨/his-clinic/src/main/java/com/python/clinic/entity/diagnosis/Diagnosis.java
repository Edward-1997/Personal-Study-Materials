package com.python.clinic.entity.diagnosis;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 门诊表
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-22
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_diagnosis")
@ApiModel(value="Diagnosis对象", description="门诊表")
public class Diagnosis extends Model<Diagnosis> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键")
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "患者id")
    private Integer patientId;

    @ApiModelProperty(value = "主诉")
    private String complain;

    @ApiModelProperty(value = "现病史")
    private String hpi;

    @ApiModelProperty(value = "现病史图片")
    private String hpiPicture;

    @ApiModelProperty(value = "既往史")
    private String pastHistory;

    @ApiModelProperty(value = "体格检查")
    private String physicalExamination;

    @ApiModelProperty(value = "诊断")
    private String diagnosis;

    @ApiModelProperty(value = "开单人")
    private Integer drawer;

    @ApiModelProperty(value = "开单时间")
    private Date diagnosisTime;

    @ApiModelProperty(value = "总金额")
    private BigDecimal totalPrice;

    @ApiModelProperty(value = "类型，为门诊时才加入就诊记录  0：门诊   1：护士开单")
    private Integer type;

    @ApiModelProperty(value = "状态")
    private Integer status;

    @ApiModelProperty(value = "医嘱")
    private String doctorAdvice;

    @ApiModelProperty(value = "挂号费")
    private BigDecimal registrationFee;

    @ApiModelProperty(value = "就诊次数")
    private Integer visitNumber;

    @ApiModelProperty(value = "就诊号")
    private String diagnosisNo;

    @ApiModelProperty(value = "执行状态")
    private Integer executeStatus;

    @ApiModelProperty(value = "挂号费状态，0：未交，1：已交")
    private Integer registrationFeeStatus;

    @ApiModelProperty(value = "诊所id")
    private Integer clinicId;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
