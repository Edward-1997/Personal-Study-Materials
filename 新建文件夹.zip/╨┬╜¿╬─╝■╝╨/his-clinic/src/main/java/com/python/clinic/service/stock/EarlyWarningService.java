package com.python.clinic.service.stock;


import com.baomidou.mybatisplus.extension.service.IService;
import com.python.clinic.entity.stock.EarlyWarning;

/**
 * <p>
 * 库存预警设置 服务类
 * </p>
 *
 * @author hm
 * @since 2020-05-19
 */
public interface EarlyWarningService extends IService<EarlyWarning> {

    /**
     * 获取商品库存信息预警设置
     * @param goodsId 商品id
     * @param clinicId 诊所id
     * @return
     */
    //EarlyWarning getEarlyWarning(Integer goodsId,Integer clinicId);

}
