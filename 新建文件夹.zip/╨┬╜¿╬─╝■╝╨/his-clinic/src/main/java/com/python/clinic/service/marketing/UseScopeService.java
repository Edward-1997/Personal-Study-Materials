package com.python.clinic.service.marketing;

import com.python.clinic.entity.marketing.UseScope;
import com.baomidou.mybatisplus.extension.service.IService;
import com.python.common.response.CommonResult;

import java.util.List;

/**
 * <p>
 * 使用范围表 服务类
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-05
 */
public interface UseScopeService extends IService<UseScope> {

    /**
     * 根据查询条件获取使用范围列表,包括例外列表
     * @author tanglong
     * @param useScope 查询条件
     * @return java.util.List<com.python.clinic.entity.marketing.UseScope>
     * @since 2020/6/6 11:31
     **/
    List<UseScope> getUseScopeList(UseScope useScope);

    /**
     * 新增使用范围
     * @author tanglong
     * @return com.python.common.response.CommonResult
     * @since 2020/6/6 11:18
     **/
    CommonResult insertUseScope(UseScope useScope);

    /**
     * 删除使用范围
     * @author tanglong
     * @return com.python.common.response.CommonResult
     * @since 2020/6/6 11:19
     **/
    CommonResult deleteUseScope(UseScope useScope);

    /**
     * 校验使用范围是否冲突
     * @author tanglong
     * @param useScopeList 校验条件
     * @return com.python.common.response.CommonResult
     * @since 2020/6/10 10:49
     **/
    CommonResult checkUseScope(List<UseScope> useScopeList);
}
