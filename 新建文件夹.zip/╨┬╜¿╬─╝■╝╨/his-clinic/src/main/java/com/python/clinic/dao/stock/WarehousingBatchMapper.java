package com.python.clinic.dao.stock;

import com.python.clinic.entity.stock.WarehousingBatch;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.python.clinic.entity.stock.vo.GoodsStockVo;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 入库批次表 Mapper 接口
 * </p>
 *
 * @author hm
 * @since 2020-05-22
 */
public interface WarehousingBatchMapper extends BaseMapper<WarehousingBatch> {

    //int saveBatch(@Param("list")List<WarehousingBatch> list,@Param("warehousingId")Integer warehousingId);

    /**
     * 根据查询某入库批次库存以及包装数量
     * @param id
     * @return packageCount:整装库存，pieceCount:散装库存，packagePrice:整装进价，
     *         preparation:制剂，medicineCadn:通用名，packageUnit:整装单位，preparationUnit:散装单位
     */
    GoodsStockVo getGoodsStockAndPreparation(@Param("id")Integer id);

    /**
     * 查询某商品剩余库存
     * @param goodsId
     * @return  packageCount:整装库存，pieceCount:散装库存，preparation:制剂，medicineCadn:通用名
     */
    GoodsStockVo getGoodsStockCount(@Param("goodsId")Integer goodsId);

    /**
     * 根据id查询入库批次
     * @param id
     * @param specifyBatch
     * @return
     */
    WarehousingBatch getWarehousingBatchById(@Param("id")Integer id,@Param("specifyBatch")Boolean specifyBatch);

    /**
     * 查询商品最新入库批次
     * @param goodsId 商品id
     * @return
     */
    Integer getLatelyBatchIdByGoodsId(@Param("goodsId")Integer goodsId);

}
