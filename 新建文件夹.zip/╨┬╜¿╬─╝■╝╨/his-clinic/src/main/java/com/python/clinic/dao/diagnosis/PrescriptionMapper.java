package com.python.clinic.dao.diagnosis;

import com.python.clinic.entity.diagnosis.Prescription;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 处方 Mapper 接口
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-26
 */
public interface PrescriptionMapper extends BaseMapper<Prescription> {

}
