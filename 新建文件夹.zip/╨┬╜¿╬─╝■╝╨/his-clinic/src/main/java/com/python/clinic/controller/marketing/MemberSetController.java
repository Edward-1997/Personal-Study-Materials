package com.python.clinic.controller.marketing;


import com.python.clinic.entity.marketing.MemberSet;
import com.python.clinic.service.marketing.MemberSetService;
import com.python.common.response.CommonResult;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * 会员卡设置表 前端控制器
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-20
 */
@RestController
@RequestMapping("/member_set")
public class MemberSetController {

    @Autowired
    private MemberSetService memberSetService;

    @ApiOperation(value = "会员卡积分设置",notes = "获取最新一次积分规则设置")
    @GetMapping("/recent_rule")
    public CommonResult getRecentRuleSet(){
        Map<String,Object> map = new HashMap<>();
        map.put("ruleSet",memberSetService.getRecentRuleSet());

        return CommonResult.success(map,"获取积分设置");
    }

    @ApiOperation(value = "修改会员积分设置",notes = "传入会员卡设置对象，完成修改会员设置")
    @PutMapping("/rule")
    public CommonResult updateMemberSet(@RequestBody MemberSet memberSet){
        return memberSetService.updateMemberSet(memberSet);
    }

    @ApiOperation(value ="新增会员积分设置",notes = "传入会员卡设置对象，完成新增会员卡设置")
    @PostMapping("/rule")
    public CommonResult insertMemberSet(@RequestBody MemberSet memberSet){
        return memberSetService.insertMemberSet(memberSet);
    }
}
