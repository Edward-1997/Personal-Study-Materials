package com.python.clinic.entity.marketing;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 患者优惠券表
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-05
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_patient_coupon")
@ApiModel(value="PatientCoupon对象", description="患者优惠券表")
public class PatientCoupon extends Model<PatientCoupon> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "患者id")
    private Integer patientId;

    @ApiModelProperty(value = "优惠券id")
    private Integer couponId;

    @ApiModelProperty(value = "领取数量")
    private Integer receiveNum;

    @ApiModelProperty(value = "使用数量")
    private Integer useNum;


    @Override
    protected Serializable pkVal() {
        return this.patientId;
    }

}
