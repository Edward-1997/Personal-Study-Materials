package com.python.clinic.dao.diagnosis;

import com.python.clinic.entity.diagnosis.PrescriptionDetails;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 处方详情表 Mapper 接口
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-26
 */
public interface PrescriptionDetailsMapper extends BaseMapper<PrescriptionDetails> {

}
