package com.python.clinic.utils;

import java.util.Calendar;
import java.util.Date;

/**
 * 编号生成
 * @author hm
 */
public class CodeUtil {

    public static String getOrderCode(String type){
        Calendar cale = Calendar.getInstance();
        String code = cale.get(Calendar.YEAR)+""+String.format("%02d", (cale.get(Calendar.MONTH)+1))
                +""+String.format("%02d", cale.get(Calendar.DATE))+(int)((Math.random()*9+1)*10000);
        return "type"+code;
    }

    public static String getOtherCode(){
        return ((Math.random()*9+1)*10000000)+"";
    }

    public static Integer getPrimaryKey(){
        return Integer.valueOf(System.currentTimeMillis()/1000+"");
    }
}
