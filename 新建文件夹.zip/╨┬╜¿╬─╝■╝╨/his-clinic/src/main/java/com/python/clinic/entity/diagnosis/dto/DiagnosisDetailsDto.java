package com.python.clinic.entity.diagnosis.dto;

import com.python.clinic.entity.diagnosis.Diagnosis;
import com.python.clinic.entity.diagnosis.Prescription;
import com.python.clinic.entity.diagnosis.vo.TreatmentItemVo;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * 门诊详情
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/5/26 10:27
 **/
@Data
public class DiagnosisDetailsDto {
    //门诊内容
    @ApiModelProperty(value = "储存门诊详情内容，其中包含医嘱事项")
    private Diagnosis diagnosis;

    //治疗项目
    @ApiModelProperty(value = "诊疗项目，包含治疗项目和材料商品")
    private List<TreatmentItemVo> treatmentItem;

    //处方
    @ApiModelProperty(value = "包含处方基本内容和处方详细细节")
    private List<Prescription> prescription;
}
