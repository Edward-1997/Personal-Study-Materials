package com.python.clinic.controller.diagnosis;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.python.clinic.entity.diagnosis.FollowUpTemplate;
import com.python.clinic.entity.diagnosis.constant.DiagnosisConstant;
import com.python.clinic.entity.diagnosis.dto.FollowUpTemplateDto;
import com.python.clinic.service.diagnosis.FollowUpTemplateService;
import com.python.common.response.CommonResult;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * 随访模板 前端控制器
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-28
 */
@RestController
@RequestMapping("/revisit_template")
public class FollowUpTemplateController {

    @Autowired
    private FollowUpTemplateService followUpTemplateService;

    @ApiOperation(value = "获取随访目标模板",notes = "分页查询，默认一页10条记录，pageSize:数量，pageNum:起始位置")
    @GetMapping("/target/list")
    public CommonResult getTargetTemplateList(@RequestParam(defaultValue = "1") Integer pageNum,
                                        @RequestParam(defaultValue = "10") Integer pageSize){
        FollowUpTemplate followUpTemplate = new FollowUpTemplate();
        followUpTemplate.setType(DiagnosisConstant.REVISIT_TARGET_TEMPLATE_TYPE);

        IPage<FollowUpTemplateDto> templateList = followUpTemplateService
                .getTemplateList(new Page<>(pageNum, pageSize),followUpTemplate);

        Map<String,Object> map = new HashMap<>();
        map.put("targetTemplateList",templateList);
        return CommonResult.success(map);
    }

    @ApiOperation(value = "获取随访目标模板",notes = "分页查询，默认一页10条记录，pageSize:数量，pageNum:起始位置")
    @GetMapping("/result/list")
    public CommonResult getResultTemplateList(@RequestParam(defaultValue = "1") Integer pageNum,
                                              @RequestParam(defaultValue = "10") Integer pageSize){
        FollowUpTemplate followUpTemplate = new FollowUpTemplate();
        followUpTemplate.setType(DiagnosisConstant.REVISIT_RESULT_TEMPLATE_TYPE);

        IPage<FollowUpTemplateDto> templateList = followUpTemplateService
                .getTemplateList(new Page<>(pageNum, pageSize),followUpTemplate);
        Map<String,Object> map = new HashMap<>();
        map.put("resultTemplateList",templateList);
        return CommonResult.success(map);
    }


    @ApiOperation(value = "修改随访模板",notes = "传入随访模板对象，包括id，模板名称（templateName），内容（content）")
    @PutMapping("/update")
    public CommonResult updateRevisitTemplate(@RequestBody FollowUpTemplate followUpTemplate){
        if(followUpTemplateService.updateTemplate(followUpTemplate)){
            return CommonResult.success(null,"修改成功");
        }
        return CommonResult.failed("修改失败");
    }

    @ApiOperation(value = "删除随访目标",notes = "传入随访目标模板id，完成删除操作")
    @DeleteMapping("/target/{id}")
    public CommonResult deleteRevisitTemplate(@PathVariable Integer id){
        if(followUpTemplateService.deleteTemplate(id)){
            return CommonResult.success(null,"修改成功");
        }
        return CommonResult.failed("修改失败");
    }
}
