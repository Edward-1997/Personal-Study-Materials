package com.python.clinic.service.user.impl;

import com.python.clinic.entity.user.TreatScope;
import com.python.clinic.dao.user.TreatScopeMapper;
import com.python.clinic.service.user.TreatScopeService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 理疗范围 服务实现类
 * </p>
 *
 * @author hm
 * @since 2020-06-02
 */
@Service
public class TreatScopeServiceImpl extends ServiceImpl<TreatScopeMapper, TreatScope> implements TreatScopeService {

}
