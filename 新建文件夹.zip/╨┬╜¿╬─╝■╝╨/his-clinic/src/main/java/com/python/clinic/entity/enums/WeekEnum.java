package com.python.clinic.entity.enums;

import com.baomidou.mybatisplus.core.enums.IEnum;
import com.fasterxml.jackson.annotation.JsonValue;

/**
 * @author hm
 */
public enum WeekEnum implements IEnum<Integer> {

    //星期一
    MON(1,"周一"),
    //星期二
    TUSE(2,"周二"),
    //星期三
    WED(3,"周三"),
    //星期四
    THUR(4,"周四"),
    //星期五
    FRI(5,"周五"),
    //星期六
    SAT(6,"周六"),
    //星期日
    SUN(7,"周日");

    private Integer value;
    private String desc;

    WeekEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public static WeekEnum getByValue(Integer value){
        WeekEnum[] weekEnums = WeekEnum.values();
        for(WeekEnum weekEnum : weekEnums){
            if(weekEnum.getValue().equals(value)){
                return weekEnum;
            }
        }
        return null;
    }

    @Override
    public Integer getValue() {
        return this.value;
    }

    @JsonValue
    public String getDesc() {
        return this.desc;
    }
}
