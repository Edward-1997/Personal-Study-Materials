package com.python.clinic.dao.sys;

import com.python.clinic.entity.sys.Calling;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 叫号设置 Mapper 接口
 * </p>
 *
 * @author hm
 * @since 2020-06-05
 */
public interface CallingMapper extends BaseMapper<Calling> {

}
