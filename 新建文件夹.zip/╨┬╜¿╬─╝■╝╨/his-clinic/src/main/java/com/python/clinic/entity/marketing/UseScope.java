package com.python.clinic.entity.marketing;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import java.util.List;

import com.python.clinic.entity.stock.Goods;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 使用范围表
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-05
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_use_scope")
@ApiModel(value="UseScope对象", description="使用范围表")
public class UseScope extends Model<UseScope> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "关联id，根据类型判断关联表")
    private Integer relationId;

    @ApiModelProperty(value = "类型，0：满减反，1：优惠券")
    private Integer type;

    @ApiModelProperty(value = "商品类型")
    private Integer goodsType;

    @ApiModelProperty(value = "商品子类型")
    private Integer goodsSubType;

    @ApiModelProperty(value = "商品id")
    private Integer goodsId;

    @ApiModelProperty(value = "商品名称")
    @TableField(exist = false)
    private String name;

    @ApiModelProperty(value = "例外商品列表")
    @TableField(exist = false)
    private List<Goods> exceptionGoodsList;

    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
