package com.python.clinic.controller.diagnosis;


import com.python.clinic.entity.diagnosis.ItemImplement;
import com.python.clinic.service.diagnosis.ItemImplementService;
import com.python.common.response.CommonResult;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 治疗项目执行记录表 前端控制器
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-28
 */
@RestController
@RequestMapping("/item_implement")
public class ItemImplementController {
    @Autowired
    private ItemImplementService itemImplementService;

    @ApiOperation(value = "获取患者治疗执行记录/患者档案",notes = "传入治疗理疗项目id，完成查询")
    @GetMapping("/records/{itemId}")
    public CommonResult getExecutionRecords(@PathVariable Integer itemId){
        List<ItemImplement> records = itemImplementService.getItemImplementList(itemId);
        Map<String,Object> map = new HashMap<>(1);
        map.put("executionRecords",records);
        return CommonResult.success(map);
    }
}
