package com.python.clinic.entity.user.dto;

import com.python.clinic.entity.user.User;
import com.python.clinic.entity.user.UserInfo;
import com.python.clinic.entity.user.UserTags;
import com.python.clinic.entity.user.UserTitle;
import lombok.Data;

import java.util.List;

/**
 * @author hm
 */
@Data
public class UserDTO {

    private User user;

    private UserInfo userInfo;

    private List<UserTitle> userTitleList;

    private List<UserTags> userTagsList;

}
