package com.python.clinic.controller.sys;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 设备类别表 前端控制器
 * </p>
 *
 * @author hm
 * @since 2020-06-02
 */
@RestController
@RequestMapping("/equipment-type")
public class EquipmentTypeController {

}
