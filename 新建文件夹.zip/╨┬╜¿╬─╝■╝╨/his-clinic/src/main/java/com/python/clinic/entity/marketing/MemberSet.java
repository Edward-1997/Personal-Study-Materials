package com.python.clinic.entity.marketing;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 会员卡设置表
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-20
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_member_set")
@ApiModel(value="MemberSet对象", description="会员卡设置表")
public class MemberSet extends Model<MemberSet> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "积分设置主键")
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "积分交换率")
    private Integer pointsExchangeRat;

    @ApiModelProperty(value = "积分清零月份")
    private Integer pointsClearMonth;

    @ApiModelProperty(value = "积分清零天数")
    private Integer pointsClearDay;

    @ApiModelProperty(value = "密码支付，0：未开启，1：已开启")
    private Integer passwordPay;


    @Override
    protected Serializable pkVal() {
        return null;
    }

}
