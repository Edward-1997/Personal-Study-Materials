package com.python.clinic.controller.marketing;


import com.python.clinic.service.marketing.GiftCouponService;
import com.python.common.response.CommonResult;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 * 优惠赠品表 前端控制器
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-05
 */
@RestController
@RequestMapping("/gift_coupon")
public class GiftCouponController {

}
