package com.python.clinic.service.marketing;

import com.python.clinic.entity.marketing.DiscountStore;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 折扣门店表 服务类
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-02
 */
public interface DiscountStoreService extends IService<DiscountStore> {

}
