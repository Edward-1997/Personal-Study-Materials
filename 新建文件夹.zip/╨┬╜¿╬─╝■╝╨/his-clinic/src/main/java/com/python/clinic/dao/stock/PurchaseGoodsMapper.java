package com.python.clinic.dao.stock;

import com.python.clinic.entity.stock.PurchaseGoods;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 采购药品/物资表 Mapper 接口
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-21
 */
public interface PurchaseGoodsMapper extends BaseMapper<PurchaseGoods> {

    /**
     * 批量插入采购药品
     * @param list
     * @return
     */
    int saveBatch(@Param("list")List<PurchaseGoods> list);

}
