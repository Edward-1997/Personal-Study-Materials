package com.python.clinic.entity.diagnosis.constant;

/**
 * 门诊常量
 * @author tanglong
 * @version 1.0
 * @since 2020/5/26 15:58
 **/
public interface DiagnosisConstant {

    //治疗项目中诊疗项目单位
    String TREATMENT_ITEM_UNIT = "次";
    //门诊项目类型 诊疗项目：0 ，材料商品：1
    Integer TREATMENT_ITEM_TYPE = 0;
    //0：检查检验 1：治疗理疗 2：其他费用 3：套餐 4：材料商品
    interface ItemType{
        Integer CHECK_ITEM = 0;
        Integer TREATMENT_ITEM = 1;
        Integer OTHER = 2;
        Integer MEAL = 3;
        Integer MATERIAL_GOODS = 4;
    }

    //随访目标模板类型
    Integer REVISIT_TARGET_TEMPLATE_TYPE = 0;
    //随访结果模板类型
    Integer REVISIT_RESULT_TEMPLATE_TYPE = 1;
}
