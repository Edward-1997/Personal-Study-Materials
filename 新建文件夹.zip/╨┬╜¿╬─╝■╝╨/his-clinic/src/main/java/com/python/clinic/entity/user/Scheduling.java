package com.python.clinic.entity.user;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 排班详情表
 * </p>
 *
 * @author hm
 * @since 2020-06-05
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_scheduling")
@ApiModel(value="Scheduling对象", description="排班详情表")
public class Scheduling extends Model<Scheduling> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "排班主键")
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "班次id")
    private Integer shiftId;

    @ApiModelProperty(value = "号源量")
    private Integer number;

    @ApiModelProperty(value = "剩余号源量")
    private Integer surplusNumber;

    @ApiModelProperty(value = "诊室id")
    private Integer roomId;

    @ApiModelProperty(value = "用户id")
    private Integer userId;

    @ApiModelProperty(value = "排班日期")
    private Date schedulingDate;

    @ApiModelProperty(value = "类型，0：医生排班，1：员工排班")
    private Integer type;

    @ApiModelProperty(value = "诊所id")
    private Integer clinicId;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
