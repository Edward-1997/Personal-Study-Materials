package com.python.clinic.service.patient;


import com.baomidou.mybatisplus.extension.service.IService;
import com.python.clinic.entity.patient.IntegralFlow;
import com.python.clinic.entity.patient.PatientMemberCard;
import com.python.clinic.entity.patient.TransactionFlow;
import com.python.clinic.entity.patient.vo.MemberCardInfoVo;
import com.python.common.response.CommonResult;

/**
 * <p>
 * 患者会员卡 服务类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-20
 */
public interface PatientMemberCardService extends IService<PatientMemberCard> {

    /**
     * 获取某种会员卡下所有的患者数量
     * @author tanglong
     * @param cardId 会员卡id
     * @return java.lang.Integer
     * @since 2020/6/4 9:31
     **/
    Integer getStatisticsMember(Integer cardId);

    /**
     * 查询患者会员卡信息，如果无返回null
     * @param patientId 患者id
     * @return com.python.common.response.CommonResult
     * @since 2020/5/22 9:27
     **/
    CommonResult getMemberCard(Integer patientId);

    /**
     * 根据会员卡id删除会员卡
     * @author tanglong
     * @return com.python.common.response.CommonResult
     * @since 2020/5/29 9:52
     **/
    CommonResult deletePatientMemberCard(Integer id);

    /**
     * 查询会员卡列表
     * @author tanglong
     * @return com.python.common.response.CommonResult
     * @since 2020/5/23 10:38
     **/
    CommonResult selectMemberList(String orderFiled,Integer orderType,Integer pageSize,Integer pageNum);

    /**
     * 修改患者会员信息
     * @author tanglong
     * @return com.python.common.response.CommonResult
     * @since 2020/5/23 14:53
     **/
    CommonResult updateMemberInfo(MemberCardInfoVo info);

    /**
     * 新增会员
     * @author tanglong
     * @return com.python.common.response.CommonResult
     * @since 2020/5/23 14:53
     **/
    CommonResult insertMemberInfo(MemberCardInfoVo info);

    /**
     * 更新用户剩余本金和剩余赠金，并新增一条交易流水
     * @author tanglong
     * @param record
     * @return com.python.common.response.CommonResult
     * @since 2020/5/25 11:08
     * @see TransactionFlow
     **/
    CommonResult updateMemberCapital(TransactionFlow record);

    /**
     * 更新用户当前积分和累计积分，并新增一条积分流水流水
     * @author tanglong
     * @param record
     * @return com.python.common.response.CommonResult
     * @since 2020/5/25 11:08
     * @see TransactionFlow
     **/
    CommonResult updateMemberIntegral(IntegralFlow record);
}
