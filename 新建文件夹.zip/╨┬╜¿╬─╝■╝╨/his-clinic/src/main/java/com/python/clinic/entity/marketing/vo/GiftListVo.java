package com.python.clinic.entity.marketing.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/6/8 9:58
 **/
@Data
public class GiftListVo {

    @ApiModelProperty(value = "满减返id")
    private Integer id;
    @ApiModelProperty(name = "满减返名称")
    private String name;
    @ApiModelProperty(name = "状态")
    private Integer status;
    @ApiModelProperty(name="活动详情")
    private String details;
    @ApiModelProperty(name = "收费订单")
    private Integer orderCount;
    @ApiModelProperty(name = "参与客户")
    private Integer patientCount;
    @ApiModelProperty(name = "实付金额")
    private BigDecimal orderTotalAmount;
}
