package com.python.clinic.dao.stock;

import com.python.clinic.entity.stock.InventoryBatch;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 盘点批次表 Mapper 接口
 * </p>
 *
 * @author hm
 * @since 2020-05-27
 */
public interface InventoryBatchMapper extends BaseMapper<InventoryBatch> {

    /**
     * 根据盘点详情查询盘点批次
     * @param inventoryDetailsId 出库详情id
     * @param specifyBatch   是否指定批次
     * @return
     */
    List<Map<String,Object>> listInventoryBatchByInventoryDetailsId(@Param("inventoryDetailsId")Integer inventoryDetailsId, @Param("specifyBatch")Boolean specifyBatch);

}
