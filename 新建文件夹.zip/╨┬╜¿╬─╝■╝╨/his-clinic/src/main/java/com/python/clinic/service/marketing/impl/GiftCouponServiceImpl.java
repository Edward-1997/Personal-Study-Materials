package com.python.clinic.service.marketing.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.python.clinic.entity.marketing.Coupon;
import com.python.clinic.entity.marketing.GiftCoupon;
import com.python.clinic.dao.marketing.GiftCouponMapper;
import com.python.clinic.entity.marketing.dto.CouponDetailsDto;
import com.python.clinic.entity.marketing.dto.GiftCouponDto;
import com.python.clinic.entity.marketing.dto.GiftGoodDto;
import com.python.clinic.service.marketing.CouponService;
import com.python.clinic.service.marketing.GiftCouponService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.python.clinic.service.stock.GoodsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 优惠赠品表 服务实现类
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-05
 */
@Service
public class GiftCouponServiceImpl extends ServiceImpl<GiftCouponMapper, GiftCoupon> implements GiftCouponService {

    @Autowired
    private GiftCouponMapper giftCouponMapper;
    @Autowired
    private GoodsService goodsService;
    @Autowired
    private CouponService couponService;

    @Override
    public Map<String,Object> getGiftCouponDetailsList(GiftCoupon giftCoupon) {
        List<GiftCoupon> giftCoupons = giftCouponMapper.selectList(new QueryWrapper<>(giftCoupon));

        List<GiftCouponDto> giftCouponDto = new ArrayList<>();
        List<GiftGoodDto> giftGoodDto = new ArrayList<>();

        for(GiftCoupon gift : giftCoupons){
            if(gift.getRelationType() == 0){
                //关联类型是优惠券
                GiftCouponDto dto = new GiftCouponDto();

                Coupon coupon = couponService.getById(gift.getRelationId());
                dto.setId(coupon.getId());
                dto.setStatus(coupon.getStatus());
                dto.setCount(gift.getCount());
                dto.setName(coupon.getCouponName());

                giftCouponDto.add(dto);
            }else{
                //关联的是赠品
                GiftGoodDto dto = new GiftGoodDto();
                dto.setCount(gift.getCount());
                dto.setGoodsId(gift.getRelationId());
                dto.setGoods(goodsService.getById(gift.getRelationId()));

                giftGoodDto.add(dto);
            }
        }

        Map<String,Object> map = new HashMap<>();
        map.put("giftCouponDto",giftCouponDto);
        map.put("giftGoodDto",giftGoodDto);
        return map;
    }
}
