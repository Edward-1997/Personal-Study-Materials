package com.python.clinic.controller.user;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.python.clinic.entity.user.RegistrationFee;
import com.python.clinic.service.user.RegistrationFeeService;
import com.python.common.response.CommonResult;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 * 挂号费表 前端控制器
 * </p>
 *
 * @author hm
 * @since 2020-06-06
 */
@RestController
@RequestMapping("/registrationFee")
public class RegistrationFeeController {

    @Autowired
    private RegistrationFeeService registrationFeeService;

    @GetMapping("/listDoctorRegistrationFee")
    @ApiOperation("获取医生挂号费")
    public CommonResult listDoctorRegistrationFee(@RequestParam(defaultValue = "1") Integer pageNum,
                                                  @RequestParam(defaultValue = "10") Integer pageSize,
                                                  Integer departmentId,String userName){
        IPage<RegistrationFee> page = new Page<>(pageNum,pageSize);
        return CommonResult.success(registrationFeeService.listDoctorRegistrationFee(page,departmentId,userName));
    }

    @PostMapping("/saveOrUpdateRegistrationFee")
    @ApiOperation(value = "添加或修改挂号费",notes = "id==null为添加，!=null为修改")
    public CommonResult saveOrUpdateRegistrationFee(@RequestBody RegistrationFee registrationFee){
        return CommonResult.result(registrationFeeService.saveOrUpdateRegistrationFee(registrationFee));
    }

    @DeleteMapping("/useDefaultPrice/{id}")
    @ApiOperation("使用默认价")
    public CommonResult useDefaultPrice(@PathVariable String id){
        return CommonResult.result(registrationFeeService.removeById(id));
    }

}
