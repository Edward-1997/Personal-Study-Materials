package com.python.clinic.controller.stock;


import com.python.clinic.entity.stock.WarehousingBatch;
import com.python.clinic.service.stock.WarehousingBatchService;
import com.python.common.response.CommonResult;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 入库批次表 前端控制器
 * </p>
 *
 * @author hm
 * @since 2020-05-22
 */
@RestController
@RequestMapping("/warehousing-batch")
public class WarehousingBatchController {

    @Autowired
    private WarehousingBatchService batchService;

    @PutMapping("/updateBatch")
    @ApiOperation("修改入库批次信息")
    public CommonResult updateBatch(@RequestBody WarehousingBatch batch){
        return CommonResult.result(batchService.updateById(batch));
    }

}
