package com.python.clinic.service.patient;


import com.baomidou.mybatisplus.extension.service.IService;
import com.python.clinic.entity.patient.PatientTag;
import com.python.common.response.CommonResult;

/**
 * <p>
 * 患者标签表 服务类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-20
 */
public interface PatientTagService extends IService<PatientTag> {

    /**
     * 给患者添加标签
     * @return com.python.common.response.CommonResult
     * @since 2020/5/20 18:44
     * @see
     **/
    CommonResult insertPatientTag(PatientTag patientTag);

    /**
     * 删除患者标签表中的标签，不删除总标签表里的内容
     * @return com.python.common.response.CommonResult
     * @since 2020/5/20 18:44
     * @see
     **/
    CommonResult deletePatientTag(PatientTag patientTag);

    /**
     * 获得患者标签
     * @author tanglong
     * @param patientId 患者id值
     * @return com.python.common.response.CommonResult
     * @since 2020/5/21 14:02
     * @see
     **/
    CommonResult getPatientTags(Integer patientId);
}
