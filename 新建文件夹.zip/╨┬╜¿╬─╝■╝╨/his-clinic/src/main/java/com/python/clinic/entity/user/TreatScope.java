package com.python.clinic.entity.user;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 理疗范围
 * </p>
 *
 * @author hm
 * @since 2020-06-02
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_treat_scope")
@ApiModel(value="TreatScope对象", description="理疗范围")
public class TreatScope extends Model<TreatScope> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "用户信息id")
    private Integer userInfoId;

    @ApiModelProperty(value = "理疗id")
    private Integer treatmentId;


    @Override
    protected Serializable pkVal() {
        return null;
    }

}
