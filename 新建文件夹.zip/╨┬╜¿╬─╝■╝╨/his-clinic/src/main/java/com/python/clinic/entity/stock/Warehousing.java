package com.python.clinic.entity.stock;

import java.math.BigDecimal;

import com.baomidou.mybatisplus.annotation.*;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.util.Date;
import java.io.Serializable;

import com.python.clinic.entity.sys.Clinic;
import com.python.clinic.entity.user.User;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 入库表
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-22
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_warehousing")
@ApiModel(value="Warehousing对象", description="入库表")
public class Warehousing extends Model<Warehousing> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "入库人id")
    private Integer createId;

    @ApiModelProperty(value = "入库时间")
    @TableField(value = "create_time" , fill = FieldFill.INSERT)
    private Date createTime;

    @ApiModelProperty(value = "诊所id")
    private Integer clinicId;

    @ApiModelProperty(value = "供应商id，供应商id为null时表示盘点入库")
    private Integer supplierId;

    @ApiModelProperty(value = "入库单号")
    private String orderNo;

    @ApiModelProperty(value = "随货单号")
    private String followGoodsNo;

    @ApiModelProperty(value = "状态，1：已入库")
    private Integer status;

    @ApiModelProperty(value = "结算状态")
    private Integer settlementStatus;

    @ApiModelProperty(value = "种类")
    private Integer kindCount;

    @ApiModelProperty(value = "总数量")
    private Double sum;

    @ApiModelProperty(value = "售价合计")
    private BigDecimal totalPrice;

    @ApiModelProperty(value = "含税金额")
    private BigDecimal taxAmount;

    @ApiModelProperty(value = "不含税金额")
    private BigDecimal noTaxAmount;

    @TableField(exist = false)
    private User creator;

    @TableField(exist = false)
    private Clinic clinic;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
