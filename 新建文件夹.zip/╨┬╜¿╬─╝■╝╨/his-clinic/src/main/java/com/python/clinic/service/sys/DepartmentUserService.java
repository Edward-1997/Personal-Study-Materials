package com.python.clinic.service.sys;

import com.python.clinic.entity.sys.DepartmentUser;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 科室成员表 服务类
 * </p>
 *
 * @author hm
 * @since 2020-06-02
 */
public interface DepartmentUserService extends IService<DepartmentUser> {

}
