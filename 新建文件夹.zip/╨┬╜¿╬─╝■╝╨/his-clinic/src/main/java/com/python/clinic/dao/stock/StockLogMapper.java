package com.python.clinic.dao.stock;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.python.clinic.entity.stock.StockLog;
import com.python.clinic.entity.stock.vo.StockLogVo;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 库存日志表，包含药品/物资、入库、出库操作记录 Mapper 接口
 * </p>
 *
 * @author hm
 * @since 2020-05-19
 */
public interface StockLogMapper extends BaseMapper<StockLog> {

    /**
     * 根据关联id和关联类型查询操作日志
     * @param relationId   关联id
     * @param type  0：药品，1：采购，2：入库，3：出库，4：结算
     * @return
     */
    List<StockLogVo> listStockLog(@Param("relationId") Integer relationId, @Param("type") Integer type);

}
