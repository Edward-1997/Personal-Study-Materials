package com.python.clinic.entity.stock.dto;

import com.python.clinic.entity.stock.PurchaseApply;
import com.python.clinic.entity.stock.PurchaseGoods;
import lombok.Data;

import java.util.List;

/**
 * @author hm
 */
@Data
public class PurchaseApplyDTO {

    private PurchaseApply purchaseApply;

    private List<PurchaseGoods> purchaseGoodsList;

}
