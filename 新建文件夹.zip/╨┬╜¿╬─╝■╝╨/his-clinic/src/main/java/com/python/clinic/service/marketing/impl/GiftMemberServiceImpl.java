package com.python.clinic.service.marketing.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.python.clinic.entity.marketing.GiftMember;
import com.python.clinic.dao.marketing.GiftMemberMapper;
import com.python.clinic.service.marketing.GiftMemberService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.python.clinic.service.marketing.MemberCardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * <p>
 * 满减活动指定会员 服务实现类
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-05
 */
@Service
public class GiftMemberServiceImpl extends ServiceImpl<GiftMemberMapper, GiftMember> implements GiftMemberService {

    @Autowired
    private GiftMemberMapper giftMemberMapper;
    @Autowired
    private MemberCardService memberCardService;
    @Override
    public List<GiftMember> getGiftMemberList(GiftMember giftMember) {
        return giftMemberMapper.selectList(new QueryWrapper<>(giftMember))
                .stream()
                .peek(gift->gift.setMemberCard(memberCardService.getById(gift.getMemberId())))
                .collect(Collectors.toList());
    }
}
