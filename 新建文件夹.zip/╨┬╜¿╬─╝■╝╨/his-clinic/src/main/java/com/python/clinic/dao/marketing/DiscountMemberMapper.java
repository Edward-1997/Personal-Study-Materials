package com.python.clinic.dao.marketing;

import com.python.clinic.entity.marketing.DiscountMember;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 折扣指定会员卡 Mapper 接口
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-02
 */
public interface DiscountMemberMapper extends BaseMapper<DiscountMember> {

}
