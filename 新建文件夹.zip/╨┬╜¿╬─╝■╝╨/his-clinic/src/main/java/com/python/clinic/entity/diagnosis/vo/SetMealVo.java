package com.python.clinic.entity.diagnosis.vo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * 诊疗项目套餐
 * @author hm
 */
@Data
public class SetMealVo {

    private Integer id;

    @ApiModelProperty(value = "套餐名称")
    private String mealName;

    @ApiModelProperty(value = "包含项目数量")
    private Integer itemCount;

    @ApiModelProperty(value = "成本")
    private BigDecimal costPrice;

    @ApiModelProperty(value = "销售价")
    private BigDecimal salesPrice;

    @ApiModelProperty(value = "包含项目")
    private List<Map<String,Object>> itemList;

}
