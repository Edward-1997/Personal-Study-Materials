package com.python.clinic.dao.sys;

import com.python.clinic.entity.sys.Dispensing;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 发药设置 Mapper 接口
 * </p>
 *
 * @author hm
 * @since 2020-06-05
 */
public interface DispensingMapper extends BaseMapper<Dispensing> {

}
