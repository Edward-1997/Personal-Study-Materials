package com.python.clinic.controller.user;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.python.clinic.entity.user.Scheduling;
import com.python.clinic.entity.user.User;
import com.python.clinic.service.user.SchedulingService;
import com.python.common.response.CommonResult;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 排班详情表 前端控制器
 * </p>
 *
 * @author hm
 * @since 2020-06-05
 */
@RestController
@RequestMapping("/scheduling")
public class SchedulingController {

    @Autowired
    private SchedulingService schedulingService;

    @PostMapping("/saveScheduling")
    @ApiOperation("添加排班")
    public CommonResult saveScheduling(@RequestBody List<Scheduling> schedulingList){
        return schedulingService.saveScheduling(schedulingList);
    }

    @GetMapping("/listUserScheduling")
    @ApiOperation(value = "获取用户排班信息",notes = "role:角色(doctor:医生(默认)，staff:员工)，departmentId:科室id，为null表示全部科室，为0表示其他")
    public CommonResult listUserScheduling(@RequestParam(defaultValue = "1") Integer pageNum,
                                           @RequestParam(defaultValue = "10") Integer pageSize,
                                           @RequestParam(defaultValue = "doctor") String role,
                                           Integer departmentId,@RequestParam(required = true) String startTime){
        IPage<User> page = new Page<>(pageNum,pageSize);
        return CommonResult.success(schedulingService.listUserScheduling(page,role,departmentId,startTime));
    }

}
