package com.python.clinic.entity.user;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 用户职称表
 * </p>
 *
 * @author hm
 * @since 2020-06-02
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_user_title")
@ApiModel(value="UserTitle对象", description="用户职称表")
public class UserTitle extends Model<UserTitle> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "用户信息id")
    private Integer userInfoId;

    @ApiModelProperty(value = "职称id")
    private Integer titleId;

    @ApiModelProperty(value = "医执人员id")
    private Integer typeId;


    @Override
    protected Serializable pkVal() {
        return null;
    }

}
