package com.python.clinic.controller.stock;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.python.clinic.entity.stock.Inventory;
import com.python.clinic.service.stock.InventoryService;
import com.python.common.response.CommonResult;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 * 盘点表 前端控制器
 * </p>
 *
 * @author hm
 * @since 2020-05-27
 */
@RestController
@RequestMapping("/inventory")
public class InventoryController {

    @Autowired
    private InventoryService inventoryService;

    @GetMapping("/listInventory")
    @ApiOperation(value = "获取盘点列表",notes = "goodsId:商品id")
    public CommonResult listInventory(@RequestParam(defaultValue = "1") Integer pageNo,
                                      @RequestParam(defaultValue = "10") Integer pageSize,
                                      String startTime,String endTime,Integer goodsId){
        IPage<Inventory> page = new Page<>(pageNo,pageSize);
        return CommonResult.success(inventoryService.selectPage(page,startTime,endTime,goodsId));
    }

    @PostMapping("/saveInventory")
    @ApiOperation(value = "添加盘点单")
    public CommonResult saveInventory(@RequestBody Inventory inventory) throws Exception {
        return CommonResult.result(inventoryService.saveInventory(inventory));
    }

    @GetMapping("/getInventory")
    @ApiOperation(value = "获取盘点信息")
    public CommonResult getOutOfStock(@RequestParam(required = true)Integer id){
        return CommonResult.success(inventoryService.getInventoryById(id));
    }

}
