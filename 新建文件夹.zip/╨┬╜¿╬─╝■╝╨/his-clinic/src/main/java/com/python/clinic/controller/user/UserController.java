package com.python.clinic.controller.user;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.python.clinic.entity.user.User;
import com.python.clinic.entity.user.dto.UserDTO;
import com.python.clinic.service.user.UserService;
import com.python.common.response.CommonResult;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * 诊所用户表 前端控制器
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-21
 */
@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/saveUser")
    @ApiOperation("添加用户")
    public CommonResult saveUser(@RequestBody UserDTO userDTO){
        return CommonResult.result(userService.saveUser(userDTO));
    }

    @PutMapping("/updateUser")
    @ApiOperation("修改用户信息")
    public CommonResult updateUser(@RequestBody UserDTO userDTO){
        return CommonResult.result(userService.updateUser(userDTO));
    }

    @DeleteMapping("/deleteUser")
    @ApiOperation("将用户移出诊所")
    public CommonResult deleteUser(@RequestParam(required = true)Integer id){
        User user = new User();
        user.setId(id);
        user.setStatus(0);
        return CommonResult.result(userService.updateById(user));
    }

    @GetMapping("/userSelect")
    @ApiOperation("获取所有用户，用于用户选择")
    public CommonResult userSelect(){
        QueryWrapper<User> wrapper = new QueryWrapper<User>().select("user_name userName","id").eq("status", 1);
        return CommonResult.success(userService.listMaps(wrapper));
    }


}
