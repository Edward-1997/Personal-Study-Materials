package com.python.clinic.service.diagnosis.impl;

import com.python.clinic.entity.diagnosis.MealItem;
import com.python.clinic.dao.diagnosis.MealItemMapper;
import com.python.clinic.service.diagnosis.MealItemService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 套餐项目表 服务实现类
 * </p>
 *
 * @author hm
 * @since 2020-06-06
 */
@Service
public class MealItemServiceImpl extends ServiceImpl<MealItemMapper, MealItem> implements MealItemService {

}
