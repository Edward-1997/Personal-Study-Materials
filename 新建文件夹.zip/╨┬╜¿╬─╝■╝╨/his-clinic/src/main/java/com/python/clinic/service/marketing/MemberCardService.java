package com.python.clinic.service.marketing;

import com.python.clinic.entity.marketing.MemberCard;

import com.baomidou.mybatisplus.extension.service.IService;
import com.python.clinic.entity.marketing.dto.MemberCardDto;
import com.python.common.response.CommonResult;

/**
 * <p>
 * 会员卡 服务类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-20
 */
public interface MemberCardService extends IService<MemberCard> {

    /**
     * 获取会员卡类型列表，默认是获取所有
     * @author tanglong
     * @return com.python.common.response.CommonResult
     * @since 2020/5/29 9:51
     **/
    CommonResult selectMemberCardList(Integer pageSize,Integer pageNum);

    /**
     * 根据患者会员卡id，查询会员卡信息
     * @author tanglong
     * @param cardId 会员卡id
     * @return com.python.clinic.entity.patient.MemberCard
     * @since 2020/6/2 9:34
     **/
    MemberCardDto selectMemberCardInfo(Integer cardId);

    /**
     * 传入新增会员卡对象，完成新增会员卡操作
     * @author tanglong
     * @param memberCardDto 会员卡信息传输对象
     * @return com.python.common.response.CommonResult
     * @since 2020/6/3 10:41
     **/
    CommonResult insertMemberCard(MemberCardDto memberCardDto);

    /**
     * 根据会员卡id和折扣id，删除会员卡信息和相关权益
     * @author tanglong
     * @return com.python.common.response.CommonResult
     * @since 2020/6/4 15:38
     **/
    CommonResult deleteMemberCard(Integer cardId,Integer discountId);

    /**
     * 根据MemberCardDto实体对象，完成修改会员卡相关信息
     * @author tanglong
     * @param memberCardDto
     * @return com.python.common.response.CommonResult
     * @since 2020/6/4 16:16
     **/
    CommonResult updateMemberCard(MemberCardDto memberCardDto);
}
