package com.python.clinic.service.diagnosis;

import com.python.clinic.entity.diagnosis.MealItem;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 套餐项目表 服务类
 * </p>
 *
 * @author hm
 * @since 2020-06-06
 */
public interface MealItemService extends IService<MealItem> {

}
