package com.python.clinic.service.marketing.impl;

import com.python.clinic.entity.marketing.PatientCoupon;
import com.python.clinic.dao.marketing.PatientCouponMapper;
import com.python.clinic.service.marketing.PatientCouponService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 患者优惠券表 服务实现类
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-05
 */
@Service
public class PatientCouponServiceImpl extends ServiceImpl<PatientCouponMapper, PatientCoupon> implements PatientCouponService {

}
