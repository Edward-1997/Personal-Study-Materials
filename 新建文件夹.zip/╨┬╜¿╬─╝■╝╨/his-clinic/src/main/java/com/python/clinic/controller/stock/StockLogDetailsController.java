package com.python.clinic.controller.stock;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 入库日志详情表 前端控制器
 * </p>
 *
 * @author hm
 * @since 2020-05-19
 */
@RestController
@RequestMapping("/stock-log-details")
public class StockLogDetailsController {

}
