package com.python.clinic.service.stock.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.python.clinic.dao.stock.StockLogMapper;
import com.python.clinic.dao.sys.ClinicMapper;
import com.python.clinic.dao.user.UserMapper;
import com.python.clinic.entity.stock.StockLog;
import com.python.clinic.entity.stock.vo.StockLogVo;
import com.python.clinic.service.stock.StockLogService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 * 库存日志表，包含药品/物资、入库、出库操作记录 服务实现类
 * </p>
 *
 * @author hm
 * @since 2020-05-19
 */
@Service
public class StockLogServiceImpl extends ServiceImpl<StockLogMapper, StockLog> implements StockLogService {

    @Resource
    private StockLogMapper stockLogMapper;
    @Resource
    private UserMapper userMapper;
    @Resource
    private ClinicMapper clinicMapper;

    @Override
    public List<StockLogVo> listStockLog(Integer relationId, Integer type) {
        List<StockLogVo> stockLogVos = stockLogMapper.listStockLog(relationId, type);
        for (StockLogVo stockLogVo : stockLogVos) {
            stockLogVo.setCreator(userMapper.getIdAndName(stockLogVo.getCreateId()).getUserName());
            stockLogVo.setClinic(clinicMapper.getIdAndName(stockLogVo.getClinicId()).getClinicName());
        }
        return stockLogVos;
    }
}
