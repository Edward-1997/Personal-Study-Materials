package com.python.clinic.dao.user;

import com.python.clinic.entity.user.Assistant;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 医生助理表 Mapper 接口
 * </p>
 *
 * @author hm
 * @since 2020-06-02
 */
public interface AssistantMapper extends BaseMapper<Assistant> {

}
