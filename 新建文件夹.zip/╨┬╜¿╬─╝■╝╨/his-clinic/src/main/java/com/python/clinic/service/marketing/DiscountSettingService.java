package com.python.clinic.service.marketing;

import com.python.clinic.entity.marketing.DiscountSetting;
import com.baomidou.mybatisplus.extension.service.IService;
import com.python.clinic.entity.marketing.dto.ConflictSettingDto;
import com.python.clinic.entity.marketing.dto.DiscountSettingDto;

import java.util.List;

/**
 * <p>
 * 折扣设置表 服务类
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-02
 */
public interface DiscountSettingService extends IService<DiscountSetting> {

    /**
     * 根据查询条件查询折扣设置
     * @author tanglong
     * @param discountSetting 折扣查询id
     * @return java.util.List<com.python.clinic.entity.marketing.dto.DiscountSettingDto>
     * @since 2020/6/10 15:59
     **/
    List<DiscountSettingDto> getDiscountSettingList(DiscountSetting discountSetting);

    /**
     * 根据折扣id，获取活动产品数量
     * @author tanglong
     * @return java.lang.Integer
     * @since 2020/6/11 10:22
     **/
    Integer getDiscountStatistic(Integer discountId);

    /**
     * 根据折扣id查询冲突统计信息
     * @author tanglong
     * @param discountId
     * @return java.util.List<com.python.clinic.entity.marketing.DiscountSetting>
     * @since 2020/6/11 16:29
     **/
    Integer getConflictDiscountSettingCount(Integer discountId);

    /**
     * 查询折扣设置冲突列表
     * @author tanglong
     * @param discountId
     * @return java.util.List<com.python.clinic.entity.marketing.vo.DiscountSettingConflictVo>
     * @since 2020/6/11 16:59
     **/
    List<ConflictSettingDto> getConflictSettingList(Integer discountId);
}
