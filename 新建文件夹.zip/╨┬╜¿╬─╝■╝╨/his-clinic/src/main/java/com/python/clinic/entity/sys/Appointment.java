package com.python.clinic.entity.sys;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 预约设置
 * </p>
 *
 * @author hm
 * @since 2020-06-03
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_appointment")
@ApiModel(value="Appointment对象", description="预约设置")
public class Appointment extends Model<Appointment> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "提前放号时间")
    private Integer releaseNumTime;

    @ApiModelProperty(value = "提前放号时间单位")
    private String releaseNumTimeUnit;

    @ApiModelProperty(value = "放号时间")
    private String releaseNumSpecificTime;

    @ApiModelProperty(value = "是否开启号源过期")
    private Boolean numExpired;

    @ApiModelProperty(value = "关闭预约时间，单位：小时")
    private Integer expiredTime;

    @ApiModelProperty(value = "是否开启现场预留号")
    private Boolean siteReservation;

    @ApiModelProperty(value = "是否开启会员预留号")
    private Boolean memberReservation;

    @ApiModelProperty(value = "预约时间，0：按上午、下午、晚上预约，1：按精确时间段预约")
    private Integer appointmentTime;

    @ApiModelProperty(value = "是否开启微信预约支付")
    private Integer wechatAppointmentPay;

    @ApiModelProperty(value = "是否开启会员卡余额支付")
    private Boolean enablePaidByMemberCard;

    @ApiModelProperty(value = "是否开启微信预约限号")
    private Boolean wechatAppointmentLimit;

    @ApiModelProperty(value = "最多预约次数")
    private Integer wechatAppointmentCount;

    @ApiModelProperty(value = "微信预约限号时间")
    private Integer wechatAppointmentCountPeriod;

    @ApiModelProperty(value = "微信预约限号时间单位")
    private String wechatAppointmentCountUnit;

    @ApiModelProperty(value = "退号抢号提醒")
    private Boolean returnRobRemind;

    @ApiModelProperty(value = "是否允许微信退号")
    private Boolean wechatReturnNo;

    @ApiModelProperty(value = "退号提前时间")
    private Integer wechatReturnTime;

    @ApiModelProperty(value = "退号提前时间单位")
    private String wechatReturnTimeUnit;

    @ApiModelProperty(value = "退费设置")
    private Integer refundSetting;

    @ApiModelProperty(value = "预约签到")
    private Boolean appointmentSignIn;

    @ApiModelProperty(value = "扫码签到")
    private Boolean scanSignIn;

    @ApiModelProperty(value = "诊所id")
    private Integer clinicId;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
