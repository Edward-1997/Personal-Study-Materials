package com.python.clinic.entity.sys;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 医疗设备表
 * </p>
 *
 * @author hm
 * @since 2020-06-02
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_medical_equipment")
@ApiModel(value="MedicalEquipment对象", description="医疗设备表")
public class MedicalEquipment extends Model<MedicalEquipment> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "医疗名称")
    private String equipmentName;

    @ApiModelProperty(value = "设备编号")
    private String equipmentCode;

    @ApiModelProperty(value = "科室id")
    private Integer departmentId;

    @ApiModelProperty(value = "设备类型")
    private Integer equipmentType;

    @ApiModelProperty(value = "设备型号")
    private String model;

    @ApiModelProperty(value = "品牌")
    private String brand;

    @ApiModelProperty(value = "产地")
    private String producer;

    @ApiModelProperty(value = "是否为大型设备，0：false，1：true")
    private Integer largeEquipment;

    @ApiModelProperty(value = "大型设备类别")
    private Integer largeEquipmentType;

    @ApiModelProperty(value = "购买日期")
    private Date purchasingTime;

    @ApiModelProperty(value = "开始使用日期")
    private Date useTime;

    @ApiModelProperty(value = "使用年限")
    private Integer serviceLife;

    @ApiModelProperty(value = "配置")
    private String configuration;

    @ApiModelProperty(value = "技术规格")
    private String specification;

    @ApiModelProperty(value = "诊所id")
    private Integer clinicId;

    @TableField(exist = false)
    private String typeParentName;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
