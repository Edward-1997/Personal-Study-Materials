package com.python.clinic.service.sys;

import com.python.clinic.entity.sys.Appointment;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 预约设置 服务类
 * </p>
 *
 * @author hm
 * @since 2020-06-03
 */
public interface AppointmentService extends IService<Appointment> {

}
