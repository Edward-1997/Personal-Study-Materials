package com.python.clinic.entity.marketing.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/6/10 17:38
 **/
@Data
public class DiscountActivitiesVo {

    @ApiModelProperty(value = "活动id")
    private Integer id;
    @ApiModelProperty(value = "活动名称")
    private String name;
    @ApiModelProperty(value = "活动状态")
    private Integer status;
    @ApiModelProperty(value = "活动产品")
    private Integer count;
    @ApiModelProperty(value = "活动门店")
    private String clinic;
    @ApiModelProperty(value = "活动开始时间")
    private Date beginDate;
    @ApiModelProperty(value = "活动结束时间")
    private Date endDate;
    @ApiModelProperty(value = "活动对象")
    private List<String> applicators;
    @ApiModelProperty(value = "冲突对象数量")
    private Integer conflictNum;
}
