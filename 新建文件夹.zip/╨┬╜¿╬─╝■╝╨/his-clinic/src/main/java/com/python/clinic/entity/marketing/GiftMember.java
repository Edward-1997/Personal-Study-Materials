package com.python.clinic.entity.marketing;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 满减活动指定会员
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-05
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_gift_member")
@ApiModel(value="GiftMember对象", description="满减活动指定会员")
public class GiftMember extends Model<GiftMember> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "满减活动id")
    private Integer giftId;

    @ApiModelProperty(value = "会员id")
    private Integer memberId;

    @ApiModelProperty(value = "会员卡基本信息")
    @TableField(exist = false)
    private MemberCard memberCard;

    @Override
    protected Serializable pkVal() {
        return null;
    }

}
