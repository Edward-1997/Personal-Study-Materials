package com.python.clinic.service.stock;

import com.python.clinic.entity.stock.InventoryDetails;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 盘点详情表 服务类
 * </p>
 *
 * @author hm
 * @since 2020-05-27
 */
public interface InventoryDetailsService extends IService<InventoryDetails> {

}
