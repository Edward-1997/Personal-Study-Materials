package com.python.clinic.dao.stock;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.python.clinic.entity.stock.Inventory;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;


/**
 * <p>
 * 盘点表 Mapper 接口
 * </p>
 *
 * @author hm
 * @since 2020-05-27
 */
public interface InventoryMapper extends BaseMapper<Inventory> {

    /**
     * 分页带条件查询盘点列表
     * @param page
     * @param startTime 开始时间
     * @param endTime   结束时间
     * @param goodsId   商品id
     * @return
     */
    IPage<Inventory> selectPage(IPage<Inventory> page, @Param("startTime")String startTime, @Param("endTime")String endTime, @Param("goodsId")Integer goodsId);

}
