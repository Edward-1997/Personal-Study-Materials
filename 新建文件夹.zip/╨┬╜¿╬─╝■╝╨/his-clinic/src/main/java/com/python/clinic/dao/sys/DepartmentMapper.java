package com.python.clinic.dao.sys;

import com.python.clinic.entity.sys.Department;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.List;

/**
 * <p>
 * 科室表 Mapper 接口
 * </p>
 *
 * @author hm
 * @since 2020-06-02
 */
public interface DepartmentMapper extends BaseMapper<Department> {

    /**
     * 获取科室列表
     * @return
     */
    List<Department> listDepartment();

}
