package com.python.clinic.entity.stock.vo;

import lombok.Data;

import java.math.BigDecimal;

/**
 * @author hm
 */
@Data
public class GoodsStockVo {

    /**
     * 整装库存
     */
    private Integer packageCount;

    /**
     * 散装库存
     */
    private Integer pieceCount;

    /**
     * 进价，有整装包装则为整装进价，无则为散装进价
     */
    private BigDecimal packagePrice;

    /**
     * 售价
     */
    private BigDecimal sellPrice;

    /**
     * 制剂
     */
    private Integer preparation;

    /**
     * 通用名
     */
    private Integer medicineCadn;

    /**
     * 整装单位
     */
    private String packageUnit;

    /**
     * 散装单位
     */
    private String preparationUnit;


}
