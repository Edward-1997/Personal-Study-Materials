package com.python.clinic.entity.marketing.dto;

import com.python.clinic.entity.stock.Goods;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/6/10 14:58
 **/
@Data
public class DiscountSettingDto {
    @ApiModelProperty(value = "折扣活动id")
    private Integer promotionId;

    @ApiModelProperty(value = "折扣活动类型 0：折扣设置 1：单品折扣")
    private Integer type;

    @ApiModelProperty(value = "折扣")
    private Double discount;

    @ApiModelProperty(value = "如果是单品折扣则设置商品id,其余情况为null")
    private Integer goodsId;

    @ApiModelProperty(value = "商品类型")
    private Integer goodsType;

    @ApiModelProperty(value = "商品子类型")
    private Integer goodsSubType;

    @ApiModelProperty(value = "商品")
    private Goods goods;
}
