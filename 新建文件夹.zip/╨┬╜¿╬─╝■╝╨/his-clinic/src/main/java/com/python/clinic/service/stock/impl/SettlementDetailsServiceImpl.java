package com.python.clinic.service.stock.impl;

import com.python.clinic.entity.stock.SettlementDetails;
import com.python.clinic.dao.stock.SettlementDetailsMapper;
import com.python.clinic.service.stock.SettlementDetailsService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 结算明细表 服务实现类
 * </p>
 *
 * @author hm
 * @since 2020-05-28
 */
@Service
public class SettlementDetailsServiceImpl extends ServiceImpl<SettlementDetailsMapper, SettlementDetails> implements SettlementDetailsService {

}
