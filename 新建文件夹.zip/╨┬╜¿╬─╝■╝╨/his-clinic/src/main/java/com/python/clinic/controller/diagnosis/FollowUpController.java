package com.python.clinic.controller.diagnosis;


import com.python.clinic.entity.diagnosis.FollowUp;
import com.python.clinic.entity.diagnosis.dto.FollowUpDto;
import com.python.clinic.service.diagnosis.FollowUpService;
import com.python.common.response.CommonResult;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * <p>
 * 随访表 前端控制器
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-22
 */
@RestController
@RequestMapping("/follow_up")
public class FollowUpController {
    @Autowired
    private FollowUpService followUpService;

    @ApiOperation(value = "获取单次随访计划执行记录",notes = "传入随访记录id")
    @GetMapping("/record")
    public CommonResult getPatientRecord(@RequestParam Integer id){
        return followUpService.getFollowRecord(id);
    }

    @ApiOperation(value = "查询患者随访记录/患者随访",
            notes = "传入随访日期（followTime）和医生id(doctorId)查询患者随访记录列表")
    @GetMapping("/records")
    public CommonResult getPatientRecords(@RequestParam(required = false) Date followTime,
                                          @RequestParam Integer doctorId){
        return followUpService.getDoctorFollowList(followTime,doctorId);
    }

    @ApiOperation(value = "更改患者随访执行计划", notes = "传入随访记录，更改患者未执行随访计划")
    @PutMapping("/record")
    public CommonResult updateFollowRecord(@RequestBody FollowUp followUp){
        return followUpService.updateFollowRecord(followUp);
    }

    @ApiOperation(value = "新建患者随访执行计划", notes = "传入随访记录和传入患者组id字符串 每个id用,分隔，" +
            "完成新建患者随访计划")
    @PostMapping("/execution/plan")
    public CommonResult insertFollowRecord(@RequestBody FollowUpDto followUpDto){
        try {
            return followUpService.insertFollowRecord(followUpDto);
        } catch (ParseException e) {
            e.printStackTrace();
            return CommonResult.failed("日期格式异常");
        }
    }

    @ApiOperation(value = "",notes = "")
    @PostMapping("/file")
    public CommonResult uploadFile(@RequestParam("file")MultipartFile file){
        if(file.isEmpty()){
            return CommonResult.failed("文件为空");
        }
        String filename = file.getOriginalFilename();
        String suffixName = filename.substring(filename.lastIndexOf("."));
        filename = UUID.randomUUID().toString()+"."+suffixName;

        String fillPath = ""+filename;
        Map<String,Object> map = new HashMap<>();
        map.put("filePath",fillPath);

        return CommonResult.success(map,"上传成功");
    }

}
