package com.python.clinic.service.marketing.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.python.clinic.entity.marketing.GiftCoupon;
import com.python.clinic.entity.marketing.PreferentialSet;
import com.python.clinic.dao.marketing.PreferentialSetMapper;
import com.python.clinic.entity.marketing.constant.MarketingConstant;
import com.python.clinic.entity.marketing.dto.GiftCouponDto;
import com.python.clinic.entity.marketing.dto.GiftGoodDto;
import com.python.clinic.entity.marketing.dto.GiftRulesDto;
import com.python.clinic.service.marketing.GiftCouponService;
import com.python.clinic.service.marketing.PreferentialSetService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.python.common.response.CommonResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * <p>
 * 优惠设置表 服务实现类
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-05
 */
@Service
public class PreferentialSetServiceImpl extends ServiceImpl<PreferentialSetMapper, PreferentialSet> implements PreferentialSetService {

    @Autowired
    private PreferentialSetMapper preferentialSetMapper;
    @Autowired
    private GiftCouponService giftCouponService;

    @SuppressWarnings("unchecked")
    @Override
    public List<GiftRulesDto> getGiftRulesVoList(Integer giftId) {
        PreferentialSet preferentialSet = new PreferentialSet();
        preferentialSet.setGiftId(giftId);

        return preferentialSetMapper.selectList(new QueryWrapper<>(preferentialSet)).stream().map(set->{
            GiftRulesDto vo = new GiftRulesDto();
            vo.setPreferentialSet(set);
            GiftCoupon giftCoupon = new GiftCoupon();
            giftCoupon.setPreferentialSetId(set.getId());
            //获取满减返活动中满返，满赠列表
            Map<String, Object> map= giftCouponService.getGiftCouponDetailsList(giftCoupon);

            vo.setGiftCoupon((List<GiftCouponDto>)map.get("giftCouponDto"));
            vo.setGiftGoods((List<GiftGoodDto>)map.get("giftGoodDto"));
            return vo;
        }).collect(Collectors.toList());
    }

    @Transactional
    @Override
    public CommonResult insertGiftPreferential(List<GiftRulesDto> giftRulesList) {

        for(GiftRulesDto dto : giftRulesList){
            PreferentialSet preferentialSet = dto.getPreferentialSet();
            //新增优惠设置基本信息
            if(1!=preferentialSetMapper.insert(preferentialSet)){
                throw new RuntimeException();
            }
            //新增设置满减返优惠券
            if(dto.getGiftCoupon()!= null && dto.getGiftCoupon().size()>0){
                if(preferentialSet.getFullReturn() == 0){//满减返优惠券未被勾选,数据异常
                    throw new RuntimeException();
                }
                for(GiftCouponDto giftCouponDto:dto.getGiftCoupon()){
                    GiftCoupon giftCoupon = new GiftCoupon();
                    giftCoupon.setPreferentialSetId(preferentialSet.getId());
                    giftCoupon.setCount(giftCouponDto.getCount());
                    giftCoupon.setRelationType(MarketingConstant.GiftCoupon.COUPON_TYPE);
                    giftCoupon.setRelationId(giftCouponDto.getId());
                    if(!giftCouponService.save(giftCoupon)){
                        throw new RuntimeException();
                    }
                }
            }
            //新增设置满减返赠品
            if(dto.getGiftGoods() != null && dto.getGiftGoods().size()>0){
                if(preferentialSet.getFullGive() == 0){//满减返赠品未被勾选,数据异常
                    throw new RuntimeException();
                }
                for(GiftGoodDto giftGoodDto:dto.getGiftGoods()){
                    GiftCoupon giftCoupon = new GiftCoupon();
                    giftCoupon.setPreferentialSetId(preferentialSet.getId());
                    giftCoupon.setCount(giftGoodDto.getCount());
                    giftCoupon.setRelationType(MarketingConstant.GiftCoupon.GOODS_TYPE);
                    giftCoupon.setRelationId(giftGoodDto.getGoodsId());
                    if(!giftCouponService.save(giftCoupon)){
                        throw new RuntimeException();
                    }
                }
            }
        }
        return CommonResult.success(null);
    }

    @Transactional
    @Override
    public CommonResult deleteGiftPreferential(Integer giftId) {
        //获取该满减返活动下的所有优惠设置
        PreferentialSet preferentialSet = new PreferentialSet();
        preferentialSet.setGiftId(giftId);
        List<PreferentialSet> preferentialSets = preferentialSetMapper.selectList(new QueryWrapper<>(preferentialSet));

        //删除优惠设置下的满减返
        for(PreferentialSet set : preferentialSets){
            GiftCoupon giftCoupon = new GiftCoupon();
            giftCoupon.setPreferentialSetId(set.getId());

            giftCouponService.remove(new QueryWrapper<>(giftCoupon));
        }

        return CommonResult.success(null);
    }
}
