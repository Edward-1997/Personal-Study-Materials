package com.python.clinic.controller.marketing;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 折扣门店表 前端控制器
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-02
 */
@RestController
@RequestMapping("/discount-store")
public class DiscountStoreController {

}
