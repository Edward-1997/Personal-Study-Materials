package com.python.clinic.entity.enums;

import com.baomidou.mybatisplus.core.enums.IEnum;
import com.fasterxml.jackson.annotation.JsonValue;

/**
 * @author hm
 */
public enum GoodsAndTreatmentTypeEnum implements IEnum<Integer> {

    //药品
    DRUGS(0,"药品"),
    //物资
    MATERIALS(1,"物资"),
    //商品
    GOODS(2,"商品"),
    //检查检验
    INSPECT(3,"检查检验"),
    //治疗理疗
    TREATMENT(4,"治疗理疗"),
    //套餐
    SET_MEAL(5,"套餐"),
    //其他费用
    OTHER(6,"其他费用");

    private Integer value;
    private String desc;

    GoodsAndTreatmentTypeEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public static GoodsAndTreatmentTypeEnum getByValue(Integer value){
        GoodsAndTreatmentTypeEnum[] goodsAndTreatmentTypeEnums = GoodsAndTreatmentTypeEnum.values();
        for(GoodsAndTreatmentTypeEnum goodsAndTreatmentTypeEnum : goodsAndTreatmentTypeEnums){
            if(goodsAndTreatmentTypeEnum.getValue().equals(value)){
                return goodsAndTreatmentTypeEnum;
            }
        }
        return null;
    }

    @Override
    public Integer getValue() {
        return this.value;
    }

    @JsonValue
    public String getDesc() {
        return this.desc;
    }
}
