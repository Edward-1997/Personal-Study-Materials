package com.python.clinic.service.diagnosis;

import com.python.clinic.entity.diagnosis.DiagnosisItem;
import com.baomidou.mybatisplus.extension.service.IService;
import com.python.clinic.entity.diagnosis.vo.TreatmentItemVo;

import java.util.List;

/**
 * <p>
 * 门诊检查项目表 服务类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-26
 */
public interface DiagnosisItemService extends IService<DiagnosisItem> {

    /**
     * 根据传来的诊疗项目，查询诊疗项目列表，
     * @author tanglong
     * @param diagnosisItem 诊疗项目的查询条件
     * @return java.util.List<com.python.clinic.entity.diagnosis.vo.TreatmentItemVo>
     * @since 2020/5/26 16:50
     * @see TreatmentItemVo
     **/
    List<TreatmentItemVo> getTreatmentList(DiagnosisItem diagnosisItem);

}
