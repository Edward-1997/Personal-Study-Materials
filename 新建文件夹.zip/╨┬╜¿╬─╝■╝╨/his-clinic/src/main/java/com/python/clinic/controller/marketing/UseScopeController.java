package com.python.clinic.controller.marketing;


import com.python.clinic.entity.marketing.UseScope;
import com.python.clinic.entity.marketing.constant.MarketingConstant;
import com.python.clinic.service.marketing.UseScopeService;
import com.python.common.response.CommonResult;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 使用范围表 前端控制器
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-05
 */
@RestController
@RequestMapping("/use_scope")
public class UseScopeController {

    @Autowired
    private UseScopeService useScopeService;

    @ApiOperation(value = "校验满减返活动使用范围是否冲突",notes = "传入UseScope 数组对象，其中包括，" +
            "商品类型goodsType，商品子类型goodsSubType，商品id goodsId，完成使用范围校验")
    @PostMapping("/gift")
    public CommonResult checkConflict(@RequestBody List<UseScope> useScope){
        return useScopeService.checkUseScope(useScope);
    }
}
