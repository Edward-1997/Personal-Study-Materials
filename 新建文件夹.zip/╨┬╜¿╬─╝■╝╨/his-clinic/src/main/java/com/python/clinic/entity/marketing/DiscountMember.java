package com.python.clinic.entity.marketing;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 折扣指定会员卡
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-02
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_discount_member")
@ApiModel(value="DiscountMember对象", description="折扣指定会员卡")
public class DiscountMember extends Model<DiscountMember> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "折扣id")
    private Integer discountId;

    @ApiModelProperty(value = "会员卡id")
    private Integer memberCardId;

    @ApiModelProperty(value = "是否为会员卡折扣，0：false，1：true")
    private Integer memberDiscount;


    @Override
    protected Serializable pkVal() {
        return null;
    }

}
