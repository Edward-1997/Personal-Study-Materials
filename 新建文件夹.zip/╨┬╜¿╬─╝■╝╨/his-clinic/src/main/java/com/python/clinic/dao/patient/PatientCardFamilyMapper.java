package com.python.clinic.dao.patient;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.python.clinic.entity.patient.PatientCardFamily;

/**
 * <p>
 * 会员卡家庭成员表 Mapper 接口
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-20
 */
public interface PatientCardFamilyMapper extends BaseMapper<PatientCardFamily> {

}
