package com.python.clinic.service.stock.impl;

import com.python.clinic.entity.stock.Invoice;
import com.python.clinic.dao.stock.InvoiceMapper;
import com.python.clinic.service.stock.InvoiceService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 发票表 服务实现类
 * </p>
 *
 * @author hm
 * @since 2020-05-28
 */
@Service
public class InvoiceServiceImpl extends ServiceImpl<InvoiceMapper, Invoice> implements InvoiceService {

}
