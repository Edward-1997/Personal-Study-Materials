package com.python.clinic.controller.stock;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 采购药品/物资表 前端控制器
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-21
 */
@RestController
@RequestMapping("/purchase-goods")
public class PurchaseGoodsController {

}
