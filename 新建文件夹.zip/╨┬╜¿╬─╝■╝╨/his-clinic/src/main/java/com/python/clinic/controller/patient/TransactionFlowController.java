package com.python.clinic.controller.patient;


import com.python.clinic.entity.patient.TransactionFlow;
import com.python.clinic.service.patient.TransactionFlowService;
import com.python.common.response.CommonResult;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;

/**
 * <p>
 * 交易流水表 前端控制器
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-20
 */
@RestController
@RequestMapping("/transaction_flow")
public class TransactionFlowController {
    @Autowired
    private TransactionFlowService transactionFlowService;

    @GetMapping("/details/{cardId}")
    @ApiOperation(value = "获取交易流水列表",notes = "分页查询，默认一页10条记录。pageSize:数量，pageNnum:起始位置")
    public CommonResult getTransactionDetails(@RequestParam(defaultValue = "1") Integer pageNum,
                                              @RequestParam(defaultValue = "10") Integer pageSize,
                                              @PathVariable Integer cardId){
        return transactionFlowService.getTransactionList(cardId,pageSize,pageNum);
    }

//    @PostMapping("/paid")
//    @ApiOperation(value = "新增支付交易记录",notes = "传入会员交易流水")
//    public CommonResult insertPaidTransactionDetails(TransactionFlow record){
//        record.setType(0);
//        transactionFlowService.insertTransactionRecord(record);
//    }
//
//    @PostMapping("/refund")
//    @ApiOperation(value = "新增退款交易记录",notes = "传入会员交易流水")
//    public CommonResult insertPaidTransactionDetails(TransactionFlow record){
//        record.setType(0);
//        transactionFlowService.insertTransactionRecord(record);
//    }
}
