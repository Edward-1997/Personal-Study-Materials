package com.python.clinic.controller.sys;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.python.clinic.entity.sys.Appointment;
import com.python.clinic.service.sys.AppointmentService;
import com.python.common.response.CommonResult;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 * 预约设置 前端控制器
 * </p>
 *
 * @author hm
 * @since 2020-06-03
 */
@RestController
@RequestMapping("/appointment")
public class AppointmentController {

    @Autowired
    private AppointmentService appointmentService;

    @GetMapping("/getAppointment/{clinicId}")
    @ApiOperation("获取预约设置信息")
    public CommonResult getAppointment(@PathVariable String clinicId){
        QueryWrapper<Appointment> wrapper = new QueryWrapper<>();
        wrapper.eq("clinic_id",clinicId);
        return CommonResult.success(appointmentService.getOne(wrapper));
    }

    @PutMapping("/updateAppointment")
    @ApiOperation("修改预约设置")
    public CommonResult updateAppointment(@RequestBody Appointment appointment){
        return CommonResult.result(appointmentService.updateById(appointment));
    }

}
