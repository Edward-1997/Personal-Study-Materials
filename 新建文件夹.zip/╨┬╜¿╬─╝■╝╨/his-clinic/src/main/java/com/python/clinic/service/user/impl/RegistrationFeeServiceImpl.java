package com.python.clinic.service.user.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.python.clinic.entity.user.RegistrationFee;
import com.python.clinic.dao.user.RegistrationFeeMapper;
import com.python.clinic.service.user.RegistrationFeeService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 挂号费表 服务实现类
 * </p>
 *
 * @author hm
 * @since 2020-06-06
 */
@Service
public class RegistrationFeeServiceImpl extends ServiceImpl<RegistrationFeeMapper, RegistrationFee> implements RegistrationFeeService {

    @Resource
    private RegistrationFeeMapper registrationFeeMapper;

    @Override
    public IPage<Map<String,Object>> listDoctorRegistrationFee(IPage<RegistrationFee> page, Integer departmentId, String userName) {
        return registrationFeeMapper.listDoctorRegistrationFee(page,departmentId,userName);
    }

    @Override
    public boolean saveOrUpdateRegistrationFee(RegistrationFee registrationFee) {
        boolean flag = false;
        if (registrationFee.getId() == null){
            //id为null,执行添加
            flag = registrationFeeMapper.insert(registrationFee) > 0;
        }else {
            //id不为null,执行修改
            flag = registrationFeeMapper.updateById(registrationFee) > 0;
        }
        return flag;
    }
}
