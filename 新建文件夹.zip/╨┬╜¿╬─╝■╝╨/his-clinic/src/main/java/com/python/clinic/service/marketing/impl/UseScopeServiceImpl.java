package com.python.clinic.service.marketing.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.python.clinic.entity.marketing.ExceptionGoods;
import com.python.clinic.entity.marketing.GiftRulePromotions;
import com.python.clinic.entity.marketing.UseScope;
import com.python.clinic.dao.marketing.UseScopeMapper;
import com.python.clinic.entity.marketing.constant.MarketingConstant;
import com.python.clinic.entity.stock.Goods;
import com.python.clinic.service.marketing.ExceptionGoodsService;
import com.python.clinic.service.marketing.GiftRulePromotionsService;
import com.python.clinic.service.marketing.UseScopeService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.python.clinic.service.stock.GoodsService;
import com.python.common.response.CommonResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * <p>
 * 使用范围表 服务实现类
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-05
 */
@Service
public class UseScopeServiceImpl extends ServiceImpl<UseScopeMapper, UseScope> implements UseScopeService {

    @Autowired
    private UseScopeMapper useScopeMapper;
    @Autowired
    private ExceptionGoodsService exceptionGoodsService;
    @Autowired
    private GoodsService goodsService;
    @Autowired
    private GiftRulePromotionsService giftRulePromotionsService;

    @Override
    public List<UseScope> getUseScopeList(UseScope useScope) {
        List<UseScope> useScopeList = useScopeMapper.selectList(new QueryWrapper<>(useScope));
        for(UseScope scope : useScopeList){
            //获得商品详细信息
            Goods goods = goodsService.getById(scope.getGoodsId());
            scope.setName(goods.getName());
            //获得例外商品
            ExceptionGoods exceptionGoods = new ExceptionGoods();
            exceptionGoods.setUseScopeId(scope.getId());
            scope.setExceptionGoodsList(exceptionGoodsService.getExceptionGoodsList(scope.getId()));
        }
        if(useScopeList.size()<1){
            return null;
        }
        return useScopeList;
    }

    @Transactional
    @Override
    public CommonResult insertUseScope(UseScope useScope) {
        if(1 != useScopeMapper.insert(useScope)){
            throw new RuntimeException();
        }
        List<Goods> exceptionGoodsList = useScope.getExceptionGoodsList();
        //新增例外商品列表
        if(exceptionGoodsList != null){
            boolean flag = exceptionGoodsService.saveBatch(exceptionGoodsList.stream().map(goods -> {
                ExceptionGoods exceptionGoods = new ExceptionGoods();
                exceptionGoods.setGoodsId(goods.getId());
                exceptionGoods.setUseScopeId(useScope.getId());
                return exceptionGoods;
            }).collect(Collectors.toList()));
            if(!flag){
                throw new RuntimeException();
            }
        }
        return CommonResult.success(null,"新增成功");
    }

    @Transactional
    @Override
    public CommonResult deleteUseScope(UseScope useScope) {
        //移除该使用范围下的例外商品列表
        ExceptionGoods oldExceptionGoods = new ExceptionGoods();
        oldExceptionGoods.setUseScopeId(useScope.getId());
        exceptionGoodsService.remove(new QueryWrapper<>(oldExceptionGoods));
        //移除该使用范围
        useScopeMapper.delete(new QueryWrapper<>(useScope));
        return CommonResult.success(null,"删除成功");
    }

    @Override
    public CommonResult checkUseScope(List<UseScope> useScopeList) {
        //保存有冲突的使用范围
        List<UseScope> conflict = new ArrayList<>();

        for(UseScope useScope:useScopeList){
            useScope.setType(MarketingConstant.UseScope.GIFT_TYPE);
            UseScope oldUseScope = useScopeMapper.selectOne(new QueryWrapper<>(useScope));
            if(null != oldUseScope){
                GiftRulePromotions giftRulePromotions = giftRulePromotionsService.getById(oldUseScope.getRelationId());
                //存在旧的使用范围，然后校验活动是否结束，如果活动已结束则继续，否则添加到conflict
                if(MarketingConstant.GiftRulePromotion.FINISHED_STATUS.equals(giftRulePromotions.getStatus())){
                    continue;
                }
                conflict.add(useScope);
            }
        }
        Map<String,Object> map = new HashMap<>();
        map.put("conflict",conflict);

        return CommonResult.success(map,"校验成功");
    }
}
