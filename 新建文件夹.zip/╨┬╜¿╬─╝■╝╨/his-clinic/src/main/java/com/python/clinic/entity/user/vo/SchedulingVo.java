package com.python.clinic.entity.user.vo;
import lombok.Data;

import java.util.List;

/**
 * @author hm
 */
@Data
public class SchedulingVo {

    private Integer id;

    private String userName;

    private List<ScheduleShiftsVo> schedules;

}
