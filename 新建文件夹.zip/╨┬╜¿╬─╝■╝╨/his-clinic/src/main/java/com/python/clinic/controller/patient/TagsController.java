package com.python.clinic.controller.patient;


import com.python.clinic.entity.patient.Tags;
import com.python.clinic.service.patient.TagsService;
import com.python.common.response.CommonResult;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;

/**
 * <p>
 * 标签表 前端控制器
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-21
 */
@RestController
@RequestMapping("/tags")
public class TagsController {
    private Logger logger = LoggerFactory.getLogger(TagsService.class);
    @Autowired
    private TagsService tagsService;

    @GetMapping("/list/{tagType}")
    @ApiOperation(value = "查询tag",notes = "传入tagType，实现查询标签操作")
    public CommonResult getTagList(@PathVariable Integer tagType){
        return tagsService.selectTagListByTagType(tagType);
    }


    @PostMapping("/tag")
    @ApiOperation(value = "新增tag",notes = "传入tagName、tagType，实现新增标签操作")
    public CommonResult insertTag(@RequestBody Tags tag){
        try {
            return tagsService.insertTag(tag);
        } catch (Exception e) {
            logger.info(LocalDateTime.now()+"新增表标签失败",e.getCause());
            return CommonResult.failed("新增标签失败");
        }
    }

    @PutMapping("/tag")
    @ApiOperation(value = "更新tag",notes = "传入tagId、新的tagName，实现更新标签操作")
    public CommonResult updateTag(@RequestBody Tags tag){
        try {
            return tagsService.updateTag(tag);
        } catch (Exception e) {
            logger.info(LocalDateTime.now()+"更新标签失败",e.getCause());
            return CommonResult.failed("更新标签失败");
        }
    }

    @DeleteMapping("/patient/tag/{tagId}")
    @ApiOperation(value = "删除tag",notes = "传入需要删除的Id，实现删除标签操作")
    public CommonResult deleteAllTags(@PathVariable Integer tagId){
        boolean flag =false;
        try {
            flag = tagsService.deleteTagAndPatientTag(tagId);
        }catch (Exception e){
            logger.info("删除标签异常",e);
        }
        if(flag){
            return CommonResult.success(null,"删除成功");
        }
        return CommonResult.failed("删除标签失败");
    }


}
