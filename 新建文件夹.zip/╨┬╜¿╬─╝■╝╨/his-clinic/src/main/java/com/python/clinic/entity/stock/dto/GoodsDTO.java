package com.python.clinic.entity.stock.dto;

import com.python.clinic.entity.stock.Goods;
import com.python.clinic.entity.stock.StockLog;
import com.python.clinic.entity.stock.StockLogDetails;
import lombok.Data;

import java.util.List;

/**
 * @author hm
 */
@Data
public class GoodsDTO {

    private Goods goods;

    private StockLog stockLog;

    private List<StockLogDetails> stockLogDetailsList;

}
