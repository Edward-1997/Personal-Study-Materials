package com.python.clinic.entity.stock;

import java.math.BigDecimal;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import java.util.List;

import com.python.clinic.entity.stock.vo.StockLogVo;
import com.python.clinic.entity.sys.Clinic;
import com.python.clinic.entity.user.User;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 出库表
 * </p>
 *
 * @author hm
 * @since 2020-05-23
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_out_of_stock")
@ApiModel(value="OutOfStock对象", description="出库表")
public class OutOfStock extends Model<OutOfStock> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "出库人id")
    private Integer createId;

    @ApiModelProperty(value = "出库时间")
    private Date createTime;

    @ApiModelProperty(value = "类型，0：科室，1：报损，2：退货")
    private Integer type;

    @ApiModelProperty(value = "领用人id")
    private Integer toUserId;

    @ApiModelProperty(value = "科室id")
    private Integer toDepartment;

    @ApiModelProperty(value = "状态 1:已入库")
    private Integer status;

    @ApiModelProperty(value = "结算状态")
    private Integer settlementStatus;

    @ApiModelProperty(value = "品种数量")
    private Integer kindCount;

    @ApiModelProperty(value = "数量")
    private Double outCount;

    @ApiModelProperty(value = "含税金额")
    private BigDecimal amount;

    @ApiModelProperty(value = "不含税金额")
    private BigDecimal noTaxAmount;

    @ApiModelProperty(value = "出库单号")
    private String orderNo;

    @ApiModelProperty(value = "所属诊所id")
    private Integer clinicId;

    @TableField(exist = false)
    private User creator;

    @TableField(exist = false)
    private Clinic clinic;

    @TableField(exist = false)
    private User toUser;

    @TableField(exist = false)
    private List<StockLogVo> logList;

    @TableField(exist = false)
    private List<OutOfStockDetails> detailsList;

    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
