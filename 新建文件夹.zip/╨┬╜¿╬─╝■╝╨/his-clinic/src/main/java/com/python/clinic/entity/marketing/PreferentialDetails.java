package com.python.clinic.entity.marketing;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 优惠详情表
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-05
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_preferential_details")
@ApiModel(value="PreferentialDetails对象", description="优惠详情表")
public class PreferentialDetails extends Model<PreferentialDetails> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "优惠项目")
    private String preferentialItem;

    @ApiModelProperty(value = "优惠金额")
    private BigDecimal preferentialMoney;

    @ApiModelProperty(value = "优惠表id")
    private Integer preferentialId;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
