package com.python.clinic.controller.patient;


import com.python.clinic.entity.patient.PatientCardFamily;
import com.python.clinic.service.patient.PatientCardFamilyService;
import com.python.common.response.CommonResult;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 会员卡家庭成员表 前端控制器
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-20
 */
@RestController
@RequestMapping("/patient_card_family")
public class PatientCardFamilyController {

    @Autowired
    private PatientCardFamilyService patientCardFamilyService;

    @ApiOperation(value = "新增会员家庭成员",notes = "传入患者id，实现新增患者家庭成员操作")
    public CommonResult insertPatientFamilyMember(Integer id){
        return null;
    }

    @ApiOperation(value = "删除患者家庭成员",notes="传入患者会员卡id（手机号）和需要删除的家庭成员id")
    @DeleteMapping("/member")
    public CommonResult deleteFamilyMember(PatientCardFamily patientCardFamily){
        return  patientCardFamilyService.deleteFamilyMembers(patientCardFamily);
    }
}
