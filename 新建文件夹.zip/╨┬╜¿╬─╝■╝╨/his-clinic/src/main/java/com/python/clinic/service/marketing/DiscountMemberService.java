package com.python.clinic.service.marketing;

import com.python.clinic.entity.marketing.DiscountMember;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 * 折扣指定会员卡 服务类
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-02
 */
public interface DiscountMemberService extends IService<DiscountMember> {

    /**
     * 查询折扣活动下指定会员
     * @author tanglong
     * @param discountMember 查询条件
     * @return java.util.List<com.python.clinic.entity.marketing.DiscountMember>
     * @since 2020/6/10 15:27
     **/
    List<DiscountMember> getDiscountMemberList(DiscountMember discountMember);
}
