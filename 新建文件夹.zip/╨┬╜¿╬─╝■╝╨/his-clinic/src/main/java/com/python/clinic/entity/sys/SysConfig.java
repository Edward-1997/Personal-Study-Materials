package com.python.clinic.entity.sys;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import java.math.BigDecimal;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 系统配置
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-21
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_sys_config")
@ApiModel(value="SysConfig对象", description="系统配置")
public class SysConfig extends Model<SysConfig> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "诊所id")
    private Integer clinicId;

    @ApiModelProperty(value = "药品周转天数")
    private Integer stockWarnGoodsTurnoverDays;

    @ApiModelProperty(value = "有效期月数")
    private Integer stockWarnGoodsWillExpiredMonth;

    @ApiModelProperty(value = "排版时是否设置诊室，0：不设置，1：设置")
    private Boolean setRoom;

    @ApiModelProperty(value = "默认挂号费成本")
    private BigDecimal defaultRegistrationFeeCost;

    @ApiModelProperty(value = "默认挂号费售价")
    private BigDecimal defaultRegistrationFeeSales;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
