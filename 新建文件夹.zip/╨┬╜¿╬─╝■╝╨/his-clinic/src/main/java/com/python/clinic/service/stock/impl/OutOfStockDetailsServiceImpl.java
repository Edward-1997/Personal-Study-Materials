package com.python.clinic.service.stock.impl;

import com.python.clinic.entity.stock.OutOfStockDetails;
import com.python.clinic.dao.stock.OutOfStockDetailsMapper;
import com.python.clinic.service.stock.OutOfStockDetailsService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 出库详情表 服务实现类
 * </p>
 *
 * @author hm
 * @since 2020-05-23
 */
@Service
public class OutOfStockDetailsServiceImpl extends ServiceImpl<OutOfStockDetailsMapper, OutOfStockDetails> implements OutOfStockDetailsService {

}
