package com.python.clinic.entity.diagnosis;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 门诊检查项目表
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-26
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_diagnosis_item")
@ApiModel(value="DiagnosisItem对象", description="门诊检查项目表")
public class DiagnosisItem extends Model<DiagnosisItem> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "诊断表id")
    private Integer diagnosisId;

    @ApiModelProperty(value = "数量")
    private Integer num;

    @ApiModelProperty(value = "总价格")
    private BigDecimal totalPrice;

    @ApiModelProperty(value = "诊疗项目id")
    private Integer relationId;

    @ApiModelProperty(value = "关联类型，0：诊疗项目，1：材料商品")
    private Integer relationType;

    @ApiModelProperty(value = "项目状态：0 待执行，1 已执行，2 已退")
    private Integer status;

    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
