package com.python.clinic.entity.stock;

import com.baomidou.mybatisplus.annotation.*;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 库存日志表，包含药品/物资、入库、出库操作记录
 * </p>
 *
 * @author hm
 * @since 2020-05-19
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_stock_log")
@ApiModel(value="StockLog对象", description="库存日志表，包含药品/物资、入库、出库操作记录")
@NoArgsConstructor
public class StockLog extends Model<StockLog> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "行为")
    private String action;

    @ApiModelProperty(value = "备注")
    private String remark;

    @ApiModelProperty(value = "创建时间")
    @TableField(value = "create_time" , fill = FieldFill.INSERT)
    private Date createTime;

    @ApiModelProperty(value = "创建人id")
    private Integer createId;

    @ApiModelProperty(value = "关联id")
    private Integer relationId;

    @ApiModelProperty(value = "关联类型，0：药品，1：采购，2：入库，3：出库，4：盘点，5：结算")
    private Integer relationType;

    @ApiModelProperty(value = "诊所id")
    private Integer clinicId;


    public StockLog(String action, Date createTime, Integer createId, Integer relationId, Integer relationType, Integer clinicId) {
        this.action = action;
        this.createTime = createTime;
        this.createId = createId;
        this.relationId = relationId;
        this.relationType = relationType;
        this.clinicId = clinicId;
    }

    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
