package com.python.clinic.service.patient.impl;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.python.clinic.dao.patient.*;
import com.python.clinic.dao.sys.ClinicMapper;
import com.python.clinic.entity.marketing.MemberCard;
import com.python.clinic.entity.marketing.dto.MemberCardDto;
import com.python.clinic.entity.patient.*;
import com.python.clinic.entity.patient.vo.MemberCardInfoVo;
import com.python.clinic.entity.sys.Clinic;
import com.python.clinic.service.marketing.MemberCardService;
import com.python.clinic.service.patient.PatientMemberCardService;
import com.python.common.response.CommonResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * <p>
 * 患者会员卡 服务实现类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-20
 */
@Service
public class PatientMemberCardServiceImpl extends ServiceImpl<PatientMemberCardMapper, PatientMemberCard> implements PatientMemberCardService {
    @Autowired
    private PatientMemberCardMapper patientMemberCardMapper;
    @Autowired
    private MemberCardService memberCardService;
    @Autowired
    private ClinicMapper clinicMapper;
    @Autowired
    private PatientMapper patientMapper;
    @Autowired
    private TransactionFlowMapper transactionFlowMapper;
    @Autowired
    private IntegralFlowMapper integralFlowMapper;
    @Autowired
    private PatientCardFamilyMapper patientCardFamilyMapper;


    @Override
    public Integer getStatisticsMember(Integer cardId) {
        return patientMemberCardMapper.selectCountForMemberCard(cardId);
    }

    @Override
    public CommonResult getMemberCard(Integer patientId) {
        PatientMemberCard patientMemberCard = new PatientMemberCard();
        patientMemberCard.setPatientId(patientId);
        QueryWrapper<PatientMemberCard> wrapper = new QueryWrapper<>(patientMemberCard);

        patientMemberCard = patientMemberCardMapper.selectOne(wrapper);
        if(patientMemberCard == null){
            return CommonResult.failed("患者未开通会员卡");
        }

        //获取患者会员卡家庭成员列表
        PatientCardFamily patientCardFamily = new PatientCardFamily();
        patientCardFamily.setPatientCardId(patientId);
        List<PatientMemberCard> list = patientMemberCardMapper.selectList(new QueryWrapper<>(patientMemberCard));

        MemberCardInfoVo memberCardInfo = getMemberCardInfo(patientMemberCard);
        memberCardInfo.setMemberShareInfos(list.stream()
                .map(memberCard -> patientMapper.selectById(memberCard.getPatientId()))
                .collect(Collectors.toList()));

        Map<String,Object> map = new HashMap<>();
        map.put("memberCardInfo",memberCardInfo);

        return CommonResult.success(map,"查询会员卡信息成功");
    }




    @Override
    public CommonResult deletePatientMemberCard(Integer id) {
        PatientMemberCard memberCard = patientMemberCardMapper.selectById(id);

        if(memberCard == null){
            return CommonResult.failed("删除账户不存在");
        }

        if(memberCard.getPrincipal().signum() == 1 || memberCard.getGiftAmount().signum() == 1){
            return CommonResult.failed("卡内还有余额");
        }

        if(1 ==patientMemberCardMapper.deleteById(id)){
            return CommonResult.success(null,"删除成功");
        }
        return CommonResult.failed("删除失败");
    }

    @Override
    public CommonResult selectMemberList(String orderFiled,Integer orderType,Integer pageSize, Integer pageNum) {
        //默认降序排序
        boolean isAsc = false;
        if(orderType != 0){
            isAsc = true;
        }
        IPage<PatientMemberCard> pages = new Page<>(pageNum,pageSize);
        IPage<PatientMemberCard> memberCardList = null;
        if(!orderFiled.equals("surplusCapital")){
            //如果排序字段不是 "surplusCapital" ，则直接在数据库进行排序
            memberCardList = patientMemberCardMapper.selectPage(pages, new QueryWrapper<PatientMemberCard>()
                    .orderBy(true,isAsc,orderFiled));
        }else {
            memberCardList = patientMemberCardMapper.selectPage(pages, new QueryWrapper<>());
        }


        if(memberCardList.getRecords().size()>0){
            if(!orderFiled.equals("surplusCapital")){
                memberCardList.convert(this::getMemberCardInfo);
            }else {
                //如果排序字段为按照当前剩余金额排序,剩余金额=当前本金余额+当前赠金余额
                memberCardList.convert(this::getMemberCardInfo).getRecords().sort((memberCardInfo1,memberCardInfo2)->{
                    int index = memberCardInfo2.getGiftAmount().add(memberCardInfo2.getPrincipal()).compareTo(
                            memberCardInfo1.getGiftAmount().add(memberCardInfo1.getPrincipal()));
                    if(orderType != 0){
                        return -index;
                    }
                    return index;
                });
            }

            Map<String,Object> map = new HashMap<>();
            map.put("memberCardList",memberCardList);
            return CommonResult.success(map,"查询列表成功");
        }
        return CommonResult.failed("查询列表失败");
    }

    @Transactional
    @Override
    public CommonResult updateMemberInfo(MemberCardInfoVo info) {
        Patient patient = new Patient();
        patient.setId(info.getId());
        patient.setPhone(info.getPhone());
        patient.setPatientName(info.getName());
        patient.setGender(info.getGender());
        patient.setAge(info.getAge());
        patient.setBirthday(info.getBirth());
        int index = patientMapper.updateById(patient);

        PatientMemberCard oldMemberCard = new PatientMemberCard();
        oldMemberCard.setPatientId(patient.getId());

        PatientMemberCard memberCard = new PatientMemberCard();
        memberCard.setCardId(info.getCardId());
        memberCard.setRemark(info.getRemark());
        index  += patientMemberCardMapper.update(memberCard,new QueryWrapper<PatientMemberCard>(oldMemberCard));

        if(index != 2){
            throw new RuntimeException("修改患者会员信息失败");
        }

        return CommonResult.success(null,"修改患者会员信息成功");
    }

    @Override
    public CommonResult insertMemberInfo(MemberCardInfoVo info) {
        //如果患者手机号有变化，则修改
        Patient patient = new Patient();
        patient.setId(info.getId());
        patient.setPhone(info.getPhone());

        int index = patientMapper.updateById(patient);

        //新增患者会员卡信息
        PatientMemberCard memberCard = new PatientMemberCard();
        memberCard.setPatientId(info.getId());
        memberCard.setCardId(info.getCardId());
        memberCard.setIntegral(0);
        memberCard.setTotalIntegral(0);
        memberCard.setPrincipal(new BigDecimal(0));
        memberCard.setGiftAmount(new BigDecimal(0));
        memberCard.setCreateDate(new Date());
        memberCard.setRemark(info.getRemark());

        index += patientMemberCardMapper.insert(memberCard);

        if(index != 2){
            throw new RuntimeException("新增会员失败");
        }
        return CommonResult.success(null,"新增会员成功");
    }

    @Transactional
    @Override
    public CommonResult updateMemberCapital(TransactionFlow record) {
        //获取患者信息
        PatientMemberCard memberCard = new PatientMemberCard();
        memberCard.setPatientId(record.getPatientCardId());
        memberCard = patientMemberCardMapper.selectOne(new QueryWrapper<>(memberCard));
        if(memberCard == null){
            return CommonResult.failed("数据异常：患者不是会员");
        }

        memberCard.setGiftAmount(memberCard.getGiftAmount().add(record.getPayGiftAmout()));
        memberCard.setPrincipal(memberCard.getPrincipal().add(record.getPayPrincipal()));
        if(memberCard.getGiftAmount().signum() == -1 || memberCard.getPrincipal().signum() == -1){
            return CommonResult.failed("数据异常");
        }

        //修改患者会员的本金和赠送金
        int index = patientMemberCardMapper.updateById(memberCard);
        //新增患者交易流水记录
        record.setTransactionTime(new Date());
        record.setSurplusGiftAmout(memberCard.getGiftAmount());
        record.setSurplusPrincipal(memberCard.getPrincipal());

        index += transactionFlowMapper.insert(record);
        if(index != 2){
            throw new RuntimeException("交易失败");
        }

        return CommonResult.success(null,"交易成功");
    }

    @Override
    public CommonResult updateMemberIntegral(IntegralFlow record) {
        //获取患者会员卡信息
        PatientMemberCard patientMemberCard = new PatientMemberCard();
        patientMemberCard.setCardId(record.getPatientCardId());
        patientMemberCard = patientMemberCardMapper.selectOne(new QueryWrapper<>(patientMemberCard));
        if(patientMemberCard == null ){
            return CommonResult.failed("数据异常：患者无会员卡");
        }

        //设置患者会员卡当前积分
        patientMemberCard.setIntegral(patientMemberCard.getIntegral()+record.getIntegralChange());
        if(patientMemberCard.getIntegral()<0){
            return CommonResult.failed("数据异常：患者当前积分小于0");
        }

        int index = patientMemberCardMapper.updateById(patientMemberCard);
        //完善积分流水记录
        record.setTransactionTime(new Date());
        record.setSurplusIntegral(patientMemberCard.getIntegral());

        index += integralFlowMapper.insert(record);
        if(index != 2){
            throw new RuntimeException("患者积分交易失败");
        }
        return CommonResult.success(null,"积分交易成功");
    }


    /**
     * 将信息转化为患者会员信息
     **/
    private MemberCardInfoVo getMemberCardInfo(PatientMemberCard patientMemberCard){
        MemberCardDto memberCardDto = memberCardService.selectMemberCardInfo(patientMemberCard.getCardId());
        MemberCard memberCard = memberCardDto.getMemberCard();
        Clinic clinic = clinicMapper.selectById(memberCard.getClinicId());

        Patient patient = patientMapper.selectById(patientMemberCard.getPatientId());

        MemberCardInfoVo vo = new MemberCardInfoVo();
        vo.setName(patient.getPatientName());
        vo.setId(patientMemberCard.getPatientId());
        vo.setPhone(patient.getPhone());
        vo.setAge(patient.getAge());
        vo.setBirth(patient.getBirthday());
        vo.setGender(patient.getGender());
        vo.setBenefits(memberCard.getBenefits());
        vo.setCardName(memberCard.getCardName());
        vo.setClinicName(clinic.getClinicName());
        vo.setIntegral(patientMemberCard.getIntegral());
        vo.setTotalIntegral(patientMemberCard.getTotalIntegral());
        vo.setPrincipal(patientMemberCard.getPrincipal());
        vo.setGiftAmount(patientMemberCard.getGiftAmount());
        vo.setCreateDate(patientMemberCard.getCreateDate());
        vo.setRemark(patientMemberCard.getRemark());
        return vo;
    }
}
