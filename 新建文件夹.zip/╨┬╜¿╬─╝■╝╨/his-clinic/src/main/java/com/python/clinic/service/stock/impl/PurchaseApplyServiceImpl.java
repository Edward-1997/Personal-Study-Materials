package com.python.clinic.service.stock.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.python.clinic.dao.stock.PurchaseGoodsMapper;
import com.python.clinic.entity.stock.PurchaseApply;
import com.python.clinic.dao.stock.PurchaseApplyMapper;
import com.python.clinic.entity.stock.StockLog;
import com.python.clinic.entity.stock.dto.PurchaseApplyDTO;
import com.python.clinic.service.stock.PurchaseApplyService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.python.clinic.utils.CodeUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

/**
 * <p>
 * 采购申请表 服务实现类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-21
 */
@Service
public class PurchaseApplyServiceImpl extends ServiceImpl<PurchaseApplyMapper, PurchaseApply> implements PurchaseApplyService {

    @Resource
    private PurchaseApplyMapper purchaseApplyMapper;
    @Resource
    private PurchaseGoodsMapper purchaseGoodsMapper;

    @Override
    public IPage<PurchaseApply> listPurchaseApply(IPage<PurchaseApply> page,Integer status,Integer dateType,
                                                  Date startTime, Date endTime, String goodsId) {
        return purchaseApplyMapper.listPurchaseApply(page,status,dateType,startTime,endTime,goodsId);
    }

    @Override
    @Transactional(propagation= Propagation.REQUIRED,isolation= Isolation.DEFAULT,rollbackFor= RuntimeException.class)
    public boolean savePurchaseApply(PurchaseApplyDTO purchaseApplyDTO) {
        PurchaseApply purchaseApply = purchaseApplyDTO.getPurchaseApply();
        purchaseApply.setPurchaseCode(CodeUtil.getOrderCode("CG"));
        purchaseApplyMapper.insert(purchaseApply);
        purchaseGoodsMapper.saveBatch(purchaseApplyDTO.getPurchaseGoodsList());
        return true;
    }
}
