package com.python.clinic.service.sys;

import com.python.clinic.entity.sys.Department;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 * 科室表 服务类
 * </p>
 *
 * @author hm
 * @since 2020-06-02
 */
public interface DepartmentService extends IService<Department> {

    /**
     * 获取科室列表
     * @return
     */
    List<Department> listDepartment();

    /**
     * 添加科室
     * @param department
     * @return
     */
    boolean saveDepartment(Department department);

    /**
     * 修改科室
     * @param department
     * @return
     */
    boolean updateDepartment(Department department);

    /**
     * 查看科室详情
     * @param id
     * @return
     */
    Department getDepartment(Integer id);

}
