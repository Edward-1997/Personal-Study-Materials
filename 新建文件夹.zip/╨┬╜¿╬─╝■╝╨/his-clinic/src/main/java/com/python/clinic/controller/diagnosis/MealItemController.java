package com.python.clinic.controller.diagnosis;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 套餐项目表 前端控制器
 * </p>
 *
 * @author hm
 * @since 2020-06-06
 */
@RestController
@RequestMapping("/meal-item")
public class MealItemController {

}
