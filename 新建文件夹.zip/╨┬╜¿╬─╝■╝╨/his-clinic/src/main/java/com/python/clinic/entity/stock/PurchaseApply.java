package com.python.clinic.entity.stock;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;

import com.python.clinic.entity.sys.Clinic;
import com.python.clinic.entity.user.User;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 采购申请表
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-21
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_purchase_apply")
@ApiModel(value="PurchaseApply对象", description="采购申请表")
public class PurchaseApply extends Model<PurchaseApply> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "采购计划名称")
    private String purchaseName;

    @ApiModelProperty(value = "采购申请单号")
    private String purchaseCode;

    @ApiModelProperty(value = "申请人id")
    private Integer applicantId;

    @ApiModelProperty(value = "申请门店id")
    private Integer clinicId;

    @ApiModelProperty(value = "备注")
    private String remark;

    @ApiModelProperty(value = "申请时间")
    private Date applyTime;

    @ApiModelProperty(value = "审核时间")
    private Date auditTime;

    @ApiModelProperty(value = "申请状态，0：待审核，1：已通过，2：已拒绝，3：已撤回")
    private Integer status;

    @ApiModelProperty(value = "品种")
    private Integer kindCount;

    @ApiModelProperty(value = "数量")
    private Integer total;

    @ApiModelProperty(value = "申请人")
    @TableField(exist = false)
    private User applicant;

    @ApiModelProperty(value = "申请诊所")
    @TableField(exist = false)
    private Clinic clinic;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
