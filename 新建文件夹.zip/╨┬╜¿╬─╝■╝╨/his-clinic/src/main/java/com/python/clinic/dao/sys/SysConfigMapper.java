package com.python.clinic.dao.sys;

import com.python.clinic.entity.sys.SysConfig;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 系统配置 Mapper 接口
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-21
 */
public interface SysConfigMapper extends BaseMapper<SysConfig> {

}
