package com.python.clinic.controller.marketing;


import com.python.clinic.entity.marketing.dto.CouponDetailsDto;
import com.python.clinic.service.marketing.CouponService;
import com.python.common.response.CommonResult;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * 优惠券表 前端控制器
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-05
 */
@RestController
@RequestMapping("/coupon")
public class CouponController {

    @Autowired
    private CouponService couponService;

    @ApiOperation(value = "获取优惠券列表",notes = "分页查询优惠券列表，默认查询全部，一页10条数据")
    @GetMapping("/list")
    public CommonResult getCouponList(@RequestParam(defaultValue = "10") Integer pageSize,
                                      @RequestParam(defaultValue = "1") Integer pageNum,
                                      @RequestParam(defaultValue = "-1") Integer status){
        Map<String,Object> map = new HashMap<>();
        map.put("couponList",couponService.selectCouponList(pageNum,pageSize,status));
        return CommonResult.success(map);
    }

    @ApiOperation(value = "获取优惠券详细信息",notes = "传入优惠券id，获取优惠券详细信息，包括使用范围")
    @GetMapping("/details/{id}")
    public CommonResult getCouponDetails(@PathVariable Integer id){
        Map<String,Object> map = new HashMap<>();
        map.put("couponDetails",couponService.selectCouponDetails(id));
        return CommonResult.success(map);
    }

    @ApiModelProperty(value = "新增商品优惠券",notes = "传入CouponDetailsDto,完成新增商品优惠券")
    @PostMapping("/save")
    public CommonResult insertCoupon(@RequestBody CouponDetailsDto couponDetailsDto){
        return couponService.insertCoupon(couponDetailsDto);
    }

    @ApiOperation(value = "编辑商品优惠券",notes="传入CouponDetailsDto,完成编辑商品优惠券")
    @PutMapping("/update")
    public CommonResult updateCoupon(@RequestBody CouponDetailsDto couponDetailsDto){
        return couponService.updateCoupon(couponDetailsDto);
    }

    @ApiOperation(value ="修改商品优惠券状态",notes = "传入优惠券id，状态，0：可发券 1：停止发券 2：已作废")
    @PutMapping("/status/{id}")
    public CommonResult updateCouponStatus(@PathVariable Integer id,@RequestParam Integer status){
        return couponService.updateCouponStatus(id,status);
    }
}
