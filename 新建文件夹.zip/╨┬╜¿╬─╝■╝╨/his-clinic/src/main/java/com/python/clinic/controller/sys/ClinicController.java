package com.python.clinic.controller.sys;


import com.python.clinic.entity.sys.Clinic;
import com.python.clinic.service.sys.ClinicService;
import com.python.common.response.CommonResult;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 * 诊所信息表 前端控制器
 * </p>
 *
 * @author hm
 * @since 2020-05-21
 */
@RestController
@RequestMapping("/clinic")
public class ClinicController {

    @Autowired
    private ClinicService clinicService;

    @PostMapping("/saveClinic")
    @ApiOperation("添加诊所")
    public CommonResult saveClinic(@RequestBody Clinic clinic){
        return CommonResult.result(clinicService.save(clinic));
    }

    @PutMapping("/updateClinic")
    @ApiOperation("修改诊所")
    public CommonResult updateClinic(@RequestBody Clinic clinic){
        return CommonResult.result(clinicService.updateById(clinic));
    }

}
