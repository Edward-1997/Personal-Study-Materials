package com.python.clinic.service.stock;

import com.python.clinic.entity.stock.Supplier;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 供应商表 服务类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-22
 */
public interface SupplierService extends IService<Supplier> {

}
