package com.python.clinic.service.stock.impl;

import com.python.clinic.entity.stock.Supplier;
import com.python.clinic.dao.stock.SupplierMapper;
import com.python.clinic.service.stock.SupplierService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 供应商表 服务实现类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-22
 */
@Service
public class SupplierServiceImpl extends ServiceImpl<SupplierMapper, Supplier> implements SupplierService {

}
