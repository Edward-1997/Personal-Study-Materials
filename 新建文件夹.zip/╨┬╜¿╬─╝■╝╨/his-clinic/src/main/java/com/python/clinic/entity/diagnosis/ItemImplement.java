package com.python.clinic.entity.diagnosis;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 治疗项目执行记录表
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-28
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_item_implement")
@ApiModel(value="ItemImplement对象", description="治疗项目执行记录表")
public class ItemImplement extends Model<ItemImplement> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "执行人")
    private String executor;

    @ApiModelProperty(value = "执行次数")
    private Integer executorNum;

    @ApiModelProperty(value = "执行时间")
    private Date executorTime;

    @ApiModelProperty(value = "登记人")
    private String registrant;

    @ApiModelProperty(value = "状态，0：待执行  1：已撤销")
    private Integer status;

    @ApiModelProperty(value = "撤销者")
    private String repealer;

    @ApiModelProperty(value = "撤销时间")
    private Date repealerTime;

    @ApiModelProperty(value = "检查项目id")
    private Integer itemId;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
