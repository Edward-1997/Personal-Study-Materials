package com.python.clinic.controller.stock;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 出库详情表 前端控制器
 * </p>
 *
 * @author hm
 * @since 2020-05-23
 */
@RestController
@RequestMapping("/out-of-stock-details")
public class OutOfStockDetailsController {

}
