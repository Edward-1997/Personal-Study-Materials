package com.python.clinic.dao.marketing;

import com.python.clinic.entity.marketing.PreferentialDetails;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 优惠详情表 Mapper 接口
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-05
 */
public interface PreferentialDetailsMapper extends BaseMapper<PreferentialDetails> {

}
