package com.python.clinic.entity.marketing;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 优惠券例外商品
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-05
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_exception_goods")
@ApiModel(value="ExceptionGoods对象", description="优惠券例外商品")
public class ExceptionGoods extends Model<ExceptionGoods> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "使用范围id")
    private Integer useScopeId;

    @ApiModelProperty(value = "商品id")
    private Integer goodsId;


    @Override
    protected Serializable pkVal() {
        return null;
    }

}
