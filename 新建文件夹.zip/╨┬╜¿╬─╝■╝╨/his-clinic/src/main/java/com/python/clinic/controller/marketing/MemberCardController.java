package com.python.clinic.controller.marketing;


import com.python.clinic.entity.marketing.dto.MemberCardDto;
import com.python.clinic.service.marketing.MemberCardService;
import com.python.common.response.CommonResult;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * 会员卡 前端控制器
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-20
 */
@RestController
@RequestMapping("/member_card")
public class MemberCardController {
    @Autowired
    private MemberCardService memberCardService;

    @ApiOperation(value = "查询会员卡类型",
            notes = "分页查询，默认查询所有会员卡类型，pageSize:数量，pageNum:起始位置")
    @GetMapping("/types")
    public CommonResult getMemberCardList(@RequestParam(defaultValue = "-1") Integer pageSize,
                                          @RequestParam(defaultValue = "-1") Integer pageNum){
        return memberCardService.selectMemberCardList(pageSize,pageNum);
    }

    @ApiOperation(value="查询会员卡详情", notes = "传入会员卡id，查询会员卡详细信息")
    @GetMapping("/details/{id}")
    public CommonResult getMemberCardDetails(@PathVariable Integer id){
        MemberCardDto memberCardDto = memberCardService.selectMemberCardInfo(id);
        Map<String,Object> map = new HashMap<>();
        map.put("memberCardDetails",memberCardDto);
        return CommonResult.success(map,"查询会员卡详细信息成功");
    }

    @ApiOperation(value = "新增会员卡",notes = "传入MemberCardDto对象，完成新增会员卡操作")
    @PostMapping("/card")
    public CommonResult insertMemberCard(@RequestBody MemberCardDto memberCardDto){
        return memberCardService.insertMemberCard(memberCardDto);
    }

    @ApiOperation(value = "删除会员卡",notes = "传入会员卡id和折扣id，完成删除会员卡操作")
    @DeleteMapping("/card")
    public CommonResult deleteMemberCard(@RequestParam Integer cardId,@RequestParam Integer discountId){
        return memberCardService.deleteMemberCard(cardId,discountId);
    }

    @ApiOperation(value = "修改会员卡",notes = "传入MemberCardDto对象，完成更新会员卡操作")
    @PutMapping("/card")
    public CommonResult updateMemberCard(@RequestBody MemberCardDto memberCardDto){
        return memberCardService.updateMemberCard(memberCardDto);
    }
}
