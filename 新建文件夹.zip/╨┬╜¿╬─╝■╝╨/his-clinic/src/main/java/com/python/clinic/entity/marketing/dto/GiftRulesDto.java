package com.python.clinic.entity.marketing.dto;

import com.python.clinic.entity.marketing.GiftCoupon;
import com.python.clinic.entity.marketing.PreferentialSet;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/6/8 9:32
 **/
@Data
public class GiftRulesDto {

    @ApiModelProperty(value = "优惠基本设置")
    private PreferentialSet preferentialSet;

    @ApiModelProperty(value = "满减返列表，表示返还优惠券")
    private List<GiftCouponDto> giftCoupon;

    @ApiModelProperty(value = "满减返列表，表示返回商品")
    private List<GiftGoodDto> giftGoods;
}
