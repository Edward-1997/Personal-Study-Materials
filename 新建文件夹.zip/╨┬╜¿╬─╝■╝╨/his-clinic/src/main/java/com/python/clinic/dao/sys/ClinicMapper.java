package com.python.clinic.dao.sys;

import com.python.clinic.entity.sys.Clinic;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 诊所信息表 Mapper 接口
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-21
 */
public interface ClinicMapper extends BaseMapper<Clinic> {

    /**
     * 获取诊所id和名称
     * @param id
     * @return
     */
    Clinic getIdAndName(@Param("id")Integer id);

}
