package com.python.clinic.service.diagnosis.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.python.clinic.dao.diagnosis.ItemIndexMapper;
import com.python.clinic.entity.diagnosis.ItemIndex;
import com.python.clinic.entity.diagnosis.TreatmentItem;
import com.python.clinic.dao.diagnosis.TreatmentItemMapper;
import com.python.clinic.entity.diagnosis.dto.TreatmentItemDetailsDto;
import com.python.clinic.entity.diagnosis.vo.SetMealVo;
import com.python.clinic.entity.enums.GoodsAndTreatmentTypeEnum;
import com.python.clinic.entity.sys.Clinic;
import com.python.clinic.service.diagnosis.TreatmentItemService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.python.clinic.service.sys.ClinicService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

/**
 * <p>
 * 治疗项目表 服务实现类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-26
 */
@Service
public class TreatmentItemServiceImpl extends ServiceImpl<TreatmentItemMapper, TreatmentItem> implements TreatmentItemService {
    @Autowired
    private TreatmentItemMapper treatmentItemMapper;
    @Autowired
    private ClinicService clinicService;
    @Resource
    private ItemIndexMapper itemIndexMapper;

    @Override
    public IPage<TreatmentItemDetailsDto> getPatientTreatmentItemList(Integer patientId, Integer pageNum, Integer pageSize) {
        List<TreatmentItemDetailsDto> list = treatmentItemMapper.selectPatientItemList(patientId, (pageNum - 1)*pageSize, pageSize);

        Integer total = treatmentItemMapper.selectPatientItemListTotal(patientId);
        IPage<TreatmentItemDetailsDto> detailsDtoIPage = new Page<>();

        detailsDtoIPage.setCurrent(pageNum);
        detailsDtoIPage.setRecords(list.stream()
                .parallel()
                .peek(dto->{
                    Clinic info = clinicService.getClinicInfo(dto.getClinicId());
                    dto.setClinicName(info.getClinicName());
                })//获取诊所名字
                .sorted(Comparator.comparing(TreatmentItemDetailsDto::getDiagnosisTime).reversed())//按照时间进行降序排序
                .collect(Collectors.toList()));
        detailsDtoIPage.setSize(pageSize);
        detailsDtoIPage.setTotal(total);

        return detailsDtoIPage;
    }

    @Override
    @Transactional(propagation= Propagation.REQUIRED,isolation= Isolation.DEFAULT,rollbackFor= RuntimeException.class)
    public boolean saveTreatmentItem(TreatmentItem treatmentItem) {
        boolean flag = treatmentItemMapper.insert(treatmentItem) > 0;
        if (flag) {
            //若type为3(检查检验),则添加指标项
            List<ItemIndex> itemIndexList = treatmentItem.getItemIndexList();
            if (treatmentItem.getType().equals(GoodsAndTreatmentTypeEnum.INSPECT.getValue()) && itemIndexList != null
                    && itemIndexList.isEmpty()){
                itemIndexMapper.insertBatch(itemIndexList,treatmentItem.getId());
            }
        }
        return flag;
    }

    @Override
    @Transactional(propagation= Propagation.REQUIRED,isolation= Isolation.DEFAULT,rollbackFor= RuntimeException.class)
    public boolean updateTreatmentItem(TreatmentItem treatmentItem) {
        boolean flag = treatmentItemMapper.updateById(treatmentItem) > 0;
        if (flag) {
            //若type为3(检查检验),则添加指标项
            List<ItemIndex> itemIndexList = treatmentItem.getItemIndexList();
            if (treatmentItem.getType().equals(GoodsAndTreatmentTypeEnum.INSPECT.getValue())){
                itemIndexMapper.delete(new QueryWrapper<ItemIndex>().eq("item_id",treatmentItem.getId()));
                if (itemIndexList != null  && itemIndexList.isEmpty()){
                    itemIndexMapper.insertBatch(itemIndexList,treatmentItem.getId());
                }
            }
        }
        return flag;
    }

    @Override
    public IPage<TreatmentItem> listTreatmentItem(IPage<TreatmentItem> page,Integer type, Integer subType, Integer itemName, Integer clinicId) {
        return treatmentItemMapper.listTreatmentItem(page,type, subType, itemName, clinicId);
    }

    @Override
    public IPage<SetMealVo> listSetMeal(IPage<SetMealVo> page,Integer itemName, Integer clinicId) {
        return treatmentItemMapper.listSetMeal(page, itemName, clinicId);
    }

    @Override
    public SetMealVo getSetMeal(Integer setMealId) {
        return treatmentItemMapper.getSetMeal(setMealId);
    }

}
