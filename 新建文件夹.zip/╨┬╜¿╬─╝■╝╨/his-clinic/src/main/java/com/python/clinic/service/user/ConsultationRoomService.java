package com.python.clinic.service.user;

import com.python.clinic.entity.user.ConsultationRoom;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 诊室表 服务类
 * </p>
 *
 * @author hm
 * @since 2020-06-03
 */
public interface ConsultationRoomService extends IService<ConsultationRoom> {

}
