package com.python.clinic.service.marketing.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.python.clinic.entity.marketing.*;
import com.python.clinic.dao.marketing.GiftRulePromotionsMapper;
import com.python.clinic.entity.marketing.constant.MarketingConstant;
import com.python.clinic.entity.marketing.dto.GiftCouponDto;
import com.python.clinic.entity.marketing.dto.GiftDetailsDto;
import com.python.clinic.entity.marketing.dto.GiftRulesDto;
import com.python.clinic.entity.marketing.vo.GiftListVo;
import com.python.clinic.service.marketing.GiftMemberService;
import com.python.clinic.service.marketing.GiftRulePromotionsService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.python.clinic.service.marketing.PreferentialSetService;
import com.python.clinic.service.marketing.UseScopeService;
import com.python.common.response.CommonResult;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * <p>
 * 满减返活动表 服务实现类
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-05
 */
@Service
public class GiftRulePromotionsServiceImpl extends ServiceImpl<GiftRulePromotionsMapper, GiftRulePromotions> implements GiftRulePromotionsService {

    @Autowired
    private GiftRulePromotionsMapper giftRulePromotionsMapper;
    @Autowired
    private UseScopeService useScopeService;
    @Autowired
    private GiftMemberService giftMemberService;
    @Autowired
    private PreferentialSetService preferentialSetService;

    @Override
    public GiftDetailsDto getGiftDetails(Integer id) {
        GiftDetailsDto giftDetailsDto = new GiftDetailsDto();
        //获取满减返活动详情
        giftDetailsDto.setGiftRulePromotions(giftRulePromotionsMapper.selectById(id));
        //获取满减返活动适用范围
        UseScope useScope = new UseScope();
        useScope.setRelationId(id);
        useScope.setType(MarketingConstant.UseScope.GIFT_TYPE);//适用范围为满减返

        giftDetailsDto.setUseScopeList(useScopeService.getUseScopeList(useScope));
        //获取领取范围详情
        if(!MarketingConstant.ALL_PATIENT.equals(giftDetailsDto.getGiftRulePromotions().getActivityObject())){
            //领取范围是指定会员卡
            GiftMember giftMember = new GiftMember();
            giftMember.setGiftId(id);
            giftDetailsDto.setGiftMemberList(giftMemberService.getGiftMemberList(giftMember));
        }

        //获取优惠设置列表
        giftDetailsDto.setGiftRulesList(preferentialSetService.getGiftRulesVoList(id));
        return giftDetailsDto;
    }

    @Override
    public IPage<GiftListVo> getGiftList(Integer status, Integer pageNum, Integer pageSize) {
        IPage<GiftRulePromotions> page = new Page<>(pageNum,pageSize);

        page = giftRulePromotionsMapper.selectPage(page, new QueryWrapper<GiftRulePromotions>().orderByAsc("status"));

        return page.convert(giftRulePromotion ->{
            GiftListVo vo = new GiftListVo();

            vo.setId(giftRulePromotion.getId());
            vo.setName(giftRulePromotion.getActivityName());
            vo.setStatus(giftRulePromotion.getStatus());
            //拼接活动详情字符串
            vo.setDetails(getGiftDetail(preferentialSetService.getGiftRulesVoList(giftRulePromotion.getId())));
            return vo;
        } );
    }

    @Transactional
    @Override
    public CommonResult insertGiftPromotion(GiftDetailsDto giftDetailsDto) {
        int index = 0;

        //新增满减活动基本信息
        GiftRulePromotions giftRulePromotions = giftDetailsDto.getGiftRulePromotions();
        giftRulePromotions.setStatus(MarketingConstant.GiftRulePromotion.ONGOING_STATUS);
        if(1==giftRulePromotions.getActivityTime()){
            if(giftRulePromotions.getStartTime().after(new Date())){
                giftRulePromotions.setStatus(MarketingConstant.GiftRulePromotion.NOT_START_STATUS);
            }
        }
        if(1 !=giftRulePromotionsMapper.insert(giftRulePromotions)){
            throw new RuntimeException();
        }
        //新增满减返活动参与范围
        for(UseScope useScope:giftDetailsDto.getUseScopeList()){
            if(null==useScopeService.insertUseScope(useScope)){//新增使用范围失败
                throw new RuntimeException();
            }
        }
        //新增满减活动指定会员
        if(!MarketingConstant.ALL_PATIENT.equals(giftRulePromotions.getActivityObject())){
            boolean flag = giftMemberService.saveBatch(giftDetailsDto.getGiftMemberList()
                    .stream()
                    .peek(giftMember -> giftMember.setGiftId(giftRulePromotions.getId()))
                    .collect(Collectors.toList()));
            if(!flag){//新增指定会员失败
                throw new RuntimeException();
            }
        }

        //新增优惠设置
        if(null == preferentialSetService.insertGiftPreferential(
                giftDetailsDto.getGiftRulesList()
                        .stream()
                        .peek(giftRulesDto -> giftRulesDto.getPreferentialSet().setGiftId(giftRulePromotions.getId()))
                        .collect(Collectors.toList()))){
            throw new RuntimeException();
        }

        return CommonResult.success(null,"新增成功");
    }

    @Override
    public CommonResult terminateGiftActivity(Integer id) {
        GiftRulePromotions giftRulePromotions = new GiftRulePromotions();
        giftRulePromotions.setId(id);
        //设置终止状态
        giftRulePromotions.setStatus(MarketingConstant.GiftRulePromotion.FINISHED_STATUS);

        if(1==giftRulePromotionsMapper.updateById(giftRulePromotions)){
            return CommonResult.success(null,"终止成功");
        }
        return CommonResult.failed("终止失败");
    }

    @Transactional
    @Override
    public CommonResult updateGiftPromotion(GiftDetailsDto giftDetailsDto) {
        //修改满减基本信息
        GiftRulePromotions giftRulePromotions = giftDetailsDto.getGiftRulePromotions();
        giftRulePromotions.setStatus(MarketingConstant.GiftRulePromotion.ONGOING_STATUS);
        if(1==giftRulePromotions.getActivityTime()){
            if(giftRulePromotions.getStartTime().after(new Date())){
                giftRulePromotions.setStatus(MarketingConstant.GiftRulePromotion.NOT_START_STATUS);
            }
        }
        if(1 !=giftRulePromotionsMapper.updateById(giftRulePromotions)){
            throw new RuntimeException();
        }

        //删除旧的使用范围，包括例外商品
        UseScope oldUseScope = new UseScope();
        oldUseScope.setType(MarketingConstant.UseScope.GIFT_TYPE);
        oldUseScope.setRelationId(giftRulePromotions.getId());
        if(null == useScopeService.deleteUseScope(oldUseScope)){
            throw new RuntimeException();
        }
        //新增使用范围及例外商品
        for(UseScope useScope:giftDetailsDto.getUseScopeList()){
            if(null==useScopeService.insertUseScope(useScope)){//新增使用范围失败
                throw new RuntimeException();
            }
        }
        //删除旧的优惠设置
        if(null ==preferentialSetService.deleteGiftPreferential(giftRulePromotions.getId())){
            throw new RuntimeException();
        }

        //新增优惠设置
        if(null == preferentialSetService.insertGiftPreferential(
                giftDetailsDto.getGiftRulesList()
                        .stream()
                        .peek(giftRulesDto -> giftRulesDto.getPreferentialSet().setGiftId(giftRulePromotions.getId()))
                        .collect(Collectors.toList()))){
            throw new RuntimeException();
        }

        //删除旧的满减指定会员
        GiftMember oldGiftMember = new GiftMember();
        oldGiftMember.setGiftId(giftRulePromotions.getId());
        giftMemberService.remove(new QueryWrapper<>(oldGiftMember));

        //新增满减活动指定会员
        if(!MarketingConstant.ALL_PATIENT.equals(giftRulePromotions.getActivityObject())){
            boolean flag = giftMemberService.saveBatch(giftDetailsDto.getGiftMemberList()
                    .stream()
                    .peek(giftMember -> giftMember.setGiftId(giftRulePromotions.getId()))
                    .collect(Collectors.toList()));
            if(!flag){//新增指定会员失败
                throw new RuntimeException();
            }
        }
        return CommonResult.success(null);
    }

    //拼接活动详情字符串
    private String getGiftDetail(List<GiftRulesDto> giftRulesVoList){
        StringBuilder str = new StringBuilder();

        for(GiftRulesDto dto : giftRulesVoList){
            if(Integer.valueOf(1).equals(dto.getPreferentialSet().getFullReduce())){
                if(Integer.valueOf(1).equals(dto.getPreferentialSet().getCycle())){
                    str.append("每满￥");
                }else{
                    str.append("满￥");
                }
                str.append(dto.getPreferentialSet().getOrderThresholdPrice());
                str.append("减￥");
                str.append(dto.getPreferentialSet().getDiscountedPrice());
                str.append(",");
            }

            if(Integer.valueOf(1).equals(dto.getPreferentialSet().getFullReturn())){
                str.append("返优惠券");
                int count = 0;
                for(GiftCouponDto giftCouponDto:dto.getGiftCoupon()){//统计总数
                    count+=giftCouponDto.getCount();
                }
                str.append(count);
                str.append("张,");
            }

            if(Integer.valueOf(1).equals(dto.getPreferentialSet().getFullGive())){
                str.append("赠品");
                str.append(dto.getGiftGoods().size());
                str.append("项");
            }
            str.append(";");
        }
        return str.toString();
    }

}
