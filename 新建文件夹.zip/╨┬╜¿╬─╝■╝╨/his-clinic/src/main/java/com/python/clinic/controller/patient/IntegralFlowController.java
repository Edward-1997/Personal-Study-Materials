package com.python.clinic.controller.patient;


import com.python.clinic.entity.patient.IntegralFlow;
import com.python.clinic.entity.patient.TransactionFlow;
import com.python.clinic.service.patient.IntegralFlowService;
import com.python.common.response.CommonResult;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 * 积分流水 前端控制器
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-20
 */
@RestController
@RequestMapping("/integral_flow")
public class IntegralFlowController {
    @Autowired
    private IntegralFlowService integralFlowService;

    @GetMapping("/details/{cardId}")
    @ApiOperation(value = "获取积分流水列表",notes = "分页查询，默认一页10条记录。pageSize:数量，pageNnum:起始位置")
    public CommonResult getTransactionDetails(@RequestParam(defaultValue = "1") Integer pageNum,
                                              @RequestParam(defaultValue = "10") Integer pageSize,
                                              @PathVariable Integer cardId){
        return integralFlowService.getIntegralFlowList(cardId,pageSize,pageNum);
    }


}
