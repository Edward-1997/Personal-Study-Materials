package com.python.clinic.service.marketing.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.python.clinic.entity.marketing.DiscountActivities;
import com.python.clinic.entity.marketing.DiscountMember;
import com.python.clinic.entity.marketing.DiscountSetting;
import com.python.clinic.dao.marketing.DiscountSettingMapper;
import com.python.clinic.entity.marketing.constant.MarketingConstant;
import com.python.clinic.entity.marketing.dto.ConflictSettingDto;
import com.python.clinic.entity.marketing.dto.DiscountSettingDto;
import com.python.clinic.entity.stock.Goods;
import com.python.clinic.service.marketing.DiscountActivitiesService;
import com.python.clinic.service.marketing.DiscountMemberService;
import com.python.clinic.service.marketing.DiscountSettingService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.python.clinic.service.marketing.MemberCardService;
import com.python.clinic.service.stock.GoodsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * <p>
 * 折扣设置表 服务实现类
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-02
 */
@Service
public class DiscountSettingServiceImpl extends ServiceImpl<DiscountSettingMapper, DiscountSetting> implements DiscountSettingService {

    @Autowired
    private DiscountSettingMapper discountSettingMapper;
    @Autowired
    private GoodsService goodsService;
    @Autowired
    private DiscountActivitiesService discountActivitiesService;
    @Autowired
    private DiscountMemberService discountMemberService;
    @Autowired
    private MemberCardService memberCardService;

    @Override
    public List<DiscountSettingDto> getDiscountSettingList(DiscountSetting discountSetting) {
        List<DiscountSetting> discountSettings = discountSettingMapper.selectList(new QueryWrapper<>(discountSetting));

        //将基本的折扣设置转换为数据传输对象
        return discountSettings.stream().map(setting->{
            DiscountSettingDto dto = new DiscountSettingDto();
            dto.setPromotionId(setting.getDiscountId());
            dto.setDiscount(setting.getDiscount());
            if(setting.getType()<0){//如果为单品
                dto.setType(1);//设置类型为单品
                Goods goods = goodsService.getById(setting.getGoodsId());

                dto.setGoods(goods);
                dto.setGoodsType(goods.getType());
                dto.setGoodsSubType(goods.getSubType());
                dto.setGoodsId(goods.getId());
            }
            return dto;
        }).sorted((setting1,setting2)->{
            if(setting1.getGoodsId() != null || setting2.getGoodsId() != null){
                //两个设置中有一个是单品设置不排序
                return 0;
            }

            if(setting1.getGoodsType()<setting2.getGoodsType()){
               return -1;
            }else if(setting1.getGoodsType()>setting2.getGoodsType()){
                return 1;
            }else if(setting1.getGoodsType().equals(setting2.getGoodsType())){
                //说明两个设置的商品同类型，然后比较子类型
                if(setting1.getGoodsSubType()<setting2.getGoodsSubType()){
                    return -1;
                }else {
                    return 1;
                }
            }
            return 0;
        }).collect(Collectors.toList());
    }

    @Override
    public Integer getDiscountStatistic(Integer discountId) {
        return discountSettingMapper.getDiscountGoodsCount(discountId);
    }

    @Override
    public Integer getConflictDiscountSettingCount(Integer discountId) {
        return discountSettingMapper.getDiscountConflictCount(discountId);
    }

    @Override
    public List<ConflictSettingDto> getConflictSettingList(Integer discountId) {
        List<DiscountSetting> conflictLists = discountSettingMapper.getDiscountConflictList(discountId);

        return conflictLists.stream()
                .map(discountSettingConflict->{
                    ConflictSettingDto dto = new ConflictSettingDto();
                    DiscountActivities activity = discountActivitiesService.getById(discountId);
                    dto.setDiscountActivities(activity);
                    dto.setGoods(goodsService.getById(discountSettingConflict.getGoodsId()));
                    dto.setDiscount(discountSettingConflict.getDiscount());
                    //设置活动对象
                    if(MarketingConstant.ALL_PATIENT.equals(activity.getActivityObject())){
                        dto.setApplicators(Collections.singletonList("所有患者"));
                    }else {
                        DiscountMember discountMember = new DiscountMember();
                        discountMember.setDiscountId(activity.getId());
                        List<DiscountMember> discountMemberList = discountMemberService.getDiscountMemberList(discountMember);

                        dto.setApplicators(discountMemberList.stream()
                                .map(discount -> memberCardService.getById(discount.getMemberCardId()).getCardName())
                                .collect(Collectors.toList()));
                    }
                    return dto;
                })
                .collect(Collectors.toList());
    }
}
