package com.python.clinic.entity.stock;

import java.math.BigDecimal;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import java.util.List;
import java.util.Map;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 盘点详情表
 * </p>
 *
 * @author hm
 * @since 2020-05-27
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_inventory_details")
@ApiModel(value="InventoryDetails对象", description="盘点详情表")
public class InventoryDetails extends Model<InventoryDetails> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "盘点表id")
    private Integer inventoryId;

    @ApiModelProperty(value = "入库批次id")
    private Integer batchId;

    @ApiModelProperty(value = "商品id")
    private Integer goodsId;

    @ApiModelProperty(value = "整装账面数量")
    private Integer beforePackageCount;

    @ApiModelProperty(value = "散装账面数量")
    private Integer beforePieceCount;

    @ApiModelProperty(value = "整装实际数量")
    private Integer packageCount;

    @ApiModelProperty(value = "散装实际数量")
    private Integer pieceCount;

    @ApiModelProperty(value = "整装盈亏数量")
    private Integer packageCountChange;

    @ApiModelProperty(value = "散装盈亏数量")
    private Integer pieceCountChange;

    @ApiModelProperty(value = "盈亏金额(进价)")
    private BigDecimal totalCostPriceChange;

    @ApiModelProperty(value = "盈亏金额(售价)")
    private BigDecimal totalPriceChange;

    @ApiModelProperty(value = "整装单位")
    private String packageUnit;

    @ApiModelProperty(value = "散装单位")
    private String pieceUnit;

    @ApiModelProperty(value = "商品名称")
    private String goodsName;

    @ApiModelProperty(value = "类型，6：中药，7：西药，8：中成药")
    private Integer goodsType;

    @ApiModelProperty(value = "等级")
    private String level;

    @ApiModelProperty(value = "商品编码")
    private String goodsCode;

    @ApiModelProperty(value = "指定批次，0：false，1：true")
    private Boolean specifyBatch;

    @ApiModelProperty(value = "出库批次对象，指定批次时使用该对象")
    @TableField(exist = false)
    private WarehousingBatch warehousingBatch;

    @ApiModelProperty(value = "出库批次集合，未指定批次时使用该集合")
    @TableField(exist = false)
    private List<Map<String,Object>> inventoryBatchList;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
