package com.python.clinic.entity.stock;

import java.math.BigDecimal;

import com.baomidou.mybatisplus.annotation.*;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.util.Date;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 入库批次表
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-22
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_warehousing_batch")
@ApiModel(value="WarehousingBatch对象", description="入库批次表")
public class WarehousingBatch extends Model<WarehousingBatch> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "批次")
    private String batch;

    @ApiModelProperty(value = "生产批号")
    private String batchNo;

    @ApiModelProperty(value = "生产日期")
    private Date productionDate;

    @ApiModelProperty(value = "有效期")
    private Date expiryDate;

    @ApiModelProperty(value = "数量")
    private Double number;

    @ApiModelProperty(value = "单位")
    private String unit;

    @ApiModelProperty(value = "进价")
    private BigDecimal purchasePrice;

    @ApiModelProperty(value = "整装进价")
    private BigDecimal packagePrice;

    @ApiModelProperty(value = "含税金额")
    private BigDecimal taxAmount;

    @ApiModelProperty(value = "不含税金额")
    private BigDecimal noTaxAmount;

    @ApiModelProperty(value = "商品id")
    private Integer goodsId;

    @ApiModelProperty(value = "入库id")
    private Integer warehousingId;

    @ApiModelProperty(value = "剩余整装库存")
    private Integer packageCount;

    @ApiModelProperty(value = "剩余散装库存")
    private Integer pieceCount;

    @ApiModelProperty(value = "药品编码")
    private String goodsCode;

    @ApiModelProperty(value = "药品名称")
    private String goodsName;

    @ApiModelProperty(value = "进项税率")
    private BigDecimal inTaxRat;

    @ApiModelProperty(value = "出项税率")
    private BigDecimal outTaxRat;

    @ApiModelProperty(value = "生产厂家")
    private String manufacturer;

    @ApiModelProperty(value = "创建时间")
    @TableField(value = "create_time" , fill = FieldFill.INSERT)
    private Date createTime;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
