package com.python.clinic.controller.marketing;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 满减活动指定会员 前端控制器
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-05
 */
@RestController
@RequestMapping("/gift-member")
public class GiftMemberController {

}
