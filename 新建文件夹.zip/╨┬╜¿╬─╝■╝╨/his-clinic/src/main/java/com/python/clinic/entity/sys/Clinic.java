package com.python.clinic.entity.sys;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 诊所信息表
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-21
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_clinic")
@ApiModel(value="Clinic对象", description="诊所信息表")
public class Clinic extends Model<Clinic> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "诊所名称")
    private String clinicName;

    @ApiModelProperty(value = "诊所地址")
    private String address;

    @ApiModelProperty(value = "联系电话1")
    private String phone1;

    @ApiModelProperty(value = "联系电话2")
    private String phone2;

    @ApiModelProperty(value = "执业许可科目")
    private String licenseSubject;

    @ApiModelProperty(value = "诊所logo")
    private String logo;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
