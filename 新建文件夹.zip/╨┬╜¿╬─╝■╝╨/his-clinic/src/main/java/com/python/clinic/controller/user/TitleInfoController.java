package com.python.clinic.controller.user;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.python.clinic.entity.user.TitleInfo;
import com.python.clinic.service.user.TitleInfoService;
import com.python.common.response.CommonResult;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 * 职称信息表 前端控制器
 * </p>
 *
 * @author hm
 * @since 2020-06-02
 */
@RestController
@RequestMapping("/titleInfo")
public class TitleInfoController {

    @Autowired
    private TitleInfoService titleInfoService;

    @GetMapping("/getTitleType")
    @ApiOperation("获取医执人员类别")
    public CommonResult getTitleType(){
        QueryWrapper<TitleInfo> wrapper = new QueryWrapper<>();
        wrapper.isNull("parent_id");
        return CommonResult.success(titleInfoService.list(wrapper));
    }

    @GetMapping("/getTitle")
    @ApiOperation("获取职称")
    public CommonResult getTitle(Integer parentId){
        QueryWrapper<TitleInfo> wrapper = new QueryWrapper<>();
        if (parentId == null){
            wrapper.isNotNull("parent_id");
        }else {
            wrapper.eq("parent_id",parentId);
        }
        return CommonResult.success(titleInfoService.list(wrapper));
    }

}
