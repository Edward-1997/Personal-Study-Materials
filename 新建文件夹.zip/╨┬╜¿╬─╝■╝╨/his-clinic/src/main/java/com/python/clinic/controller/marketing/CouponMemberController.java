package com.python.clinic.controller.marketing;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 优惠券会员表 前端控制器
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-06
 */
@RestController
@RequestMapping("/coupon-member")
public class CouponMemberController {

}
