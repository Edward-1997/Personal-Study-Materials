package com.python.clinic.service.patient;

import com.python.clinic.entity.patient.Tags;
import com.baomidou.mybatisplus.extension.service.IService;
import com.python.common.response.CommonResult;

/**
 * <p>
 * 标签表 服务类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-21
 */
public interface TagsService extends IService<Tags> {

    /**
     * 查询某类型下所有标签
     * @author tanglong
     * @param tagType 标签类型
     * @return com.python.common.response.CommonResult
     * @throws
     * @since 2020/5/21 15:38
     * @see
     **/
    CommonResult selectTagListByTagType(Integer tagType);
    /**
     * 删除标签表中id，并同时删除患者表中含有该id的所有行
     * @param tagId 标签id
     * @throws Exception
     * @return boolean
     * @since 2020/5/21 9:39
     * @see
     **/
    boolean deleteTagAndPatientTag(Integer tagId) throws Exception;

    /**
     * 增加tag标签
     * @return com.python.common.response.CommonResult
     * @since 2020/5/21 11:01
     * @see
     **/
    CommonResult insertTag(Tags tag) throws Exception;

    /**
     * 修改tag标签
     * @author tanglong
     * @param tag 需要修改的tag
     * @return com.python.common.response.CommonResult
     * @throws
     * @since 2020/5/21 15:07
     * @see
     **/
    CommonResult updateTag(Tags tag) throws Exception;
}
