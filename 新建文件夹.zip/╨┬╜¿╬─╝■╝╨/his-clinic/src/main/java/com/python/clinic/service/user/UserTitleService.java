package com.python.clinic.service.user;

import com.python.clinic.entity.user.UserTitle;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 用户职称表 服务类
 * </p>
 *
 * @author hm
 * @since 2020-06-02
 */
public interface UserTitleService extends IService<UserTitle> {

}
