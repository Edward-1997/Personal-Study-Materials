package com.python.clinic.controller.diagnosis;


import io.swagger.annotations.ApiModelProperty;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 门诊检查项目表 前端控制器
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-26
 */
@RestController
@RequestMapping("/diagnosis_item")
public class DiagnosisItemController {


}
