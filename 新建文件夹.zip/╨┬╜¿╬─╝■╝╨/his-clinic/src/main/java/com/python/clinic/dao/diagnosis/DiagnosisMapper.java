package com.python.clinic.dao.diagnosis;

import com.python.clinic.entity.diagnosis.Diagnosis;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 门诊表 Mapper 接口
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-22
 */
public interface DiagnosisMapper extends BaseMapper<Diagnosis> {

}
