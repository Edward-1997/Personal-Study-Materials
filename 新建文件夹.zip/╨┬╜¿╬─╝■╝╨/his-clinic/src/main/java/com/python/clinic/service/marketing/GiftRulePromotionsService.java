package com.python.clinic.service.marketing;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.python.clinic.entity.marketing.GiftRulePromotions;
import com.baomidou.mybatisplus.extension.service.IService;
import com.python.clinic.entity.marketing.dto.GiftDetailsDto;
import com.python.clinic.entity.marketing.vo.GiftListVo;
import com.python.common.response.CommonResult;

/**
 * <p>
 * 满减返活动表 服务类
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-05
 */
public interface GiftRulePromotionsService extends IService<GiftRulePromotions> {

    /**
     * 通过id，获取满减返活动详情
     * @author tanglong
     * @return com.python.clinic.entity.marketing.dto.GiftDetailsDto
     * @since 2020/6/8 10:08
     **/
    GiftDetailsDto getGiftDetails(Integer id);

    /**
     * 分页查询满减返活动
     * @author tanglong
     * @return com.baomidou.mybatisplus.core.metadata.IPage<com.python.clinic.entity.marketing.vo.GiftListVo>
     * @since 2020/6/8 15:23
     **/
    IPage<GiftListVo> getGiftList(Integer status,Integer pageNum,Integer pageSize);

    /**
     * 新增满减返活动
     * @author tanglong
     * @return com.python.common.response.CommonResult
     * @since 2020/6/9 11:16
     **/
    CommonResult insertGiftPromotion(GiftDetailsDto giftDetailsDto);

    /**
     * 逻辑删除满减返活动，相关数据不进行物理删除
     * @author tanglong
     * @return com.python.common.response.CommonResult
     * @since 2020/6/9 11:17
     **/
    CommonResult terminateGiftActivity(Integer id);

    /**
     *  更新满减返活动的内容：
     *  1、删除部分旧的满减返活动
     *  2、重新插入新的满减返活动内容
     * @author tanglong
     * @return com.python.common.response.CommonResult
     * @since 2020/6/9 15:35
     **/
    CommonResult updateGiftPromotion(GiftDetailsDto giftDetailsDto);
}
