package com.python.clinic.service.sys.impl;

import com.python.clinic.entity.sys.Clinic;
import com.python.clinic.dao.sys.ClinicMapper;
import com.python.clinic.service.sys.ClinicService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 诊所信息表 服务实现类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-21
 */
@Service
public class ClinicServiceImpl extends ServiceImpl<ClinicMapper, Clinic> implements ClinicService {
    @Autowired
    private ClinicMapper clinicMapper;

    @Override
    public Clinic getClinicInfo(Integer id) {
        return clinicMapper.selectById(id);
    }
}
