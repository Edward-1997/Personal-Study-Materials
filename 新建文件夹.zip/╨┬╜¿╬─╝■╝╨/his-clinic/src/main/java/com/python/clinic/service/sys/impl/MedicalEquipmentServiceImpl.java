package com.python.clinic.service.sys.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.python.clinic.entity.sys.MedicalEquipment;
import com.python.clinic.dao.sys.MedicalEquipmentMapper;
import com.python.clinic.service.sys.MedicalEquipmentService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * <p>
 * 医疗设备表 服务实现类
 * </p>
 *
 * @author hm
 * @since 2020-06-02
 */
@Service
public class MedicalEquipmentServiceImpl extends ServiceImpl<MedicalEquipmentMapper, MedicalEquipment> implements MedicalEquipmentService {

    @Resource
    private MedicalEquipmentMapper medicalEquipmentMapper;

    @Override
    public IPage<MedicalEquipment> listMedicalEquipment(IPage<MedicalEquipment> page) {
        return medicalEquipmentMapper.listMedicalEquipment(page);
    }
}
