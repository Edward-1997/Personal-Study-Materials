package com.python.clinic.controller.user;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 用户信息表 前端控制器
 * </p>
 *
 * @author hm
 * @since 2020-06-02
 */
@RestController
@RequestMapping("/user-info")
public class UserInfoController {

}
