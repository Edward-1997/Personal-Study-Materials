package com.python.clinic.dao.user;

import com.python.clinic.entity.user.TreatScope;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 理疗范围 Mapper 接口
 * </p>
 *
 * @author hm
 * @since 2020-06-02
 */
public interface TreatScopeMapper extends BaseMapper<TreatScope> {

}
