package com.python.clinic.entity.sys;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import java.util.List;

import com.python.clinic.entity.user.User;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 科室表
 * </p>
 *
 * @author hm
 * @since 2020-06-02
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_department")
@ApiModel(value="Department对象", description="科室表")
public class Department extends Model<Department> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "科室名称")
    private String departmentName;

    @ApiModelProperty(value = "科室编码")
    private String departmentCode;

    @ApiModelProperty(value = "科室类型  0：诊疗科室  1：职能科室")
    private Integer type;

    @ApiModelProperty(value = "诊疗科目父级id")
    private Integer subjectParentId;

    @ApiModelProperty(value = "诊疗科目id")
    private Integer subjectId;

    @ApiModelProperty(value = "是否为门诊室  0：是   1：不是")
    private Integer consultationRoom;

    @ApiModelProperty(value = "科室负责人")
    private Integer head;

    @ApiModelProperty(value = "成立时间")
    private Date establishedTime;

    @ApiModelProperty(value = "联系电话")
    private Integer phone;

    @ApiModelProperty(value = "床位数")
    private Integer bedNum;

    @ApiModelProperty(value = "所属诊室")
    private Integer clinicId;

    @TableField(exist = false)
    private String subjectParentName;

    @TableField(exist = false)
    private List<User> userList;

    @TableField(exist = false)
    private Integer userCount;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
