package com.python.clinic.service.stock;


import com.baomidou.mybatisplus.extension.service.IService;
import com.python.clinic.entity.stock.StockLog;
import com.python.clinic.entity.stock.vo.StockLogVo;

import java.util.List;

/**
 * <p>
 * 库存日志表，包含药品/物资、入库、出库操作记录 服务类
 * </p>
 *
 * @author hm
 * @since 2020-05-19
 */
public interface StockLogService extends IService<StockLog> {

    /**
     * 查询日志列表
     * @param relationId   关联id
     * @param type  0：药品，1：采购，2：入库，3：出库，4：盘点，5：结算
     * @return
     */
    List<StockLogVo> listStockLog(Integer relationId, Integer type);

}
