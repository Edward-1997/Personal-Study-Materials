package com.python.clinic.controller.user;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.python.clinic.entity.user.ShiftManagement;
import com.python.clinic.service.user.ShiftManagementService;
import com.python.common.response.CommonResult;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 * 班次管理 前端控制器
 * </p>
 *
 * @author hm
 * @since 2020-06-03
 */
@RestController
@RequestMapping("/shiftManagement")
public class ShiftManagementController {

    @Autowired
    private ShiftManagementService shiftManagementService;

    @GetMapping("/listShiftManagement/{clinicId}")
    @ApiOperation("获取班次")
    public CommonResult listShiftManagement(@PathVariable Integer clinicId){
        QueryWrapper<ShiftManagement> wrapper = new QueryWrapper<>();
        wrapper.eq("clinic_id",clinicId).orderByAsc("start_time");
        return CommonResult.success(shiftManagementService.list(wrapper));
    }

    @PostMapping("/saveShiftManagement")
    @ApiOperation("添加班次")
    public CommonResult saveShiftManagement(@Validated @RequestBody ShiftManagement shiftManagement){
        //判断名称是否重复
        int count = shiftManagementService.count(new QueryWrapper<ShiftManagement>().eq("shifts_name", shiftManagement.getShiftsName()));
        if (count > 0){
            return CommonResult.failed("班次名重复，请重新输入");
        }
        return CommonResult.result(shiftManagementService.save(shiftManagement));
    }

    @DeleteMapping("/deleteShiftManagement/{id}")
    @ApiOperation("删除班次")
    public CommonResult deleteShiftManagement(@PathVariable Integer id){
        return CommonResult.result(shiftManagementService.deleteShiftManagement(id));
    }

    @PutMapping("/updateShiftManagement")
    @ApiOperation("修改班次")
    public CommonResult updateShiftManagement(@RequestBody ShiftManagement shiftManagement){
        //判断名称是否重复
        QueryWrapper<ShiftManagement> wrapper = new QueryWrapper<>();
        wrapper.eq("shifts_name", shiftManagement.getShiftsName()).ne("id", shiftManagement.getId());
        int count = shiftManagementService.count(wrapper);
        if (count > 0){
            return CommonResult.failed("班次名重复，请重新输入");
        }
        return CommonResult.result(shiftManagementService.updateById(shiftManagement));
    }

}
