package com.python.clinic.service.patient.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.python.clinic.dao.patient.PatientMapper;
import com.python.clinic.entity.diagnosis.vo.DiagnosisRecordsVo;
import com.python.clinic.entity.patient.Patient;
import com.python.clinic.entity.patient.dto.PatientInfoDto;
import com.python.clinic.entity.patient.vo.PatientInfoListVo;
import com.python.clinic.service.diagnosis.DiagnosisService;
import com.python.clinic.service.patient.PatientService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.python.clinic.service.user.UserService;
import com.python.common.response.CommonResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * <p>
 * 患者表 服务实现类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-20
 */
@Service
public class PatientServiceImpl extends ServiceImpl<PatientMapper, Patient> implements PatientService {
    @Autowired
    private PatientMapper patientMapper;
    @Autowired
    private DiagnosisService diagnosisService;
    @Autowired
    private UserService userService;

    @Override
    public CommonResult selectPatientById(Integer id) {
        Patient patient =  patientMapper.selectById(id);

        if(patient != null){
            PatientInfoDto patientInfoDto = new PatientInfoDto(patient);

            //设置推荐人姓名，如果没有则为null
//            patient.setReferee(patient.getSourceFrom().toString());
            Map<String,Object> map = new HashMap<>();
            map.put("patient",patientInfoDto);
            return CommonResult.success(map,"查询患者信息成功");
        }

        return CommonResult.failed("查询异常");
    }

    @Override
    public CommonResult selectPatientList(String sortField,String sortReg,Integer pageSize,Integer pageNum) {
        IPage<Patient> page = new Page<>(pageNum,pageSize);
        IPage<Patient> patientIPage = patientMapper.selectPage(page, new QueryWrapper<>(new Patient()));

        patientIPage.convert(patient -> {
            PatientInfoListVo patientInfo = new PatientInfoListVo();
            patientInfo.setAge(patient.getAge());
            patientInfo.setGender(patient.getGender());
            patientInfo.setPatientName(patient.getPatientName());
            patientInfo.setPatientId(patient.getId());
            IPage<DiagnosisRecordsVo> diagnosisRecords = diagnosisService.selectRecordByPatientId(1, 1, patient.getId());
            if(diagnosisRecords!= null){//设置患者最近就诊时间
                patientInfo.setDiagnosisTime(diagnosisRecords.getRecords().get(0).getDiagnosisDate());
            }else {
                //如果没有门诊记录，则使用时间：1970, 00:00:00 GMT
                patientInfo.setDiagnosisTime(new Date(0));
            }

            return patientInfo;
        }).getRecords().stream().sorted((m1,m2)-> {
            //此处进行排序逻辑
            int i = m2.getDiagnosisTime().compareTo(m1.getDiagnosisTime());
            if(sortReg.equals("desc")){//按照降序规则排序
                return i;
            }
            return -i;//如果不是则按照升序规则排序
        }).peek(patientInfo ->{
            if(patientInfo.getDiagnosisTime().getTime() == 0){
                patientInfo.setDiagnosisTime(null);
            }
        });

        Map<String,Object> map = new HashMap<>();
        map.put("patientList",patientIPage);

        return CommonResult.success(map,"查询患者列表成功");
    }

    @Override
    public CommonResult insertPatient(Patient patient) {
        Date birthday = patient.getBirthday();
        Calendar now = Calendar.getInstance();
        now.setTime(new Date());
        Calendar birth = Calendar.getInstance();
        birth.setTime(birthday);
        //通过用户传入的生日计算年龄
        int age = now.get(Calendar.YEAR)-birth.get(Calendar.YEAR);
        if(now.get(Calendar.DAY_OF_YEAR)<birth.get(Calendar.DAY_OF_YEAR)){
            age --;
        }

        patient.setAge(age);
        patient.setCreateTime(new Date());

        if(1 == patientMapper.insert(patient)){
            return CommonResult.success(null,"新增患者成功");
        }
        return CommonResult.failed("新增患者失败");
    }

    @Override
    public CommonResult updatePatient(Patient patient) {
        if(patientMapper.updateById(patient)==1){
            return CommonResult.success(null,"修改患者信息成功");
        }
        return CommonResult.failed("修改患者信息失败");
    }


}
