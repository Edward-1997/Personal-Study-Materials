package com.python.clinic.service.diagnosis.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.python.clinic.dao.user.UserMapper;
import com.python.clinic.entity.diagnosis.FollowUpTemplate;
import com.python.clinic.dao.diagnosis.FollowUpTemplateMapper;
import com.python.clinic.entity.diagnosis.constant.DiagnosisConstant;
import com.python.clinic.entity.diagnosis.dto.FollowUpTemplateDto;
import com.python.clinic.service.diagnosis.FollowUpTemplateService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 随访模板 服务实现类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-28
 */
@Service
public class FollowUpTemplateServiceImpl extends ServiceImpl<FollowUpTemplateMapper, FollowUpTemplate> implements FollowUpTemplateService {

    @Autowired
    private FollowUpTemplateMapper followUpTemplateMapper;
    @Autowired
    private UserMapper userMapper;

    @Override
    public IPage<FollowUpTemplateDto> getTemplateList(IPage<FollowUpTemplate> pages,FollowUpTemplate followUpTemplate) {

        IPage<FollowUpTemplate> templateIPage = followUpTemplateMapper.selectPage(pages, new QueryWrapper<>(followUpTemplate));
        return templateIPage.convert(template->{
            FollowUpTemplateDto dto = new FollowUpTemplateDto();
            dto.setId(template.getId());
            //由于用户未创建，暂时没有
            //dto.setName(userMapper.selectById(template.getCreateId()).getUserName());
            dto.setName("哈哈");
            dto.setContent(template.getContent());
            dto.setCreateId(template.getCreateId());
            dto.setTemplateName(template.getTemplateName());
            dto.setType(template.getType());
            return dto;
        });
    }

    @Override
    public boolean updateTemplate(FollowUpTemplate followUpTemplate) {
        return followUpTemplateMapper.updateById(followUpTemplate) == 1;
    }

    @Override
    public boolean deleteTemplate(Integer id) {
        return followUpTemplateMapper.deleteById(id) == 1;
    }
}
