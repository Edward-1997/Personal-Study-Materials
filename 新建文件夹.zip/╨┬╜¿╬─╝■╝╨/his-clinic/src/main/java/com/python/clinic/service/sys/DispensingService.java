package com.python.clinic.service.sys;

import com.python.clinic.entity.sys.Dispensing;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 发药设置 服务类
 * </p>
 *
 * @author hm
 * @since 2020-06-05
 */
public interface DispensingService extends IService<Dispensing> {

}
