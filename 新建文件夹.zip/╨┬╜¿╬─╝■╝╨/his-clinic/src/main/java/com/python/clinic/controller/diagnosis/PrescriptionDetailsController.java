package com.python.clinic.controller.diagnosis;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 处方详情表 前端控制器
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-26
 */
@RestController
@RequestMapping("/prescription-details")
public class PrescriptionDetailsController {

}
