package com.python.clinic.service.user.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.python.clinic.dao.user.SchedulingMapper;
import com.python.clinic.entity.user.Scheduling;
import com.python.clinic.entity.user.ShiftManagement;
import com.python.clinic.dao.user.ShiftManagementMapper;
import com.python.clinic.service.user.ShiftManagementService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;

/**
 * <p>
 * 班次管理 服务实现类
 * </p>
 *
 * @author hm
 * @since 2020-06-03
 */
@Service
public class ShiftManagementServiceImpl extends ServiceImpl<ShiftManagementMapper, ShiftManagement> implements ShiftManagementService {

    @Resource
    private ShiftManagementMapper shiftManagementMapper;
    @Resource
    private SchedulingMapper schedulingMapper;

    @Override
    @Transactional(propagation= Propagation.REQUIRED,isolation= Isolation.DEFAULT,rollbackFor= RuntimeException.class)
    public boolean deleteShiftManagement(Integer id) {
        //删除班次，同时删除与该班次相关的排班
        Boolean flag = shiftManagementMapper.deleteById(id) > 0;
        if (flag){
            schedulingMapper.delete(new QueryWrapper<Scheduling>().eq("shift_id",id));
        }
        return flag;
    }
}
