package com.python.clinic.dao.stock;

import com.python.clinic.entity.stock.InventoryDetails;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 盘点详情表 Mapper 接口
 * </p>
 *
 * @author hm
 * @since 2020-05-27
 */
public interface InventoryDetailsMapper extends BaseMapper<InventoryDetails> {

    /**
     * 根据盘点id查询盘点详情
     * @param inventoryId
     * @return
     */
    List<InventoryDetails> listInventoryDetailsByInventoryId(@Param("inventoryId")Integer inventoryId);

}
