package com.python.clinic.service.diagnosis;

import com.python.clinic.entity.diagnosis.Prescription;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 * 处方 服务类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-26
 */
public interface PrescriptionService extends IService<Prescription> {

    /**
     * 根据传来的prescription条件获得处方详细细节
     * @author tanglong
     * @return java.util.List<com.python.clinic.entity.diagnosis.Prescription>
     * @throws
     * @since 2020/5/26 16:35
     * @see
     **/
    List<Prescription> getPrescriptionList(Prescription prescription);
}
