package com.python.clinic.dao.diagnosis;

import com.python.clinic.entity.diagnosis.MealItem;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 套餐项目表 Mapper 接口
 * </p>
 *
 * @author hm
 * @since 2020-06-06
 */
public interface MealItemMapper extends BaseMapper<MealItem> {

    /**
     * 查询套餐包含项目
     * @param mealId
     * @return
     */
    List<Map<String,Object>> listMealItem(Integer mealId);

}
