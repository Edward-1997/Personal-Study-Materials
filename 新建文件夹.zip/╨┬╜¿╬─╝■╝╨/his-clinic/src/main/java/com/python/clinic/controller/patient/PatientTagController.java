package com.python.clinic.controller.patient;


import com.python.clinic.entity.patient.PatientTag;
import com.python.clinic.service.patient.PatientTagService;
import com.python.common.response.CommonResult;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 * 患者标签表 前端控制器
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-20
 */
@RestController
@RequestMapping("/patient_tag")
public class PatientTagController {
    private Logger logger = LoggerFactory.getLogger(PatientTagController.class);

    @Autowired
    private PatientTagService patientTagService;

    @GetMapping("/tags/{patientId}")
    @ApiOperation(value = "查询患者tag",notes = "传入患者Id、标签Id，实现查询患者标签操作")
    public CommonResult getPatientTags(@PathVariable Integer patientId){
        return patientTagService.getPatientTags(patientId);
    }

    @PostMapping("/tag")
    @ApiOperation(value = "添加患者tag",notes = "传入患者Id、标签Id，实现添加患者标签操作")
    public CommonResult insertPatientTag(@RequestBody PatientTag tag){
        return patientTagService.insertPatientTag(tag);
    }

    @DeleteMapping("/tag")
    @ApiOperation(value = "删除患者tag",notes = "传入患者Id、标签Id，实现删除患者标签操作")
    public CommonResult deletePatientTag(@RequestBody PatientTag tag){
        return patientTagService.deletePatientTag(tag);
    }


}
