package com.python.clinic.service.stock;

import com.python.clinic.entity.stock.OutOfStockDetails;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 出库详情表 服务类
 * </p>
 *
 * @author hm
 * @since 2020-05-23
 */
public interface OutOfStockDetailsService extends IService<OutOfStockDetails> {

}
