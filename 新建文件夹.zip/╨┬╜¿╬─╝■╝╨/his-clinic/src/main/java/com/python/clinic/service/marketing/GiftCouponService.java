package com.python.clinic.service.marketing;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.python.clinic.entity.marketing.Coupon;
import com.python.clinic.entity.marketing.GiftCoupon;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 优惠赠品表 服务类
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-05
 */
public interface GiftCouponService extends IService<GiftCoupon> {

    /**
     * 获取满减返还物品优惠详情
     * @author tanglong
     * @return java.util.List<com.python.clinic.entity.marketing.GiftCoupon>
     * @since 2020/6/8 14:07
     **/
    Map<String,Object> getGiftCouponDetailsList(GiftCoupon giftCoupon);
}
