package com.python.clinic.service.patient;

import com.python.clinic.entity.patient.IntegralFlow;
import com.baomidou.mybatisplus.extension.service.IService;
import com.python.common.response.CommonResult;

/**
 * <p>
 * 积分流水 服务类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-20
 */
public interface IntegralFlowService extends IService<IntegralFlow> {

    /**
     * 根据会员id获取会员积分列表
     * @author tanglong
     * @return com.python.common.response.CommonResult
     * @since 2020/5/25 10:58
     **/
    CommonResult getIntegralFlowList(Integer cardId,Integer pageSize,Integer pageNum);
}
