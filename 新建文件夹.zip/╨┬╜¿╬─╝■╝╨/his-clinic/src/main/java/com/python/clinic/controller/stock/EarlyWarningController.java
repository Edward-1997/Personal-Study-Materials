package com.python.clinic.controller.stock;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.python.clinic.entity.stock.EarlyWarning;
import com.python.clinic.service.stock.EarlyWarningService;
import com.python.clinic.service.sys.SysConfigService;
import com.python.common.response.CommonResult;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * 库存预警设置 前端控制器
 * </p>
 *
 * @author hm
 * @since 2020-05-19
 */
@RestController
@RequestMapping("/earlyWarning")
public class EarlyWarningController {

    @Autowired
    private EarlyWarningService earlyWarningService;
    @Autowired
    private SysConfigService SysConfigService;

    @GetMapping("/getEarlyWarning")
    @ApiOperation("获取商品预警设置")
    public CommonResult getEarlyWarning(@RequestParam(required = true) Integer goodsId, @RequestParam(required = true)Integer clinicId){
        Map<String,Object> map = new HashMap<>();
        //查询商品预警设置
        QueryWrapper wrapper = new QueryWrapper();
        wrapper.eq("goods_id",goodsId);
        map.put("earlyWarning",earlyWarningService.getOne(wrapper));

        //查询诊所默认预警设置
        QueryWrapper queryWrapper = new QueryWrapper();
        queryWrapper.select("id","clinic_id","stock_warn_goods_turnover_days","stock_warn_goods_will_expired_month").eq("clinic_id",clinicId);
        map.put("clinicEarlyWarning",SysConfigService.getOne(queryWrapper));
        return CommonResult.success(map);
    }

    @PostMapping("/updateEarlyWarning")
    @ApiOperation(value = "修改/添加商品预警设置",notes = "id为null表示添加，不为null表示修改")
    public CommonResult updateEarlyWarning(@RequestBody EarlyWarning earlyWarning){
        if (earlyWarning.getId() == null){
            return CommonResult.result(earlyWarningService.save(earlyWarning));
        }
        return CommonResult.result(earlyWarningService.updateById(earlyWarning));
    }

}
