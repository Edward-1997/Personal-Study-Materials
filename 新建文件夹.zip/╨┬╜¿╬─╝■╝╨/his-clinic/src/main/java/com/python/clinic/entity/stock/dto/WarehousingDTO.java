package com.python.clinic.entity.stock.dto;

import com.python.clinic.entity.stock.*;
import lombok.Data;

import java.util.List;

/**
 * @author hm
 */
@Data
public class WarehousingDTO {

    private Warehousing warehousing;

    private List<WarehousingBatch> batchList;

    private StockLog stockLog;

    private List<StockLogDetails> stockLogDetailsList;

}
