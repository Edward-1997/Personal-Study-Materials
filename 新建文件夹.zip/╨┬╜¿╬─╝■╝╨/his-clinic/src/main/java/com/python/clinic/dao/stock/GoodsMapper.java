package com.python.clinic.dao.stock;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.python.clinic.entity.stock.Goods;
import com.python.clinic.entity.stock.Warehousing;
import com.python.clinic.entity.stock.dto.GoodsSelectDTO;
import com.python.clinic.entity.stock.vo.GoodsVo;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 药品/物资表 Mapper 接口
 * </p>
 *
 * @author hm
 * @since 2020-05-19
 */
public interface GoodsMapper extends BaseMapper<Goods> {

    /**
     * 查询商品列表
     * @param page
     * @param goodsDTO 条件参数
     * @return
     */
    IPage<GoodsVo> listGoods(IPage<GoodsVo> page, @Param("goodsDTO") GoodsSelectDTO goodsDTO);

    /**
     * 获取商品数量、合计成本、售价
     * @param goodsId
     * @return  total:商品数量，sellPriceSum:售价，inputPriceSum:合计成本
     */
    Map<String,Object> getGoodsCount(Integer goodsId);

    /**
     * 获取商品历史进价
     * @param goodsId
     * @return
     */
    List<Map<String,Object>> getHistoricalPrice(Integer goodsId);

    /**
     * 获取历史最低或最高进价
     * @param goodsId
     * @param orderType
     * @return
     */
    Map<String,Object> getMaxOrMinHistoricalPrice(@Param("goodsId")Integer goodsId,@Param("orderType")String orderType);

}
