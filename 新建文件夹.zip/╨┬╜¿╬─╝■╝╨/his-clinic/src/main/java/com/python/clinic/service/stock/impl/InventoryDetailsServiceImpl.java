package com.python.clinic.service.stock.impl;

import com.python.clinic.entity.stock.InventoryDetails;
import com.python.clinic.dao.stock.InventoryDetailsMapper;
import com.python.clinic.service.stock.InventoryDetailsService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 盘点详情表 服务实现类
 * </p>
 *
 * @author hm
 * @since 2020-05-27
 */
@Service
public class InventoryDetailsServiceImpl extends ServiceImpl<InventoryDetailsMapper, InventoryDetails> implements InventoryDetailsService {

}
