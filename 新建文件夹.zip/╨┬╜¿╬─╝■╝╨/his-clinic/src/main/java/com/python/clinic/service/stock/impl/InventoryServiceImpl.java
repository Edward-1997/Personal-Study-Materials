package com.python.clinic.service.stock.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.python.clinic.dao.stock.*;
import com.python.clinic.dao.sys.ClinicMapper;
import com.python.clinic.dao.user.UserMapper;
import com.python.clinic.entity.stock.*;
import com.python.clinic.entity.stock.vo.GoodsStockVo;
import com.python.clinic.service.stock.InventoryService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.python.clinic.service.stock.StockLogService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * <p>
 * 盘点表 服务实现类
 * </p>
 *
 * @author hm
 * @since 2020-05-27
 */
@Service
public class InventoryServiceImpl extends ServiceImpl<InventoryMapper, Inventory> implements InventoryService {

    @Resource
    private InventoryMapper inventoryMapper;
    @Resource
    private InventoryDetailsMapper detailsMapper;
    @Resource
    private InventoryBatchMapper inventoryBatchMapper;
    @Resource
    private GoodsMapper goodsMapper;
    @Resource
    private UserMapper userMapper;
    @Resource
    private ClinicMapper clinicMapper;
    @Resource
    private WarehousingBatchMapper warehousingBatchMapper;
    @Resource
    private StockLogService stockLogService;



    /**
     * 盘点盈亏数量
     */
    Double numChange;

    @Override
    public IPage<Inventory> selectPage(IPage<Inventory> page, String startTime, String endTime, Integer goodsId) {
        IPage<Inventory> inventoryPage = inventoryMapper.selectPage(page, startTime, endTime, goodsId);
        for (Inventory record : inventoryPage.getRecords()) {
            record.setClinic(clinicMapper.getIdAndName(record.getClinicId()));
            record.setCreator(userMapper.getIdAndName(record.getCreateId()));
        }
        return inventoryPage;
    }

    private void saveInventoryCommon(InventoryDetails inventoryDetails,Integer batchId){
        WarehousingBatch warehousingBatch = new WarehousingBatch();
        warehousingBatch.setId(batchId);
        warehousingBatch.setPackageCount(inventoryDetails.getPackageCount());
        warehousingBatch.setPieceCount(inventoryDetails.getPieceCount());
        warehousingBatchMapper.updateById(warehousingBatch);

        //查询批次信息
        GoodsStockVo goodsStockVo = warehousingBatchMapper.getGoodsStockAndPreparation(inventoryDetails.getBatchId());
        //判断商品是否有有整装包装
        Double detailsNumChange;
        BigDecimal pieceCostPriceChange;
        BigDecimal piecePriceChange;
        if (goodsStockVo.getPreparation() == null){
            detailsNumChange = inventoryDetails.getPieceCountChange().doubleValue();
            pieceCostPriceChange = new BigDecimal(inventoryDetails.getPieceCount()).multiply(goodsStockVo.getPackagePrice());
            piecePriceChange = new BigDecimal(inventoryDetails.getPieceCount()).multiply(goodsStockVo.getPackagePrice());
        }else {
            detailsNumChange = inventoryDetails.getPackageCountChange() + inventoryDetails.getPieceCountChange().doubleValue() / goodsStockVo.getPreparation();
            pieceCostPriceChange = new BigDecimal(inventoryDetails.getPieceCount()).multiply(goodsStockVo.getPackagePrice().divide(new BigDecimal(goodsStockVo.getPreparation())));
            piecePriceChange = new BigDecimal(inventoryDetails.getPieceCountChange()).multiply(goodsStockVo.getSellPrice()).divide(new BigDecimal(goodsStockVo.getPreparation()));
        }
        //盈亏数量
        numChange += detailsNumChange;
        //盈亏金额（进价）
        BigDecimal packageCostPriceChange = ( new BigDecimal(inventoryDetails.getPackageCountChange()).multiply(goodsStockVo.getPackagePrice()) );
        inventoryDetails.setTotalCostPriceChange(packageCostPriceChange.add(pieceCostPriceChange));

        //盈亏金额（售价）
        BigDecimal packagePriceChange = (new BigDecimal(inventoryDetails.getPackageCountChange()).multiply(goodsStockVo.getSellPrice()));
        inventoryDetails.setTotalPriceChange(packagePriceChange.add(piecePriceChange));

        //添加盘点详情
        detailsMapper.insert(inventoryDetails);

    }

    @Override
    @Transactional(propagation= Propagation.REQUIRED,isolation= Isolation.DEFAULT,rollbackFor= Exception.class)
    public boolean saveInventory(Inventory inventory)throws Exception {
        //1.添加盘点
        inventoryMapper.insert(inventory);

        //盈亏进价总金额，盈亏售价总金额，盈亏数量
        BigDecimal totalCostPriceChange = new BigDecimal(0);
        BigDecimal totalPriceChange = new BigDecimal(0);
        //初始化numChange为 0
        numChange = 0.0;

        //2.添加盘点详情
        for (InventoryDetails inventoryDetails : inventory.getDetailsList()) {

            //2.1指定批次
            if (inventoryDetails.getSpecifyBatch()){
                saveInventoryCommon(inventoryDetails,inventoryDetails.getBatchId());
                totalCostPriceChange = totalCostPriceChange.add(inventoryDetails.getTotalCostPriceChange());
                totalPriceChange = totalPriceChange.add(inventoryDetails.getTotalPriceChange());

            }else {
                InventoryBatch inventoryBatch;
                //2.2不指定批次
                if (inventoryDetails.getPackageCountChange() < 0 || inventoryDetails.getPieceCountChange() < 0){
                    //2.2.1 盈亏数量为负，优先扣减过期时间较近的入库批次

                    QueryWrapper<Goods> goodsWrapper = new QueryWrapper<>();
                    goodsWrapper.select("id","preparation","sell_price").eq("id",inventoryDetails.getGoodsId());
                    Goods goods = goodsMapper.selectOne(goodsWrapper);

                    Boolean preparationIsNull = ( goods.getPreparation() == null );
                    //出库数量
                    Integer outPieceNum = -(preparationIsNull ? inventoryDetails.getPieceCountChange()
                            : inventoryDetails.getPackageCountChange() * goods.getPreparation() + inventoryDetails.getPieceCountChange());

                    //盈亏金额（售价）
                    BigDecimal packagePriceChange = (new BigDecimal(inventoryDetails.getPackageCountChange()).multiply(goods.getSellPrice()));
                    BigDecimal piecePriceChange = preparationIsNull ? new BigDecimal(inventoryDetails.getPieceCountChange()).multiply(goods.getSellPrice())
                            : new BigDecimal(inventoryDetails.getPieceCountChange()).multiply(goods.getSellPrice()).divide(new BigDecimal(goods.getPreparation()));
                    inventoryDetails.setTotalPriceChange(packagePriceChange.add(piecePriceChange));
                    totalPriceChange = totalPriceChange.add(inventoryDetails.getTotalPriceChange());
                    //添加盘点详情，后面计算出进价盈亏金额再做修改
                    detailsMapper.insert(inventoryDetails);

                    //盘点详情盈亏金额（进价）
                    BigDecimal detailsCostPriceChange = new BigDecimal(0);

                    //查询出库商品库存不为零的批次，按有效期顺序排列
                    QueryWrapper<WarehousingBatch> warehousingWrapper = new QueryWrapper();
                    warehousingWrapper.select("id","package_count","piece_count","package_price").ne("package_count",0).or().
                            ne("piece_count",0).eq("goods_id",inventoryDetails.getGoodsId()).orderByAsc("expiry_date");
                    List<WarehousingBatch> warehousingBatches = warehousingBatchMapper.selectList(warehousingWrapper);
                    //遍历批次集合，扣除库存
                    for (WarehousingBatch temp : warehousingBatches) {
                        //查询当前入库批次总数量(按最小存库单位计算)
                        Integer batchStockPiece = preparationIsNull ? temp.getPieceCount() : temp.getPackageCount() * goods.getPreparation() + temp.getPieceCount();
                        if (outPieceNum <= batchStockPiece){
                            //当前批次库存足够扣除出库数量，跳出循环

                            //剩余库存
                            batchStockPiece = batchStockPiece - outPieceNum;

                            //计算该盘点批次盈亏金额(进价)
                            BigDecimal costPriceChange = preparationIsNull ? new BigDecimal(-outPieceNum).multiply(temp.getPackagePrice())
                                    : new BigDecimal(-outPieceNum).multiply(temp.getPackagePrice().divide(new BigDecimal(goods.getPreparation())));

                            //添加盘点批次
                            inventoryBatch = new InventoryBatch(inventoryDetails.getId(),temp.getId(),temp.getPackageCount(),temp.getPieceCount(),
                                    preparationIsNull ? 0 : batchStockPiece / goods.getPreparation(),preparationIsNull ? batchStockPiece : batchStockPiece % goods.getPreparation(),
                                    preparationIsNull ? 0 : outPieceNum / goods.getPreparation(),preparationIsNull ? outPieceNum : outPieceNum % goods.getPreparation(),
                                    costPriceChange);
                            inventoryBatchMapper.insert(inventoryBatch);

                            //修改盘点详情进价盈亏金额
                            detailsCostPriceChange = detailsCostPriceChange.add(costPriceChange);
                            InventoryDetails details = new InventoryDetails();
                            details.setId(inventoryDetails.getId());
                            details.setTotalCostPriceChange(detailsCostPriceChange);
                            detailsMapper.updateById(details);
                            //累加盘点进价盈亏总金额
                            totalCostPriceChange = totalCostPriceChange.add(detailsCostPriceChange);

                            //修改入库批次剩余库存
                            temp.setPackageCount(inventoryBatch.getPackageCount());
                            temp.setPieceCount(inventoryBatch.getPieceCount());
                            warehousingBatchMapper.updateById(temp);

                            break;
                        }else {
                            //扣除出库金额
                            outPieceNum = outPieceNum - batchStockPiece;
                            //计算该盘点批次盈亏金额(进价)
                            BigDecimal costPriceChange = preparationIsNull ? new BigDecimal(-batchStockPiece).multiply(temp.getPackagePrice())
                                    : new BigDecimal(-batchStockPiece).multiply(temp.getPackagePrice().divide(new BigDecimal(goods.getPreparation())));
                            //添加盘点批次
                            inventoryBatch = new InventoryBatch(inventoryDetails.getId(),temp.getId(),temp.getPackageCount(),temp.getPieceCount(),
                                    0,0, preparationIsNull ? 0 : batchStockPiece / goods.getPreparation(),
                                    preparationIsNull ? batchStockPiece : batchStockPiece % goods.getPreparation(), costPriceChange);
                            inventoryBatchMapper.insert(inventoryBatch);

                            //累加盘点详情金额
                            detailsCostPriceChange = detailsCostPriceChange.add(costPriceChange);

                            //当前批次库存不够扣除出库数量
                            temp.setPackageCount(0);
                            temp.setPieceCount(0);
                            warehousingBatchMapper.updateById(temp);
                        }
                    }
                }else {
                    //2.2.2 盈亏数量为正，选择最新入库批次，增加库存
                    saveInventoryCommon(inventoryDetails,warehousingBatchMapper.getLatelyBatchIdByGoodsId(inventoryDetails.getGoodsId()));

                    saveInventoryCommon(inventoryDetails,warehousingBatchMapper.getLatelyBatchIdByGoodsId(inventoryDetails.getGoodsId()));
                    totalCostPriceChange = totalCostPriceChange.add(inventoryDetails.getTotalCostPriceChange());
                    totalPriceChange = totalPriceChange.add(inventoryDetails.getTotalPriceChange());
                }
            }
        }

        //3.修改盘点总盈亏数据
        Inventory updateInventory = new Inventory();
        updateInventory.setId(inventory.getId());
        updateInventory.setNumChange(numChange);
        updateInventory.setTotalCostPriceChange(totalCostPriceChange);
        updateInventory.setTotalPriceChange(totalPriceChange);
        inventoryMapper.updateById(updateInventory);

        //4.添加操作日志
        StockLog stockLog = new StockLog("创建盘点单",new Date(),inventory.getCreateId(),inventory.getId(),4,inventory.getClinicId());
        stockLogService.save(stockLog);

        return true;
    }

    @Override
    public Inventory getInventoryById(Integer id) {
        //1.查询盘点单信息
        Inventory inventory = inventoryMapper.selectById(id);
        if (inventory != null){
            //盘点人
            inventory.setCreator(userMapper.getIdAndName(inventory.getCreateId()));
            //盘点门店
            inventory.setClinic(clinicMapper.getIdAndName(inventory.getClinicId()));
            //盘点详情
            inventory.setDetailsList(detailsMapper.listInventoryDetailsByInventoryId(id));
            //盘点日志
            inventory.setLogList(stockLogService.listStockLog(id,3));
        }
        return inventory;
    }
}
