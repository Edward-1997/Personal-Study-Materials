package com.python.clinic.service.diagnosis.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.python.clinic.entity.diagnosis.ItemImplement;
import com.python.clinic.dao.diagnosis.ItemImplementMapper;
import com.python.clinic.service.diagnosis.ItemImplementService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 * 治疗项目执行记录表 服务实现类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-28
 */
@Service
public class ItemImplementServiceImpl extends ServiceImpl<ItemImplementMapper, ItemImplement> implements ItemImplementService {

    @Autowired
    private ItemImplementMapper itemImplementMapper;

    @Override
    public List<ItemImplement> getItemImplementList(Integer itemId) {
        ItemImplement itemImplement = new ItemImplement();
        itemImplement.setItemId(itemId);

        return itemImplementMapper.selectList(new QueryWrapper<>(itemImplement).orderByDesc("executor_time"));
    }
}
