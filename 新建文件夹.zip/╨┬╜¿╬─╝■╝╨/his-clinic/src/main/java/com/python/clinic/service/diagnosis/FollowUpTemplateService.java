package com.python.clinic.service.diagnosis;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.python.clinic.entity.diagnosis.FollowUpTemplate;
import com.baomidou.mybatisplus.extension.service.IService;
import com.python.clinic.entity.diagnosis.dto.FollowUpTemplateDto;

/**
 * <p>
 * 随访模板 服务类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-28
 */
public interface FollowUpTemplateService extends IService<FollowUpTemplate> {

    /**
     * 获取随访目标模板，并进行分页
     * @author tanglong
     * @return com.baomidou.mybatisplus.core.metadata.IPage<com.python.clinic.entity.diagnosis.FollowUpTemplate>
     * @since 2020/5/28 14:50
     **/
    IPage<FollowUpTemplateDto> getTemplateList(IPage<FollowUpTemplate> pages,FollowUpTemplate followUpTemplate);

    /**
     * 更新随访模板
     * @author tanglong
     * @return boolean
     * @since 2020/5/28 15:51
     **/
    boolean updateTemplate(FollowUpTemplate followUpTemplate);

    /**
     *
     * @author tanglong
     * @return
     * @since 2020/5/28 15:53
     **/

    boolean deleteTemplate(Integer id);
}
