package com.python.clinic.service.patient.impl;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.python.clinic.dao.patient.IntegralFlowMapper;
import com.python.clinic.entity.patient.IntegralFlow;
import com.python.clinic.service.patient.IntegralFlowService;
import com.python.common.response.CommonResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * <p>
 * 积分流水 服务实现类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-20
 */
@Service
public class IntegralFlowServiceImpl extends ServiceImpl<IntegralFlowMapper, IntegralFlow> implements IntegralFlowService {

    @Autowired
    private IntegralFlowMapper integralFlowMapper;

    @Override
    public CommonResult getIntegralFlowList(Integer cardId, Integer pageSize, Integer pageNum) {
        IntegralFlow integralFlow = new IntegralFlow();
        integralFlow.setPatientCardId(cardId);
        QueryWrapper wrapper = new QueryWrapper(integralFlow);

        IPage<IntegralFlow> page = new Page<>(pageNum,pageSize);
        IPage<IntegralFlow> integralFlowList = integralFlowMapper.selectPage(page, wrapper);

        if(integralFlowList.getRecords().size() >0){

            Map<String,Object> map = new HashMap<>();
            map.put("integralFlowList",integralFlowList);
            return CommonResult.success(map,"查询积分流水成功");
        }

        return CommonResult.failed("未查询到积分流水记录");
    }
}
