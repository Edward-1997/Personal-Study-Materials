package com.python.clinic.service.marketing;

import com.python.clinic.entity.marketing.PatientCoupon;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 患者优惠券表 服务类
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-05
 */
public interface PatientCouponService extends IService<PatientCoupon> {

}
