package com.python.clinic.service.diagnosis.impl;

import com.python.clinic.entity.diagnosis.ItemIndex;
import com.python.clinic.dao.diagnosis.ItemIndexMapper;
import com.python.clinic.service.diagnosis.ItemIndexService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 检查项目指标 服务实现类
 * </p>
 *
 * @author hm
 * @since 2020-06-06
 */
@Service
public class ItemIndexServiceImpl extends ServiceImpl<ItemIndexMapper, ItemIndex> implements ItemIndexService {

}
