package com.python.clinic.entity.marketing.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 满减返还的是优惠券
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/6/8 14:14
 **/
@Data
public class GiftCouponDto {
    @ApiModelProperty(value = "优惠券id")
    private Integer id;
    @ApiModelProperty(value = "优惠券数量")
    private Integer count;
    @ApiModelProperty(value = "优惠券名称")
    private String name;
    @ApiModelProperty(value = "优惠券状态,0：可发券 1：停止发券，2：已作废")
    private Integer status;
}
