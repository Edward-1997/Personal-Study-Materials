package com.python.clinic.service.marketing.impl;

import com.python.clinic.entity.marketing.PreferentialDetails;
import com.python.clinic.dao.marketing.PreferentialDetailsMapper;
import com.python.clinic.service.marketing.PreferentialDetailsService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 优惠详情表 服务实现类
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-05
 */
@Service
public class PreferentialDetailsServiceImpl extends ServiceImpl<PreferentialDetailsMapper, PreferentialDetails> implements PreferentialDetailsService {

}
