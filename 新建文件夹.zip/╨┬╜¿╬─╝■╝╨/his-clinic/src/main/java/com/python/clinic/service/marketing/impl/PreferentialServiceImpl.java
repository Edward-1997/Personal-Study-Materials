package com.python.clinic.service.marketing.impl;

import com.python.clinic.entity.marketing.Preferential;
import com.python.clinic.dao.marketing.PreferentialMapper;
import com.python.clinic.service.marketing.PreferentialService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 优惠信息表 服务实现类
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-05
 */
@Service
public class PreferentialServiceImpl extends ServiceImpl<PreferentialMapper, Preferential> implements PreferentialService {

}
