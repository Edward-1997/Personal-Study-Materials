package com.python.clinic.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.core.env.Profiles;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.service.VendorExtension;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.util.ArrayList;

/**
 * Swagger配置类
 *
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/5/7 10:29
 **/
@Configuration
@EnableSwagger2
public class SwaggerConfig {
    @Bean
    public Docket docket(Environment environment) {
        Contact contact = new Contact("", "", "");
        ApiInfo apiInfo = new ApiInfo("HIS-App项目API接口文档",
                "restful 编码规范",
                "1.0",
                "urn:tos",
                contact,
                "",
                "",
                new ArrayList<VendorExtension>());
        //用于判定是否是生产环境
        boolean flag = environment.acceptsProfiles(Profiles.of("dev"));
        return new Docket(DocumentationType.SWAGGER_2)
                .apiInfo(apiInfo)
                .enable(flag)
                .groupName("his-clinic")
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.python.clinic.controller"))
                .build();
    }

}
