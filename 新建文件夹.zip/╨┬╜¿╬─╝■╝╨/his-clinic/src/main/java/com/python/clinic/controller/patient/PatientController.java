package com.python.clinic.controller.patient;


import com.python.clinic.entity.patient.Patient;
import com.python.clinic.service.patient.PatientService;
import com.python.common.response.CommonResult;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;



/**
 * <p>
 * 患者表 前端控制器
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-20
 */
@RestController
@RequestMapping("/patient")
public class PatientController {
    private Logger logger = LoggerFactory.getLogger(PatientController.class);
    @Autowired
    private PatientService patientService;

    @GetMapping("/info/{id}")
    @ApiOperation(value = "查询患者基本信息",notes = "传入患者Id，实现查询患者操作")
    public CommonResult selectPatientInfo(@PathVariable Integer id){
        return patientService.selectPatientById(id);
    }

    @GetMapping("/list")
    @ApiOperation(value = "查询患者列表/患者档案",
            notes = "分页查询，默认一页40名患者，pageSize:数量，pageNum:起始位置，")
    public CommonResult listPatients(@RequestParam(defaultValue = "1") Integer pageNum,
                                   @RequestParam(defaultValue = "40") Integer pageSize,
                                   @RequestParam(defaultValue = "") String sortFiled,
                                   @RequestParam(defaultValue = "desc") String sortReg){
        return patientService.selectPatientList(sortFiled,sortReg,pageSize,pageNum);
    }

    @PostMapping("/info")
    @ApiOperation(value = "新增患者", notes = "传入patient对象，实现新增患者操作")
    public CommonResult insertPatientInfo(@RequestBody Patient patient){
        try {
            return patientService.insertPatient(patient);
        }catch (Exception e){
            logger.info("新增患者失败",e);
            return CommonResult.failed("新增患者失败");
        }
    }

    @ApiOperation(value = "修改患者信息",notes = "传入修改的patient对象，实现修改患者信息的操作")
    @PutMapping("/info")
    public CommonResult updatePatientInfo(@RequestBody Patient patient){
        return patientService.updatePatient(patient);
    }
}
