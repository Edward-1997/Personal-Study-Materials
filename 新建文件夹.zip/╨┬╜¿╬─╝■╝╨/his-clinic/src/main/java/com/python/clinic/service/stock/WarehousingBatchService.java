package com.python.clinic.service.stock;

import com.python.clinic.entity.stock.WarehousingBatch;
import com.baomidou.mybatisplus.extension.service.IService;
import com.python.clinic.entity.stock.dto.WarehousingDTO;

/**
 * <p>
 * 入库批次表 服务类
 * </p>
 *
 * @author hm
 * @since 2020-05-22
 */
public interface WarehousingBatchService extends IService<WarehousingBatch> {

    /**
     * 修改入库批次
     * @param warehousingDTO
     * @return
     */
    boolean updateWarehousingBatch(WarehousingDTO warehousingDTO);

}
