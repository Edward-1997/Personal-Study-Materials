package com.python.clinic.dao.marketing;

import com.python.clinic.entity.marketing.GiftMember;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 满减活动指定会员 Mapper 接口
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-05
 */
public interface GiftMemberMapper extends BaseMapper<GiftMember> {

}
