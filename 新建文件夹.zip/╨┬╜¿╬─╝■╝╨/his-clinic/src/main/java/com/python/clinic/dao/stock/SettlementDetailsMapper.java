package com.python.clinic.dao.stock;

import com.python.clinic.entity.stock.SettlementDetails;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 结算明细表 Mapper 接口
 * </p>
 *
 * @author hm
 * @since 2020-05-28
 */
public interface SettlementDetailsMapper extends BaseMapper<SettlementDetails> {

    /**
     * 根据传入类型获取入库出库批次，用于结算明细添加
     * @param refId 关联id
     * @param type  关联类型 0:入库，1:出库
     * @return
     */
    List<SettlementDetails> listInOrOutBatch(@Param("redId")Integer refId,@Param("type")Integer type);

    /**
     * 批量插入结算明细
     * @param list
     * @return
     */
    int saveBatch(@Param("list") List<SettlementDetails> list);

}
