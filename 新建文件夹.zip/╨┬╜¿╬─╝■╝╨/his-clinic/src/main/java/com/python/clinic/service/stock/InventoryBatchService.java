package com.python.clinic.service.stock;

import com.python.clinic.entity.stock.InventoryBatch;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 盘点批次表 服务类
 * </p>
 *
 * @author hm
 * @since 2020-05-27
 */
public interface InventoryBatchService extends IService<InventoryBatch> {

}
