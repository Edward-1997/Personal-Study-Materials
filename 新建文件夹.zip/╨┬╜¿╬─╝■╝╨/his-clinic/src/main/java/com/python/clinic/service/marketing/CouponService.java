package com.python.clinic.service.marketing;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.python.clinic.entity.marketing.Coupon;
import com.baomidou.mybatisplus.extension.service.IService;
import com.python.clinic.entity.marketing.dto.CouponDetailsDto;
import com.python.clinic.entity.marketing.vo.CouponListVo;
import com.python.common.response.CommonResult;

/**
 * <p>
 * 优惠券表 服务类
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-05
 */
public interface CouponService extends IService<Coupon> {

    /**
     * 分页查询门店定义的优惠券列表，默认一页10条
     * @author tanglong
     * @return com.baomidou.mybatisplus.core.metadata.IPage<com.python.clinic.entity.marketing.Coupon>
     * @since 2020/6/5 10:10
     **/
    IPage<CouponListVo> selectCouponList(Integer pageNum, Integer pageSize,Integer status);

    /**
     * 根据id查询优惠券详情
     * @author tanglong
     * @return com.python.clinic.entity.marketing.dto.CouponDetailsDto
     * @since 2020/6/5 14:37
     **/
    CouponDetailsDto selectCouponDetails(Integer id);

    /**
     * 新增商品优惠券
     * @author tanglong
     * @param couponDetailsDto
     * @return com.python.common.response.CommonResult
     * @since 2020/6/6 9:28
     **/
    CommonResult insertCoupon(CouponDetailsDto couponDetailsDto);

    /**
     * 修改商品优惠券对象
     * @author tanglong
     * @return com.python.common.response.CommonResult
     * @since 2020/6/6 10:25
     **/
    CommonResult updateCoupon(CouponDetailsDto couponDetailsDto);

    /**
     * 修改商品优惠券的状态
     * @author tanglong
     * @param id
     * @param status 状态id 0：可发券 1：停止发券 2：已作废
     * @return com.python.common.response.CommonResult
     * @since 2020/6/6 14:50
     **/
    CommonResult updateCouponStatus(Integer id,Integer status);
}
