package com.python.clinic.service.marketing;

import com.python.clinic.entity.marketing.CouponMember;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 优惠券会员表 服务类
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-06
 */
public interface CouponMemberService extends IService<CouponMember> {

}
