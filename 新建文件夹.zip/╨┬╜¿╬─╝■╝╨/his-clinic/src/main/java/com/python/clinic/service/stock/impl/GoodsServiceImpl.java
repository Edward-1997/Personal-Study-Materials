package com.python.clinic.service.stock.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.python.clinic.dao.stock.GoodsMapper;
import com.python.clinic.dao.stock.StockLogDetailsMapper;
import com.python.clinic.dao.stock.StockLogMapper;
import com.python.clinic.entity.stock.Goods;
import com.python.clinic.entity.stock.StockLog;
import com.python.clinic.entity.stock.dto.GoodsDTO;
import com.python.clinic.entity.stock.dto.GoodsSelectDTO;
import com.python.clinic.entity.stock.vo.GoodsVo;
import com.python.clinic.service.stock.GoodsService;
import com.python.clinic.service.stock.StockLogDetailsService;
import com.python.clinic.service.stock.StockLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 药品/物资表 服务实现类
 * </p>
 *
 * @author hm
 * @since 2020-05-19
 */
@Service
public class GoodsServiceImpl extends ServiceImpl<GoodsMapper, Goods> implements GoodsService {

    @Resource
    private GoodsMapper goodsMapper;
    @Resource
    private StockLogService stockLogService;
    @Resource
    private StockLogDetailsMapper stockLogDetailsMapper;

    @Override
    @Transactional(propagation= Propagation.REQUIRED,isolation= Isolation.DEFAULT,rollbackFor= RuntimeException.class)
    public boolean saveGoods(GoodsDTO goodsDto){
        Goods goods = goodsDto.getGoods();
        //设置商品状态
        goods.setStatus(1);
        goodsMapper.insert(goods);
        //添加药品创建操作日志
        StockLog stockLog = goodsDto.getStockLog();
        stockLog.setAction("创建药品");
        stockLog.setRelationId(goods.getId());
        //设置关联类型,0为商品
        stockLog.setRelationType(0);
        stockLogService.save(stockLog);
        return true;
    }

    @Override
    @Transactional(propagation= Propagation.REQUIRED,isolation= Isolation.DEFAULT,rollbackFor= RuntimeException.class)
    public boolean updateGoods(GoodsDTO goodsDto) {
        Goods goods = goodsDto.getGoods();
        //防止传入商品下架状态进行修改
        goods.setStatus(1);
        goodsMapper.updateById(goods);
        //添加药品修改操作日志
        StockLog stockLog = goodsDto.getStockLog();
        stockLog.setAction("修改");
        stockLog.setRelationId(goods.getId());
        //设置关联类型,0为商品
        stockLog.setRelationType(0);
        stockLogService.save(stockLog);
        //添加修改详情
        stockLogDetailsMapper.saveBatch(goodsDto.getStockLogDetailsList(),stockLog.getId());
        return true;
    }

    @Override
    public Map<String,Object> getGoods(Integer id) {
        Goods goods = goodsMapper.selectById(id);
        if (goods != null && goods.getId() != null){
            Map<String,Object> map = new HashMap<>(4);
            map.put("goods",goods);
            map.put("stockLog",stockLogService.listStockLog(goods.getId(), 0));
            return map;
        }
        return null;
    }

    @Override
    public Map<String,Object> listGoods(IPage<GoodsVo> page, GoodsSelectDTO goodsDTO) {
        Map<String, Object> map = goodsMapper.getGoodsCount(goodsDTO.getGoodsId());
        if (map != null){
            map.put("goodsList",goodsMapper.listGoods(page, goodsDTO));
        }
        return map;
    }

    @Override
    public Map<String, Object> getHistoricalPrice(Integer goodsId) {
        Map<String, Object> map = new HashMap<>(4);
        map.put("historicalPrice",goodsMapper.getHistoricalPrice(goodsId));
        map.put("maxPrice",goodsMapper.getMaxOrMinHistoricalPrice(goodsId,"desc"));
        map.put("minPrice",goodsMapper.getMaxOrMinHistoricalPrice(goodsId,"asc"));
        return map;
    }
}
