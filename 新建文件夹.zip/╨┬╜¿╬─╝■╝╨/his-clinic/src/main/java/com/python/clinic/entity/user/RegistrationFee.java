package com.python.clinic.entity.user;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 挂号费表
 * </p>
 *
 * @author hm
 * @since 2020-06-06
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_registration_fee")
@ApiModel(value="RegistrationFee对象", description="挂号费表")
public class RegistrationFee extends Model<RegistrationFee> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "医生id")
    private Integer userId;

    @ApiModelProperty(value = "成本价")
    private BigDecimal costPrice;

    @ApiModelProperty(value = "销售价")
    private BigDecimal salesPrice;

    @ApiModelProperty(value = "科室id")
    private Integer departmentId;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
