package com.python.clinic.entity.stock;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

/**
 * <p>
 * 结算明细表
 * </p>
 *
 * @author hm
 * @since 2020-05-28
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@NoArgsConstructor
@TableName("his_settlement_details")
@ApiModel(value="SettlementDetails对象", description="结算明细表")
public class SettlementDetails extends Model<SettlementDetails> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "结算id")
    private Integer settlementId;

    @ApiModelProperty(value = "名称")
    private String name;

    @ApiModelProperty(value = "规格")
    private String spec;

    @ApiModelProperty(value = "单位")
    private String unit;

    @ApiModelProperty(value = "数量")
    private Integer number;

    @ApiModelProperty(value = "单价")
    private BigDecimal unitPrice;

    @ApiModelProperty(value = "总金额")
    private BigDecimal amount;

    @ApiModelProperty(value = "不含税金额")
    private BigDecimal amountExcludingTax;

    @ApiModelProperty(value = "税率")
    private BigDecimal taxRat;

    @ApiModelProperty(value = "税额")
    private BigDecimal tax;

    @ApiModelProperty(value = "创建时间")
    private Date createTime;

    @ApiModelProperty(value = "创建人id")
    private Integer createId;

    @ApiModelProperty(value = "修改时间")
    private Date updateTime;

    @ApiModelProperty(value = "修改人id")
    private Integer updateId;

    public SettlementDetails(Integer settlementId, String name, String spec, String unit, Integer number, BigDecimal unitPrice, BigDecimal amount, BigDecimal amountExcludingTax, BigDecimal taxRat, BigDecimal tax, Date createTime, Integer createId) {
        this.settlementId = settlementId;
        this.name = name;
        this.spec = spec;
        this.unit = unit;
        this.number = number;
        this.unitPrice = unitPrice;
        this.amount = amount;
        this.amountExcludingTax = amountExcludingTax;
        this.taxRat = taxRat;
        this.tax = tax;
        this.createTime = createTime;
        this.createId = createId;
    }

    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
