package com.python.clinic.service.patient.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.python.clinic.dao.patient.PatientCardFamilyMapper;
import com.python.clinic.entity.patient.PatientCardFamily;
import com.python.clinic.service.patient.PatientCardFamilyService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.python.common.response.CommonResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 会员卡家庭成员表 服务实现类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-20
 */
@Service
public class PatientCardFamilyServiceImpl extends ServiceImpl<PatientCardFamilyMapper, PatientCardFamily> implements PatientCardFamilyService {

    @Autowired
    private PatientCardFamilyMapper patientCardFamilyMapper;

    @Override
    public CommonResult insertPatientFamily(Integer patientId) {
        return null;
    }

    @Override
    public CommonResult deleteFamilyMembers(PatientCardFamily patientCardFamily) {
        if(1 ==patientCardFamilyMapper.delete(new QueryWrapper<>(patientCardFamily))){
            return CommonResult.success(null,"删除成功");
        }
        return CommonResult.failed("删除失败");
    }
}
