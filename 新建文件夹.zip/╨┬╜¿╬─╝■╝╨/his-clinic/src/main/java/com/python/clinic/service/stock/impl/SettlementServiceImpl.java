package com.python.clinic.service.stock.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.python.clinic.dao.stock.InvoiceMapper;
import com.python.clinic.dao.stock.RelationBillMapper;
import com.python.clinic.dao.stock.SettlementDetailsMapper;
import com.python.clinic.entity.stock.*;
import com.python.clinic.dao.stock.SettlementMapper;
import com.python.clinic.service.stock.RelationBillService;
import com.python.clinic.service.stock.SettlementService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.python.clinic.service.stock.StockLogService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

/**
 * <p>
 * 结算申请表 服务实现类
 * </p>
 *
 * @author hm
 * @since 2020-05-28
 */
@Service
public class SettlementServiceImpl extends ServiceImpl<SettlementMapper, Settlement> implements SettlementService {

    @Resource
    private SettlementMapper settlementMapper;
    @Resource
    private RelationBillService relationBillService;
    @Resource
    private RelationBillMapper relationBillMapper;
    @Resource
    private InvoiceMapper invoiceMapper;
    @Resource
    private StockLogService stockLogService;
    @Resource
    private SettlementDetailsMapper settlementDetailsMapper;

    @Override
    public IPage<Settlement> selectPage(IPage<Settlement> page, String startTime, String endTime, String dateType, Integer status, Integer supplierId) {
        return settlementMapper.selectPage(page, startTime, endTime, dateType, status, supplierId);
    }

    @Override
    public Settlement getSettlement(Integer id,Integer type) {
        //1.结算单数据
        Settlement settlement = settlementMapper.getSettlementById(id);
        if (!StringUtils.isEmpty(settlement)){
            //2.关联单据
            settlement.setBillList(relationBillService.listRelationBillBySettlementId(id));
            //3.关联发票
            QueryWrapper<Invoice> invoiceWrapper = new QueryWrapper();
            invoiceWrapper.eq("settlement_id",id);
            settlement.setInvoiceList(invoiceMapper.selectList(invoiceWrapper));
            //4.日志
            settlement.setLogList(stockLogService.listStockLog(id,5));
            //5.结算明细，当type=1时才查询结算明细
            if (type == 1){
                QueryWrapper<SettlementDetails> detailsWrapper = new QueryWrapper();
                detailsWrapper.eq("settlement_id",id);
                settlement.setDetailsList(settlementDetailsMapper.selectList(detailsWrapper));
            }
        }
        return settlement;
    }

    @Override
    @Transactional(propagation= Propagation.REQUIRED,isolation= Isolation.DEFAULT,rollbackFor= Exception.class)
    public boolean saveSettlement(Settlement settlement) {
        //1.添加结算申请
        settlementMapper.insert(settlement);
        //2.添加关联单据
        relationBillMapper.saveBatch(settlement.getBillList(),settlement.getId());
        //3.添加结算明细
        //3.1先查询出关联入库、出库下的所有批次
        List<SettlementDetails> allBatch = new ArrayList<>();
        for (RelationBill bill : settlement.getBillList()) {
            allBatch.addAll(settlementDetailsMapper.listInOrOutBatch(bill.getRefId(),bill.getType()));
        }
        //3.2循环得到的批次，将所有税率相同的批次金额相加，得到一条结算明细数据
        List<SettlementDetails> allDetails  = new ArrayList<>();
        for (SettlementDetails batch : allBatch) {
            //判断结算明细集合中是否有相同税率数据，有则累加，无则新增
            boolean flag = true;
            for (SettlementDetails detail : allDetails) {
                if (batch.getTaxRat().equals(detail.getTaxRat())){
                    detail.setUnitPrice(detail.getUnitPrice().add(batch.getUnitPrice()));
                    detail.setAmount(detail.getAmount().add(batch.getAmount()));
                    detail.setAmountExcludingTax(detail.getUnitPrice());
                    detail.setTax(detail.getTax().add(batch.getTax()));
                    flag = false;
                    break;
                }
            }
            if (flag){
                allDetails.add(new SettlementDetails(settlement.getId(),"药品","无","无",1,batch.getAmountExcludingTax(),
                        batch.getAmount(),batch.getAmountExcludingTax(),batch.getTaxRat(),batch.getTax(),new Date(),settlement.getCreateId()));
            }
        }
        settlementDetailsMapper.saveBatch(allDetails);
        //4.添加发票
        invoiceMapper.saveBatch(settlement.getInvoiceList(),settlement.getId());
        //5.添加日志
        StockLog stockLog = new StockLog("创建结算单",new Date(),settlement.getCreateId(),settlement.getId(),5,settlement.getClinicId());
        stockLogService.save(stockLog);
        return true;
    }

    @Override
    @Transactional(propagation= Propagation.REQUIRED,isolation= Isolation.DEFAULT,rollbackFor= Exception.class)
    public boolean updateSettlement(Settlement settlement) {
        //修改申请
        settlementMapper.updateById(settlement);
        //添加或修改关联发票，id为空添加，id不为空修改
        if (!StringUtils.isEmpty(settlement.getInvoiceList())){
            for (Invoice invoice : settlement.getInvoiceList()) {
                if (invoice.getId() == null){
                    invoiceMapper.insert(invoice);
                }else {
                    invoiceMapper.updateById(invoice);
                }
            }
        }
        //添加或修改结算明细
        if (!StringUtils.isEmpty(settlement.getDetailsList())){
            for (SettlementDetails details : settlement.getDetailsList()) {
                if (details.getId() == null){
                    settlementDetailsMapper.insert(details);
                }else {
                    settlementDetailsMapper.updateById(details);
                }
            }
        }
        return true;
    }
}
