package com.python.clinic.dao.marketing;

import com.python.clinic.entity.marketing.Preferential;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 优惠信息表 Mapper 接口
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-05
 */
public interface PreferentialMapper extends BaseMapper<Preferential> {

}
