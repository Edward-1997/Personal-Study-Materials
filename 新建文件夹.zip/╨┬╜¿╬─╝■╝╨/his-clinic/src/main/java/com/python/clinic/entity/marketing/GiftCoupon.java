package com.python.clinic.entity.marketing;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 优惠赠品表
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-05
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_gift_coupon")
@ApiModel(value="GiftCoupon对象", description="优惠赠品表")
public class GiftCoupon extends Model<GiftCoupon> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "优惠设置id")
    private Integer preferentialSetId;

    @ApiModelProperty(value = "关联id，根据类型判断")
    private Integer relationId;

    @ApiModelProperty(value = "关联类型，0：优惠券，1：赠品")
    private Integer relationType;

    @ApiModelProperty(value = "数量")
    private Integer count;

    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
