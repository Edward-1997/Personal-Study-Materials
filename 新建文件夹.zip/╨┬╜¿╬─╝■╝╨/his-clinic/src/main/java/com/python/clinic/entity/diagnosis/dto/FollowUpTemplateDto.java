package com.python.clinic.entity.diagnosis.dto;

import com.python.clinic.entity.diagnosis.FollowUpTemplate;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.annotations.ApiOperation;
import lombok.Data;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/5/28 15:05
 **/
@Data
public class FollowUpTemplateDto extends FollowUpTemplate {

    @ApiModelProperty(value = "创建模板人的姓名")
    private String name;
}
