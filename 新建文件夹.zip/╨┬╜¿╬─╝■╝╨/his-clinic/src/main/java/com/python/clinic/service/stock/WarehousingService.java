package com.python.clinic.service.stock;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.python.clinic.entity.stock.Warehousing;
import com.baomidou.mybatisplus.extension.service.IService;
import com.python.clinic.entity.stock.dto.WarehousingDTO;
import org.apache.ibatis.annotations.Param;

import java.util.Date;

/**
 * <p>
 * 入库表 服务类
 * </p>
 *
 * @author hm
 * @since 2020-05-22
 */
public interface WarehousingService extends IService<Warehousing> {

    /**
     * 添加入库表
     * @param warehousingDTO
     * @return
     */
    boolean saveWarehousing(WarehousingDTO warehousingDTO);

    /**
     * 修改入库信息并添加操作日志
     * @param warehousingDTO
     * @return
     */
    boolean updateWarehousing(WarehousingDTO warehousingDTO);

    /**
     * 分页带条件查询入库信息
     * @param page
     * @param startTime 开始时间
     * @param endTime  结束时间
     * @param supplierId 供应商id
     * @param goodsId   商品id
     * @return
     */
    IPage<Warehousing> selectPage(IPage<Warehousing> page, String startTime, String endTime, Integer supplierId, Integer goodsId);

}
