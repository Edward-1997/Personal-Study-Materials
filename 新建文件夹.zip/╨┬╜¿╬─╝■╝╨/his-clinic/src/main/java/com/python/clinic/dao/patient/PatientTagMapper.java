package com.python.clinic.dao.patient;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.python.clinic.entity.patient.PatientTag;
import com.python.clinic.entity.patient.Tags;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * <p>
 * 患者标签表 Mapper 接口
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-20
 */
@Mapper
public interface PatientTagMapper extends BaseMapper<PatientTag> {

    /**
     * 通过关联查询，查询患者具有的标签具体属性
     * @author tanglong
     * @param patientId 患者id
     * @return java.util.List<com.python.clinic.entity.patient.Tags>
     * @throws
     * @since 2020/5/21 15:59
     * @see
     **/
    public List<PatientTag> selectTagListByPatientId(Integer patientId);
}
