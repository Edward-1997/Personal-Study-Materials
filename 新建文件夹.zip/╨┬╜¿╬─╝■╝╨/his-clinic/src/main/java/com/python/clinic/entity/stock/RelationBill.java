package com.python.clinic.entity.stock;

import java.math.BigDecimal;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;

import com.python.clinic.entity.sys.Clinic;
import com.python.clinic.entity.user.User;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 关联单据id
 * </p>
 *
 * @author hm
 * @since 2020-05-29
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_relation_bill")
@ApiModel(value="RelationBill对象", description="关联单据id")
public class RelationBill extends Model<RelationBill> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "结算id")
    private Integer settlementId;

    @ApiModelProperty(value = "类型，0：入库，1：出库")
    private Integer type;

    @ApiModelProperty(value = "关联id（出库、入库）")
    private Integer refId;

    @ApiModelProperty(value = "关联单号")
    private String refOrderNo;

    @ApiModelProperty(value = "出/入库时间")
    private Date refOrderDate;

    @ApiModelProperty(value = "品种")
    private Integer kindCount;

    @ApiModelProperty(value = "数量")
    private Double number;

    @ApiModelProperty(value = "含税金额")
    private BigDecimal amount;

    @ApiModelProperty(value = "除税金额")
    private BigDecimal amountExcludingTax;

    @ApiModelProperty(value = "诊所id")
    private Integer clinicId;

    @ApiModelProperty(value = "操作人id")
    private Integer operatorId;

    @TableField(exist = false)
    @ApiModelProperty(value = "诊所")
    private Clinic clinic;

    @TableField(exist = false)
    @ApiModelProperty(value = "操作人")
    private User operator;



    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
