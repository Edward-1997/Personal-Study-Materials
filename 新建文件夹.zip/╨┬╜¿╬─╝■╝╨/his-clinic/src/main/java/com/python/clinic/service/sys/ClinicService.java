package com.python.clinic.service.sys;

import com.python.clinic.entity.sys.Clinic;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 诊所信息表 服务类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-21
 */
public interface ClinicService extends IService<Clinic> {

    /**
     * 根据诊所id，查询诊所信息
     * @author tanglong
     * @return com.python.clinic.entity.sys.Clinic
     * @since 2020/5/27 17:38
     **/
    Clinic getClinicInfo(Integer id);
}
