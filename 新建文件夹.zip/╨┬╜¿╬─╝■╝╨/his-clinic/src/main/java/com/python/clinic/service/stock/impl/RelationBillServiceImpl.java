package com.python.clinic.service.stock.impl;

import com.python.clinic.dao.sys.ClinicMapper;
import com.python.clinic.dao.user.UserMapper;
import com.python.clinic.entity.stock.RelationBill;
import com.python.clinic.dao.stock.RelationBillMapper;
import com.python.clinic.service.stock.RelationBillService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 * 关联单据id 服务实现类
 * </p>
 *
 * @author hm
 * @since 2020-05-29
 */
@Service
public class RelationBillServiceImpl extends ServiceImpl<RelationBillMapper, RelationBill> implements RelationBillService {

    @Resource
    private RelationBillMapper relationBillMapper;
    @Resource
    private UserMapper userMapper;
    @Resource
    private ClinicMapper clinicMapper;


    @Override
    public List<RelationBill> listRelationBillBySettlementId(Integer settlementId) {
        List<RelationBill> relationBills = relationBillMapper.listRelationBillBySettlementId(settlementId);
        for (RelationBill bill : relationBills) {
            bill.setOperator(userMapper.getIdAndName(bill.getOperatorId()));
            bill.setClinic(clinicMapper.getIdAndName(bill.getClinicId()));
        }
        return relationBills;
    }
}
