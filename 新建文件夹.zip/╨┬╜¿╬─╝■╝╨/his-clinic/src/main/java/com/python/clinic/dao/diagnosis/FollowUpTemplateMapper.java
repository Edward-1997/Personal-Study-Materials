package com.python.clinic.dao.diagnosis;

import com.python.clinic.entity.diagnosis.FollowUpTemplate;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 随访模板 Mapper 接口
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-28
 */
public interface FollowUpTemplateMapper extends BaseMapper<FollowUpTemplate> {

}
