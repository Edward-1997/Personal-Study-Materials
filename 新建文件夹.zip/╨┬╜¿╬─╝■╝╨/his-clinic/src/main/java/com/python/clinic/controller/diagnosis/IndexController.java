package com.python.clinic.controller.diagnosis;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.python.clinic.entity.diagnosis.Index;
import com.python.clinic.service.diagnosis.IndexService;
import com.python.common.response.CommonResult;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 * 指标项表 前端控制器
 * </p>
 *
 * @author hm
 * @since 2020-06-06
 */
@RestController
@RequestMapping("/index")
public class IndexController {

    @Autowired
    private IndexService indexService;

    @GetMapping("/listIndex")
    @ApiOperation("获取指标列表")
    public CommonResult listIndex(@RequestParam(defaultValue = "1") Integer pageNum,
                                  @RequestParam(defaultValue = "10") Integer pageSize,
                                  String indexName,Integer clinicId){
        return CommonResult.success(indexService.page(new Page<>(pageNum,pageSize)
                ,new QueryWrapper<Index>().like(!StringUtils.isEmpty(indexName),"index_name",indexName).eq("clinic_id",clinicId)));
    }

    @PostMapping("/saveIndex")
    @ApiOperation("添加指标项")
    public CommonResult saveIndex(@Validated @RequestBody Index index){
        //判断名称是否重复
        int count = indexService.count(new QueryWrapper<Index>().eq("index_name", index.getIndexName()));
        if (count > 0){
            return CommonResult.failed("指标项已存在");
        }
        return CommonResult.result(indexService.save(index));
    }

    @PutMapping("/updateIndex")
    @ApiOperation("修改指标项")
    public CommonResult updateIndex(@RequestBody Index index){
        //判断名称是否重复
        int count = indexService.count(new QueryWrapper<Index>().eq("index_name", index.getIndexName())
                .ne("id", index.getId()));
        if (count > 0){
            return CommonResult.failed("指标项已存在");
        }
        return CommonResult.result(indexService.updateById(index));
    }

    @DeleteMapping("/deleteIndex/{id}")
    @ApiOperation("删除指标项")
    public CommonResult deleteIndex(@PathVariable Integer id){
        return CommonResult.result(indexService.removeById(id));
    }

}
