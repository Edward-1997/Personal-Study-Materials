package com.python.clinic.dao.patient;

import com.python.clinic.entity.patient.IntegralFlow;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 积分流水 Mapper 接口
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-20
 */
public interface IntegralFlowMapper extends BaseMapper<IntegralFlow> {

}
