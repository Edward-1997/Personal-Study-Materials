package com.python.clinic.entity.marketing.dto;

import com.python.clinic.entity.marketing.DiscountActivities;
import com.python.clinic.entity.marketing.MemberCard;
import com.python.clinic.entity.stock.Goods;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/6/11 17:19
 **/
@Data
public class ConflictSettingDto {

    @ApiModelProperty(value = "冲突折扣活动详情")
    private DiscountActivities discountActivities;

    @ApiModelProperty(value = "折扣")
    private Double discount;

    @ApiModelProperty(value = "商品")
    private Goods goods;

    @ApiModelProperty(value = "活动对象")
    private List<String> applicators;
}
