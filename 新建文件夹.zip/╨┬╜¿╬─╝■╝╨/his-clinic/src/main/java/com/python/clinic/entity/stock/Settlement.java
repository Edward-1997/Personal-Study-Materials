package com.python.clinic.entity.stock;

import java.math.BigDecimal;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import java.util.List;

import com.python.clinic.entity.stock.vo.StockLogVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 结算申请表
 * </p>
 *
 * @author hm
 * @since 2020-05-28
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_settlement")
@ApiModel(value="Settlement对象", description="结算申请表")
public class Settlement extends Model<Settlement> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "结算单号")
    private String orderNo;

    @ApiModelProperty(value = "价税合计")
    private BigDecimal amount;

    @ApiModelProperty(value = "不含税金额")
    private BigDecimal amountExcludingTax;

    @ApiModelProperty(value = "税额")
    private BigDecimal tax;

    @ApiModelProperty(value = "供应商id")
    private Integer supplierId;

    @ApiModelProperty(value = "创建时间")
    private Date createTime;

    @ApiModelProperty(value = "创建人id")
    private Integer createId;

    @ApiModelProperty(value = "审核时间")
    private Date auditTime;

    @ApiModelProperty(value = "审核人id")
    private Integer auditId;

    @ApiModelProperty(value = "状态，0：待审核，1：已结算，2：未通过，3：已作废")
    private Integer status;

    @ApiModelProperty(value = "诊所id")
    private Integer clinicId;

    @TableField(exist = false)
    @ApiModelProperty(value = "结算明细")
    private List<SettlementDetails> detailsList;

    @TableField(exist = false)
    @ApiModelProperty(value = "发票")
    private List<Invoice> invoiceList;

    @TableField(exist = false)
    @ApiModelProperty(value = "关联单据")
    private List<RelationBill> billList;

    @TableField(exist = false)
    @ApiModelProperty(value = "日志")
    private List<StockLogVo> logList;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
