package com.python.clinic.entity.sys;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 科室成员表
 * </p>
 *
 * @author hm
 * @since 2020-06-02
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_department_user")
@ApiModel(value="DepartmentUser对象", description="科室成员表")
public class DepartmentUser extends Model<DepartmentUser> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "科室id")
    private Integer departmentId;

    @ApiModelProperty(value = "成员id")
    private Integer userId;


    @Override
    protected Serializable pkVal() {
        return null;
    }

}
