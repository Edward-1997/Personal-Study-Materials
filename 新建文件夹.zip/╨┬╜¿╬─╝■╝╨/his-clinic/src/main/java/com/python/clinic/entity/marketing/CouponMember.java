package com.python.clinic.entity.marketing;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 优惠券会员表
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-06
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_coupon_member")
@ApiModel(value="CouponMember对象", description="优惠券会员表")
public class CouponMember extends Model<CouponMember> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "优惠券id")
    private Integer couponId;

    @ApiModelProperty(value = "会员卡id")
    private Integer memberId;


    @Override
    protected Serializable pkVal() {
        return null;
    }

}
