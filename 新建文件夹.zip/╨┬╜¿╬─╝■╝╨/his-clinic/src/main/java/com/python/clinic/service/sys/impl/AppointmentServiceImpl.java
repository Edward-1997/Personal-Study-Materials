package com.python.clinic.service.sys.impl;

import com.python.clinic.entity.sys.Appointment;
import com.python.clinic.dao.sys.AppointmentMapper;
import com.python.clinic.service.sys.AppointmentService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 预约设置 服务实现类
 * </p>
 *
 * @author hm
 * @since 2020-06-03
 */
@Service
public class AppointmentServiceImpl extends ServiceImpl<AppointmentMapper, Appointment> implements AppointmentService {

}
