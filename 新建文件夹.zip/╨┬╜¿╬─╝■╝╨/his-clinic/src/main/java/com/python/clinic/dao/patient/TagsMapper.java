package com.python.clinic.dao.patient;

import com.python.clinic.entity.patient.Tags;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 标签表 Mapper 接口
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-21
 */
public interface TagsMapper extends BaseMapper<Tags> {
    Tags selectTagById(Integer id);
}
