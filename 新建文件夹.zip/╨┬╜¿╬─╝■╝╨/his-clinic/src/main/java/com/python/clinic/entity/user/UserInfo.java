package com.python.clinic.entity.user;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 用户信息表
 * </p>
 *
 * @author hm
 * @since 2020-06-02
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_user_info")
@ApiModel(value="UserInfo对象", description="用户信息表")
public class UserInfo extends Model<UserInfo> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "展示在微诊所，0：false，1：true")
    private Integer display;

    @ApiModelProperty(value = "执业照")
    private String licensePic;

    @ApiModelProperty(value = "介绍")
    private String introduction;

    @ApiModelProperty(value = "擅长")
    private String goodAt;

    @ApiModelProperty(value = "his编码")
    private String code;

    @ApiModelProperty(value = "性别，0：男，1：女")
    private Integer gender;

    @ApiModelProperty(value = "民族")
    private String nation;

    @ApiModelProperty(value = "生日")
    private Date birthday;

    @ApiModelProperty(value = "证件类型")
    private Integer credentialsType;

    @ApiModelProperty(value = "证件号")
    private String credentialsNo;

    @ApiModelProperty(value = "注册地")
    private String registerPlace;

    @ApiModelProperty(value = "执业范围")
    private String practiceScope;

    @ApiModelProperty(value = "执业证书编号")
    private String practiceCredentialsCode;

    @ApiModelProperty(value = "资格证书编码")
    private String qualificationCertificateCode;

    @ApiModelProperty(value = "职务")
    private String position;

    @ApiModelProperty(value = "诊所开始执业时间")
    private Date clinicPracticeStartTime;

    @ApiModelProperty(value = "诊所结束执业时间")
    private Date clinicPracticeEndTime;

    @ApiModelProperty(value = "执业开始时间")
    private Date practiceStartTime;

    @ApiModelProperty(value = "执业结束时间")
    private Date practiceEndTime;

    @ApiModelProperty(value = "处方特权")
    private Integer prescriptionPrivilege;

    @ApiModelProperty(value = "特殊处方权")
    private String specialPrescriptionPrivilege;

    @ApiModelProperty(value = "用户id")
    private Integer userId;

    @ApiModelProperty(value = "是否助理所有医生，0：false，1：true")
    private Integer allAssistant;

    @ApiModelProperty(value = "是否所有理疗，0：false，1：true")
    private Integer allTreat;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
