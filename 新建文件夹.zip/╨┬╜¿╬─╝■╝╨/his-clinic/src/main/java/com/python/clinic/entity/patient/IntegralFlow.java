package com.python.clinic.entity.patient;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 积分流水
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-20
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_integral_flow")
@ApiModel(value="IntegralFlow对象", description="积分流水")
public class IntegralFlow extends Model<IntegralFlow> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "患者会员卡id")
    private Integer patientCardId;

    @ApiModelProperty(value = "交易时间")
    private Date transactionTime;

    @ApiModelProperty(value = "类型，1、获得，2、退费扣除，3、兑换")
    private Integer type;

    @ApiModelProperty(value = "积分变更")
    private Integer integralChange;

    @ApiModelProperty(value = "剩余积分")
    private Integer surplusIntegral;

    @ApiModelProperty(value = "备注")
    private String remark;

    @ApiModelProperty(value = "收费人（创建人）")
    private Integer createId;

    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
