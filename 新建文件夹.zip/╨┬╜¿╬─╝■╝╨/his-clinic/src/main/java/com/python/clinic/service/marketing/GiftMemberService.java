package com.python.clinic.service.marketing;

import com.python.clinic.entity.marketing.GiftMember;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 * 满减活动指定会员 服务类
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-05
 */
public interface GiftMemberService extends IService<GiftMember> {

    /**
     * 获取满减活动指定会员卡详情
     * @author tanglong
     * @param giftMember 满减活动条件
     * @return java.util.List<com.python.clinic.entity.marketing.GiftMember>
     * @since 2020/6/8 10:54
     **/
    List<GiftMember> getGiftMemberList(GiftMember giftMember);
}
