package com.python.clinic.service.stock.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.python.clinic.dao.stock.StockLogDetailsMapper;
import com.python.clinic.entity.stock.StockLogDetails;
import com.python.clinic.service.stock.StockLogDetailsService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 入库日志详情表 服务实现类
 * </p>
 *
 * @author hm
 * @since 2020-05-19
 */
@Service
public class StockLogDetailsServiceImpl extends ServiceImpl<StockLogDetailsMapper, StockLogDetails> implements StockLogDetailsService {

}
