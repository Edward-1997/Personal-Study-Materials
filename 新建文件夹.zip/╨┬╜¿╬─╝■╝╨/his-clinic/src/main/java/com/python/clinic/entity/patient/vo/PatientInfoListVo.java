package com.python.clinic.entity.patient.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/5/22 16:59
 **/
@Data
public class PatientInfoListVo {
    @ApiModelProperty(value = "患者主键")
    private Integer patientId;

    @ApiModelProperty(value = "患者姓名")
    private String patientName;

    @ApiModelProperty(value = "性别 0：男  1：女")
    private Integer gender;

    @ApiModelProperty(value = "年龄, 小于128")
    private Integer age;

    @ApiModelProperty(value = "最近就诊时间")
    private Date diagnosisTime;
}
