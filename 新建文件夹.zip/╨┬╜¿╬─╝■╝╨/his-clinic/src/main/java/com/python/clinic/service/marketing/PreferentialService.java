package com.python.clinic.service.marketing;

import com.python.clinic.entity.marketing.Preferential;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 优惠信息表 服务类
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-05
 */
public interface PreferentialService extends IService<Preferential> {

}
