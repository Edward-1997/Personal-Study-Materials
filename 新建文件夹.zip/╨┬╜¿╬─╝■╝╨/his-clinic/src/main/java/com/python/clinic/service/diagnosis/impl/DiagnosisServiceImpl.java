package com.python.clinic.service.diagnosis.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.python.clinic.dao.diagnosis.*;
import com.python.clinic.dao.sys.ClinicMapper;
import com.python.clinic.entity.diagnosis.*;
import com.python.clinic.entity.diagnosis.dto.DiagnosisDetailsDto;
import com.python.clinic.entity.diagnosis.vo.DiagnosisRecordsVo;
import com.python.clinic.entity.diagnosis.vo.TreatmentItemVo;
import com.python.clinic.service.diagnosis.DiagnosisItemService;
import com.python.clinic.service.diagnosis.DiagnosisService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.python.clinic.service.diagnosis.PrescriptionService;
import com.python.clinic.service.sys.ClinicService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 * 门诊表 服务实现类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-22
 */
@Service
public class DiagnosisServiceImpl extends ServiceImpl<DiagnosisMapper, Diagnosis> implements DiagnosisService {
    @Autowired
    private DiagnosisMapper diagnosisMapper;
    @Autowired
    private DiagnosisItemService diagnosisItemService;
    @Autowired
    private PrescriptionService prescriptionService;
    @Autowired
    private ClinicService clinicService;

    @Override
    public IPage<DiagnosisRecordsVo> selectRecordByPatientId(Integer pageSize, Integer pageNum, Integer patientId) {
        //按照诊断时间降序
        IPage<Diagnosis> pages = new Page<>(pageNum,pageSize);
        Diagnosis diagnosis = new Diagnosis();
        diagnosis.setPatientId(patientId);
        IPage<Diagnosis> page = diagnosisMapper.selectPage(pages,
                new QueryWrapper<>(diagnosis).orderByDesc("diagnosis_time"));

        if(page.getRecords().size()>0){
            return page.convert(diagnosisRecord->{
                DiagnosisRecordsVo record = new DiagnosisRecordsVo();
                record.setId(diagnosisRecord.getId());
                record.setDiagnosisDate(diagnosisRecord.getDiagnosisTime());
                record.setDiagnosis(diagnosisRecord.getDiagnosis());
                record.setClinic(clinicService.getClinicInfo(diagnosisRecord.getClinicId()).getClinicName());
                //获取开单人姓名,没有用户模块暂时不做
                //userMapper.selectById(diagnosisRecord.getDrawer()).getUserName();
                record.setDoctor(diagnosisRecord.getDrawer().toString());
                return record;
            });

        }
        return null;
    }

    @Override
    public DiagnosisDetailsDto getDiagnosisDetails(Integer id) {
        DiagnosisDetailsDto diagnosisDetails = new DiagnosisDetailsDto();
        //获取门诊表信息
        Diagnosis diagnosis = diagnosisMapper.selectById(id);
        diagnosisDetails.setDiagnosis(diagnosis);
        //获取诊疗项目信息
        DiagnosisItem item = new DiagnosisItem();
        item.setDiagnosisId(id);
        List<TreatmentItemVo> treatmentList = diagnosisItemService.getTreatmentList(item);

        //获取处方详情
        Prescription selectPre = new Prescription();
        selectPre.setRelationId(id);
        selectPre.setRelationType(1);//关联类型：模板表是0，诊断类型是1

        List<Prescription> prescriptions = prescriptionService.getPrescriptionList(selectPre);

        diagnosisDetails.setPrescription(prescriptions);
        diagnosisDetails.setTreatmentItem(treatmentList);

        return diagnosisDetails;
    }
}
