package com.python.clinic.service.user.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.python.clinic.dao.user.ShiftManagementMapper;
import com.python.clinic.dao.user.UserMapper;
import com.python.clinic.entity.user.Scheduling;
import com.python.clinic.dao.user.SchedulingMapper;
import com.python.clinic.entity.user.ShiftManagement;
import com.python.clinic.entity.user.User;
import com.python.clinic.entity.enums.WeekEnum;
import com.python.clinic.entity.user.vo.ScheduleShiftsVo;
import com.python.clinic.entity.user.vo.SchedulingVo;
import com.python.clinic.service.user.SchedulingService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.python.common.response.CommonResult;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * 排班详情表 服务实现类
 * </p>
 *
 * @author hm
 * @since 2020-06-05
 */
@Service
public class SchedulingServiceImpl extends ServiceImpl<SchedulingMapper, Scheduling> implements SchedulingService {

    @Resource
    private SchedulingMapper schedulingMapper;
    @Resource
    private ShiftManagementMapper shiftManagementMapper;
    @Resource
    private UserMapper userMapper;

    @Override
    public CommonResult saveScheduling(List<Scheduling> schedulingList) {
        //添加排班
        for (int i = 0; i < schedulingList.size(); i++) {
            Scheduling scheduling = schedulingList.get(i);
            ShiftManagement shiftManagement = shiftManagementMapper.getShiftManagementById(scheduling.getShiftId());
            //判断时间是否冲突 (s1 >= e2 or s2 >= e1)：不冲突，取反则为冲突
            for (int j = i+1; j < schedulingList.size(); j++){
                ShiftManagement temp = shiftManagementMapper.getShiftManagementById(schedulingList.get(j).getShiftId());
                if (!((shiftManagement.getStartTime().compareTo(temp.getEndTime()) >= 0) ||
                        (temp.getStartTime().compareTo(shiftManagement.getEndTime()) >= 0))){
                    return CommonResult.failed("排班时间有冲突");
                }
            }
        }
        //没有冲突，先删除原有排班，再添加
        int count = schedulingMapper.saveBatch(schedulingList);
        if (count <= 0){
            return CommonResult.failed("添加排班失败");
        }
        return CommonResult.success(null,"添加排班成功");
    }

    @Override
    public boolean getNowAfterSchedulingCountByRoomId(Integer roomId) {
        //count大于零表示该诊室有排班，返回true
        return schedulingMapper.getNowAfterSchedulingCountByRoomId(roomId) > 0;
    }

    @Override
    public IPage<SchedulingVo> listUserScheduling(IPage<User> page, String role, Integer departmentId, String startTime) {
        //分页数据
        IPage<SchedulingVo> schedulingVoIPage = userMapper.listUserByRoleAndDepartmentId(page, role, departmentId);
        //用户
        List<SchedulingVo> schedulingVos = schedulingVoIPage.getRecords();
        //排班日期集合
        List<ScheduleShiftsVo> schedules;
        //开始时间，默认是周一
        LocalDate date = LocalDate.parse(startTime, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        for (SchedulingVo schedulingVo : schedulingVos) {
            schedules = new ArrayList<>();
            for (int i = 0; i < 7; i++){
                LocalDate tempTime = date.plusDays(i);
                schedules.add(new ScheduleShiftsVo(WeekEnum.getByValue(tempTime.getDayOfWeek().getValue()),tempTime,
                        schedulingMapper.listScheduling(schedulingVo.getId(),tempTime.toString())));
                schedulingVo.setSchedules(schedules);
            }
        }
        return schedulingVoIPage;
    }
}
