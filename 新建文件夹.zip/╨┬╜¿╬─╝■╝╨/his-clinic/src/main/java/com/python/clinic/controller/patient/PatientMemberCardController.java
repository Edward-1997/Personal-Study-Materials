package com.python.clinic.controller.patient;


import com.python.clinic.entity.patient.IntegralFlow;
import com.python.clinic.entity.patient.TransactionFlow;
import com.python.clinic.entity.patient.constant.PatientConstant;
import com.python.clinic.entity.patient.vo.MemberCardInfoVo;
import com.python.clinic.service.patient.PatientMemberCardService;
import com.python.clinic.service.patient.TransactionFlowService;
import com.python.common.response.CommonResult;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 * 患者会员卡 前端控制器
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-20
 */
@RestController
@RequestMapping("/patient_member_card")
public class PatientMemberCardController {
    @Autowired
    private PatientMemberCardService memberCardService;

    @ApiOperation(value = "查询患者会员信息",notes = "传入患者Id，返回值为null，则说明该患者不是会员")
    @GetMapping("/card/{patientId}")
    public CommonResult getPatientCard(@PathVariable Integer patientId){
        return memberCardService.getMemberCard(patientId);
    }

    @ApiOperation(value = "查询会员档案记录",
            notes = "分页查询，默认一页10条患者记录，pageSize:数量，pageNum:起始位置，当前余额=本金余额+赠金余额，" +
                    "orderField 排序字段：当前余额(surplusCapital)，当前积分(integral)，累计积分(totalIntegral)。" +
                    "默认按照当前余额。orderType 排序类型 0:降序 1：升序，默认是降序")
    @GetMapping("/list")
    public CommonResult getMemberArchiveList(@RequestParam(defaultValue = "1") Integer pageNum,
                                             @RequestParam(defaultValue = "10") Integer pageSize,
                                             @RequestParam(defaultValue = "surplusCapital") String orderField,
                                             @RequestParam(defaultValue = "0") Integer orderType){
        return memberCardService.selectMemberList(orderField,orderType,pageSize,pageNum);
    }

    @ApiOperation(value = "删除会员信息",notes = "传入患者会员卡主键 id，实现删除患者会员卡功能")
    @DeleteMapping("/member/{id}")
    public CommonResult deletePatientMemberCard(@PathVariable Integer id){
        return memberCardService.deletePatientMemberCard(id);
    }

    @ApiOperation(value = "修改患者会员信息",notes ="传入患者信息，实现修改患者会员信息操作")
    @PutMapping("/patient")
    public CommonResult updateMemberInfo(@RequestBody MemberCardInfoVo info){
        return memberCardService.updateMemberInfo(info);
    }

    @ApiOperation(value = "新增患者会员",notes ="传入患者信息，实现修改患者会员信息操作")
    @PostMapping("/patient")
    public CommonResult insertMemberInfo(@RequestBody MemberCardInfoVo info){
        return memberCardService.insertMemberInfo(info);
    }


    @ApiOperation(value = "充值/储蓄金、赠送金",notes = "传入患者Id（patientCardId与customer相同），储值金（payPrincipal），" +
            "赠送金（payGiftAmout）,销售员（seller）,支付方式（payMethod），创建人id（createId） ")
    @PutMapping("/fill/capital")
    public CommonResult insertTransactionRecord(@RequestBody TransactionFlow record){
        if(record.getPayPrincipal().signum() == -1 || record.getPayGiftAmout().signum() == -1){
            return CommonResult.failed("传入金额参数非负");
        }
        record.setType(PatientConstant.Transaction.fillCapital);
        return memberCardService.updateMemberCapital(record);
    }

    @ApiOperation(value = "会员管理/退款(退储蓄金)",notes = "传入患者Id（patientCardId与customer相同），储值金（payPrincipal），" +
            "赠送金（payGiftAmout）,销售员（seller）,支付方式（payMethod），创建人id（createId） ")
    @PutMapping("/refund/capital")
    public CommonResult reFundCapitalTransactionRecord(@RequestBody TransactionFlow record){
        if(record.getPayPrincipal().signum() == -1 || record.getPayGiftAmout().signum() == -1){
            return CommonResult.failed("传入金额参数非负");
        }
        record.setPayGiftAmout(record.getPayGiftAmout().negate());
        record.setPayPrincipal(record.getPayPrincipal().negate());
        record.setType(PatientConstant.Transaction.refundCapital);
        return memberCardService.updateMemberCapital(record);
    }




    @ApiOperation(value = "兑换/积分",notes = "传入患者会员卡Id（patientCardId,患者手机号），兑换积分值（integralChange）" +
            "，备注（remark）,创建人id（createId） ")
    @PutMapping("/conversion/integral")
    public CommonResult exchangeIntegral(@RequestBody IntegralFlow record){
        if(record.getIntegralChange()<=0){
            return CommonResult.failed("传入积分参数为正数");
        }
        record.setIntegralChange(-record.getIntegralChange());
        record.setType(3);//3 代表兑换
        return memberCardService.updateMemberIntegral(record);
    }
}
