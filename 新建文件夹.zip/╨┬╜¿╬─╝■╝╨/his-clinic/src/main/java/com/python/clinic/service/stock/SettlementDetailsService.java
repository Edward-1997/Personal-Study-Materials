package com.python.clinic.service.stock;

import com.python.clinic.entity.stock.SettlementDetails;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 结算明细表 服务类
 * </p>
 *
 * @author hm
 * @since 2020-05-28
 */
public interface SettlementDetailsService extends IService<SettlementDetails> {

}
