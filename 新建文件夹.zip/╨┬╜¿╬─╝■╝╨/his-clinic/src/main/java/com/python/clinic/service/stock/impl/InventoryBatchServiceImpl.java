package com.python.clinic.service.stock.impl;

import com.python.clinic.entity.stock.InventoryBatch;
import com.python.clinic.dao.stock.InventoryBatchMapper;
import com.python.clinic.service.stock.InventoryBatchService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 盘点批次表 服务实现类
 * </p>
 *
 * @author hm
 * @since 2020-05-27
 */
@Service
public class InventoryBatchServiceImpl extends ServiceImpl<InventoryBatchMapper, InventoryBatch> implements InventoryBatchService {

}
