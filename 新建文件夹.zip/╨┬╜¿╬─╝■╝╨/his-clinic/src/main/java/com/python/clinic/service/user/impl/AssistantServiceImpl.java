package com.python.clinic.service.user.impl;

import com.python.clinic.entity.user.Assistant;
import com.python.clinic.dao.user.AssistantMapper;
import com.python.clinic.service.user.AssistantService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 医生助理表 服务实现类
 * </p>
 *
 * @author hm
 * @since 2020-06-02
 */
@Service
public class AssistantServiceImpl extends ServiceImpl<AssistantMapper, Assistant> implements AssistantService {

}
