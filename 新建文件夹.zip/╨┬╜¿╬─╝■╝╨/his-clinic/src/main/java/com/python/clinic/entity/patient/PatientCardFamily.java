package com.python.clinic.entity.patient;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 会员卡家庭成员表
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-20
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_patient_card_family")
@ApiModel(value="PatientCardFamily对象", description="会员卡家庭成员表")
public class PatientCardFamily extends Model<PatientCardFamily> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "患者会员卡id")
    private Integer patientCardId;

    @ApiModelProperty(value = "会员卡家庭成员")
    private Integer patientId;


    @Override
    protected Serializable pkVal() {
        return null;
    }

}
