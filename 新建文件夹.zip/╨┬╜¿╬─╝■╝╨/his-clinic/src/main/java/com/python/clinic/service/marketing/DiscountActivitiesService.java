package com.python.clinic.service.marketing;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.python.clinic.entity.marketing.DiscountActivities;
import com.baomidou.mybatisplus.extension.service.IService;
import com.python.clinic.entity.marketing.dto.DiscountActivityDetailsDto;
import com.python.clinic.entity.marketing.vo.DiscountActivitiesVo;
import com.python.common.response.CommonResult;

/**
 * <p>
 * 折扣活动表 服务类
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-02
 */
public interface DiscountActivitiesService extends IService<DiscountActivities> {

    /**
     * 根据折扣id获取折扣详情
     * @author tanglong
     * @param id 活动id
     * @return com.python.common.response.CommonResult
     * @since 2020/6/10 14:29
     **/
    DiscountActivityDetailsDto getDiscountActivityDetails(Integer id);

    /**
     * 分页查询折扣活动
     * @author tanglong
     * @return com.baomidou.mybatisplus.core.metadata.IPage<com.python.clinic.entity.marketing.DiscountActivities>
     * @since 2020/6/10 17:30
     **/
    IPage<DiscountActivitiesVo> getDiscountActivities(Integer pageNum, Integer pageSize);
}
