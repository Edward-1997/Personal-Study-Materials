package com.python.clinic.entity.stock;

import java.math.BigDecimal;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import java.util.List;
import java.util.Map;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 出库详情表
 * </p>
 *
 * @author hm
 * @since 2020-05-23
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_out_of_stock_details")
@ApiModel(value="OutOfStockDetails对象", description="出库详情表")
public class OutOfStockDetails extends Model<OutOfStockDetails> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "出库id")
    private Integer outStockId;

    @ApiModelProperty(value = "商品id")
    private Integer goodsId;

    @ApiModelProperty(value = "出库数量")
    private Integer outNum;

    @ApiModelProperty(value = "金额")
    private BigDecimal amount;

    @ApiModelProperty(value = "不含税金额")
    private BigDecimal noTaxAmount;

    @ApiModelProperty(value = "商品编号")
    private String goodsCode;

    @ApiModelProperty(value = "商品名称")
    private String goodsName;

    @ApiModelProperty(value = "规格")
    private String specifications;

    @ApiModelProperty(value = "厂家")
    private String manufactor;

    @ApiModelProperty(value = "指定批次，false：不指定，true：指定")
    private Boolean specifyBatch;

    @ApiModelProperty(value = "批次id")
    private Integer batchId;

    @ApiModelProperty(value = "进价")
    private BigDecimal purchasePrice;

    @ApiModelProperty(value = "出库数量单位")
    private String outUnit;

    @ApiModelProperty(value = "是否为散装，false，true")
    private Boolean piece;

    @ApiModelProperty(value = "进价单位")
    private String purchasePriceUnit;

    @ApiModelProperty(value = "进项税率")
    private BigDecimal inTaxRat;

    @ApiModelProperty(value = "出项税率")
    private BigDecimal outTaxRat;

    @ApiModelProperty(value = "出库批次集合，未指定批次时使用该集合")
    @TableField(exist = false)
    private List<Map<String,Object>> stockBatchList;

    @ApiModelProperty(value = "出库批次对象，指定批次时使用该对象")
    @TableField(exist = false)
    private WarehousingBatch warehousingBatch;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
