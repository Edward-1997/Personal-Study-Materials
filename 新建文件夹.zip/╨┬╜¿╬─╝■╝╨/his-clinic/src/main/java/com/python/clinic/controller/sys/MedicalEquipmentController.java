package com.python.clinic.controller.sys;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.python.clinic.entity.sys.MedicalEquipment;
import com.python.clinic.service.sys.MedicalEquipmentService;
import com.python.common.response.CommonResult;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 * 医疗设备表 前端控制器
 * </p>
 *
 * @author hm
 * @since 2020-06-02
 */
@RestController
@RequestMapping("/medicalEquipment")
public class MedicalEquipmentController {

    @Autowired
    private MedicalEquipmentService medicalEquipmentService;

    @GetMapping("/listMedicalEquipment")
    @ApiOperation("获取医疗设备列表")
    public CommonResult listMedicalEquipment(@RequestParam(defaultValue = "1") Integer pageNo,
                                             @RequestParam(defaultValue = "10") Integer pageSize){
        IPage<MedicalEquipment> page = new Page<>(pageNo,pageSize);
        return CommonResult.success(medicalEquipmentService.listMedicalEquipment(page));
    }

    @PostMapping("/saveMedicalEquipment")
    @ApiOperation("添加医疗设备")
    public CommonResult saveMedicalEquipment(@RequestBody MedicalEquipment medicalEquipment){
        return CommonResult.result(medicalEquipmentService.save(medicalEquipment));
    }

    @PostMapping("/updateMedicalEquipment")
    @ApiOperation("修改医疗设备信息")
    public CommonResult updateMedicalEquipment(@RequestBody MedicalEquipment medicalEquipment){
        return CommonResult.result(medicalEquipmentService.updateById(medicalEquipment));
    }

    @GetMapping("/getMedicalEquipment")
    @ApiOperation("查看医疗设备详情")
    public CommonResult getMedicalEquipment(@RequestParam(required = true) Integer id){
        return CommonResult.success(medicalEquipmentService.getById(id));
    }

    @DeleteMapping("/delMedicalEquipment")
    @ApiOperation("删除医疗设备")
    public CommonResult delMedicalEquipment(@RequestParam(required = true) Integer id){
        return CommonResult.success(medicalEquipmentService.removeById(id));
    }

}
