package com.python.clinic.entity.marketing.vo;

import com.python.clinic.entity.marketing.Coupon;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/6/5 11:08
 **/
@Data
public class CouponListVo {
    @ApiModelProperty(value = "优惠券id")
    private Integer id;
    @ApiModelProperty(value = "优惠券名称")
    private String name;
    @ApiModelProperty(value = "已使用优惠券的数量")
    private Integer usedCouponNum;
    @ApiModelProperty(value = "状态 0：可发券，1：停止发券，2：已作废")
    private Integer status;
    @ApiModelProperty(value = "优惠内容")
    private String giftContent;
    @ApiModelProperty(value = "已领取/总量")
    private String obtainPercent;

}
