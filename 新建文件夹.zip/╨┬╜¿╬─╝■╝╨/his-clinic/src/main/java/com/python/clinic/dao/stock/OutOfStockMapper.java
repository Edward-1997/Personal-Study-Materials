package com.python.clinic.dao.stock;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.python.clinic.entity.stock.OutOfStock;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.Date;

/**
 * <p>
 * 出库表 Mapper 接口
 * </p>
 *
 * @author hm
 * @since 2020-05-23
 */
public interface OutOfStockMapper extends BaseMapper<OutOfStock> {

    /**
     * 分页带条件查询出库列表
     * @param page
     * @param startTime 开始时间
     * @param endTime   结束时间
     * @param type      类型  0：科室，1：报损，2：退货
     * @param goodsId   商品id
     * @return
     */
    IPage<OutOfStock> selectPage(IPage<OutOfStock> page, @Param("startTime")String startTime, @Param("endTime")String endTime,
                                 @Param("type")Integer type, @Param("goodsId")Integer goodsId);

}
