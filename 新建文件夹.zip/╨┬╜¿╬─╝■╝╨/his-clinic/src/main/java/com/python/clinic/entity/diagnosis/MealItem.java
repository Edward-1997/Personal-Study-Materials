package com.python.clinic.entity.diagnosis;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 套餐项目表
 * </p>
 *
 * @author hm
 * @since 2020-06-06
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_meal_item")
@ApiModel(value="MealItem对象", description="套餐项目表")
public class MealItem extends Model<MealItem> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "套餐id")
    private Integer mealId;

    @ApiModelProperty(value = "诊疗项目id")
    private Integer itemId;

    @ApiModelProperty(value = "诊疗项目价格")
    private BigDecimal price;

    @ApiModelProperty(value = "数量")
    private Integer num;


    @Override
    protected Serializable pkVal() {
        return null;
    }

}
