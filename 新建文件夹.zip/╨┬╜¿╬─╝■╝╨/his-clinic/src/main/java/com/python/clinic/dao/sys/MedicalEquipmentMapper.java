package com.python.clinic.dao.sys;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.python.clinic.entity.sys.MedicalEquipment;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.List;

/**
 * <p>
 * 医疗设备表 Mapper 接口
 * </p>
 *
 * @author hm
 * @since 2020-06-02
 */
public interface MedicalEquipmentMapper extends BaseMapper<MedicalEquipment> {

    /**
     * 查询医疗设备列表
     * @param page
     * @return
     */
    IPage<MedicalEquipment> listMedicalEquipment(IPage<MedicalEquipment> page);

}
