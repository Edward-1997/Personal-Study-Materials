package com.python.clinic.service.marketing.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.python.clinic.dao.marketing.MemberSetMapper;
import com.python.clinic.entity.marketing.MemberSet;
import com.python.clinic.service.marketing.MemberSetService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.python.common.response.CommonResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 会员卡设置表 服务实现类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-20
 */
@Service
public class MemberSetServiceImpl extends ServiceImpl<MemberSetMapper, MemberSet> implements MemberSetService {
    @Autowired
    private MemberSetMapper memberSetMapper;

    @Override
    public MemberSet getRecentRuleSet() {
        return memberSetMapper.selectLastRuleRecord();
    }

    @Override
    public CommonResult updateMemberSet(MemberSet memberSet) {

        if(1==memberSetMapper.updateById(memberSet)){
            return CommonResult.success(null,"会员卡设置成功");
        }
        return CommonResult.failed("会员卡设置失败");
    }

    @Override
    public CommonResult insertMemberSet(MemberSet memberSet) {
        if(1==memberSetMapper.insert(memberSet)){
            return CommonResult.success(null,"新增会员卡设置成功");
        }

        return CommonResult.failed("新增会员卡设置失败");
    }


}
