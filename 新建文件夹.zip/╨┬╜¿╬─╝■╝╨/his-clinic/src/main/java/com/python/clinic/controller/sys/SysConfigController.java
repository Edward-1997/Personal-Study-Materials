package com.python.clinic.controller.sys;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.python.clinic.entity.sys.Calling;
import com.python.clinic.entity.sys.SysConfig;
import com.python.clinic.service.sys.CallingService;
import com.python.clinic.service.sys.SysConfigService;
import com.python.common.response.CommonResult;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 * 系统配置 前端控制器
 * </p>
 *
 * @author hm
 * @since 2020-05-21
 */
@RestController
@RequestMapping("/sysConfig")
public class SysConfigController {

    @Autowired
    private SysConfigService configService;
    @Autowired
    private CallingService callingService;

    @PutMapping("/SysConfig")
    @ApiOperation(value = "修改系统设置",notes = "根据诊所id进行修改")
    public CommonResult updateSysConfig(@RequestBody SysConfig sysConfig){
        boolean isSuccess = configService.update(sysConfig,new QueryWrapper<SysConfig>().eq("clinic_id",sysConfig.getClinicId()));
        if (isSuccess) {
            return CommonResult.success(null,"修改成功");
        }
        return CommonResult.failed("修改失败");
    }

    @GetMapping("/getClinicEarlyWarning/{clinicId}")
    @ApiOperation(value = "获取诊所默认库存预警设置",notes = "需传入诊所id")
    public CommonResult getClinicEarlyWarning(@PathVariable String clinicId){
        QueryWrapper<SysConfig> wrapper = new QueryWrapper<>();
        wrapper.select("id","clinic_id","stock_warn_goods_turnover_days","stock_warn_goods_will_expired_month").eq("clinic_id",clinicId);
        return CommonResult.success(configService.getOne(wrapper));
    }

    @PutMapping("/setRoom/{setRoom}")
    @ApiOperation(value = "排班时设置诊室",notes = "setRoom：设置诊室，false、true")
    public CommonResult setRoom(@PathVariable Boolean setRoom){
        Calling calling = callingService.getOne(new QueryWrapper<Calling>().select("enable_calling"));
        if (calling.getEnableCalling() && !setRoom){
            return CommonResult.failed("诊所已启用排队叫号功能，必须设置诊室才可正常使用。");
        }
        SysConfig sysConfig = new SysConfig();
        sysConfig.setSetRoom(setRoom);
        return CommonResult.result(configService.update(sysConfig,null));
    }

    @GetMapping("/getDefaultRegistrationFee/{clinicId}")
    @ApiOperation(value = "获取默认挂号费",notes = "根据传入诊所id查询")
    public CommonResult getDefaultRegistrationFee(@PathVariable String clinicId){
        QueryWrapper<SysConfig> wrapper = new QueryWrapper<>();
        wrapper.select("id","default_registration_fee_cost","default_registration_fee_sales").eq("clinic_id",clinicId);
        return CommonResult.success(configService.getOne(wrapper));
    }

}
