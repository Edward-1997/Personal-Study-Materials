package com.python.clinic.service.marketing.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.python.clinic.dao.marketing.*;
import com.python.clinic.entity.marketing.Coupon;
import com.python.clinic.entity.marketing.CouponMember;
import com.python.clinic.entity.marketing.UseScope;
import com.python.clinic.entity.marketing.constant.MarketingConstant;
import com.python.clinic.entity.marketing.dto.CouponDetailsDto;
import com.python.clinic.entity.marketing.vo.CouponListVo;
import com.python.clinic.service.marketing.CouponMemberService;
import com.python.clinic.service.marketing.CouponService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.python.clinic.service.marketing.UseScopeService;
import com.python.common.response.CommonResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * <p>
 * 优惠券表 服务实现类
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-05
 */
@Service
public class CouponServiceImpl extends ServiceImpl<CouponMapper, Coupon> implements CouponService {
    @Autowired
    private CouponMapper couponMapper;
    @Autowired
    private PatientCouponMapper patientCouponMapper;
    @Autowired
    private UseScopeService useScopeService;
    @Autowired
    private CouponMemberService couponMemberService;

    @Override
    public IPage<CouponListVo> selectCouponList(Integer pageNum, Integer pageSize,Integer status) {
        IPage<Coupon> couponPages = new Page<>(pageNum,pageSize);
        if(status == -1){//默认查询全部
            couponPages = couponMapper.selectPage(couponPages,new QueryWrapper<Coupon>().orderByDesc("id"));
        }else {//根据状态查询
            Coupon coupon = new Coupon();
            coupon.setStatus(status);
            couponPages = couponMapper.selectPage(couponPages,new QueryWrapper<Coupon>(coupon).orderByDesc("id"));
        }

        return couponPages.convert(coupon -> {
           CouponListVo vo = new CouponListVo();
           vo.setId(coupon.getId());
           vo.setObtainPercent((coupon.getTotalCount()-coupon.getSurplusCount())+"/"+coupon.getTotalCount());
           if(coupon.getUseThreshold().signum() == 0){//表示立减
               vo.setGiftContent("立减"+coupon.getPreferentialPrice());
           }else {//表示有门槛
               vo.setGiftContent("满"+coupon.getUseThreshold()+"减"+coupon.getPreferentialPrice());
           }
           vo.setName(coupon.getCouponName());
           vo.setStatus(coupon.getStatus());
           vo.setUsedCouponNum(patientCouponMapper.getStatisticUseCoupon(coupon.getId()));
           return  vo;
        });
    }

    @Override
    public CouponDetailsDto selectCouponDetails(Integer id) {
        CouponDetailsDto couponDetailsDto = new CouponDetailsDto();

        //获取优惠券详细信息
        couponDetailsDto.setCoupon(couponMapper.selectById(id));
        //获取使用范围详细信息
        UseScope useScope = new UseScope();
        useScope.setRelationId(id);
        useScope.setType(MarketingConstant.UseScope.COUPON_TYPE);//设置使用范围类型
        couponDetailsDto.setUseScopeList(useScopeService.getUseScopeList(useScope));

        //获取领取范围详情
        if(!MarketingConstant.ALL_PATIENT.equals(couponDetailsDto.getCoupon().getAllPatients())){
            //领取范围是指定会员卡
            CouponMember couponMember = new CouponMember();
            couponMember.setCouponId(id);
            couponDetailsDto.setCouponMemberList(couponMemberService.list(new QueryWrapper<>(couponMember)));
        }
        return couponDetailsDto;
    }

    @Transactional
    @Override
    public CommonResult insertCoupon(CouponDetailsDto couponDetailsDto) {
        //新增商品优惠券信息
        if(1 != couponMapper.insert(couponDetailsDto.getCoupon())){
            throw new RuntimeException();
        }
        //新增会员领取范围
        insertObtainScope(couponDetailsDto);
        //新增使用范围信息
        insertUseScope(couponDetailsDto);
        return CommonResult.success(null,"新增商品优惠券成功");
    }

    @Transactional
    @Override
    public CommonResult updateCoupon(CouponDetailsDto couponDetailsDto) {
        //修改优惠券详细信息
        Coupon coupon = couponDetailsDto.getCoupon();
         if(1 != couponMapper.updateById(coupon)){
             throw new RuntimeException();
         }
        //删除旧的使用范围以及例外商品
        UseScope oldUseScope = new UseScope();
        oldUseScope.setRelationId(couponDetailsDto.getCoupon().getId());
        oldUseScope.setType(MarketingConstant.UseScope.COUPON_TYPE);//设置使用范围类型
        if(null ==useScopeService.deleteUseScope(oldUseScope)){
            throw new RuntimeException();
        }

        //删除旧的会员领取范围
        CouponMember couponMember = new CouponMember();
        couponMember.setCouponId(coupon.getId());
        if(!couponMemberService.remove(new QueryWrapper<>(couponMember))){
            throw new RuntimeException();
        }
        //新增会员领取范围
        insertObtainScope(couponDetailsDto);
        //新增更新后的使用范围以及例外商品
        insertUseScope(couponDetailsDto);

        return CommonResult.success(null,"更新成功");
    }

    @Override
    public CommonResult updateCouponStatus(Integer id, Integer status) {
        Coupon coupon = new Coupon();
        coupon.setId(id);
        coupon.setStatus(status);
        if(1==couponMapper.updateById(coupon)){
            return CommonResult.success(null,"修改成功");
        }
        return CommonResult.failed("修改失败");
    }

    private void insertUseScope(CouponDetailsDto couponDetailsDto){
        int index = 0;

        List<UseScope> updateUseScopeList = couponDetailsDto.getUseScopeList();
        for(UseScope useScope:updateUseScopeList){
            useScope.setRelationId(couponDetailsDto.getCoupon().getId());
            if(null == useScopeService.insertUseScope(useScope)){
                throw new RuntimeException();
            }
            index++;
        }

        if(index != updateUseScopeList.size()){
            throw new RuntimeException();
        }
    }

    private void insertObtainScope(CouponDetailsDto couponDetailsDto){
        if(!MarketingConstant.ALL_PATIENT.equals(couponDetailsDto.getCoupon().getAllPatients())){
            //指定会员
            List<CouponMember> couponMemberList = couponDetailsDto.getCouponMemberList();
            couponMemberList.forEach(couponMember1 -> couponMember1.setCouponId(couponDetailsDto.getCoupon().getId()));
            if(!couponMemberService.saveBatch(couponMemberList)){
                throw new RuntimeException();
            }
        }
    }
}
