package com.python.clinic.entity.patient.dto;

import com.python.clinic.entity.patient.Patient;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/5/29 11:02
 **/
@Data
public class PatientInfoDto extends Patient {

    public PatientInfoDto(Patient patient){
        setId(patient.getId());
        setPatientName(patient.getPatientName());
        setAge(patient.getAge());
        setPhone(patient.getPhone());
        setGender(patient.getGender());
        setBirthday(patient.getBirthday());
        setIdCard(patient.getIdCard());
        setSourceFrom(patient.getSourceFrom());
        setSource(patient.getSource());
        setCreateTime(patient.getCreateTime());
        setAddress(patient.getAddress());
        setCreateId(patient.getCreateId());
        setWechat(patient.getWechat());
        setPastHistory(patient.getPastHistory());

    }

    @ApiModelProperty(value = "推荐人姓名")
    private String referee;

}
