package com.python.clinic.entity.marketing;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 满减返活动表
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-05
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_gift_rule_promotions")
@ApiModel(value="GiftRulePromotions对象", description="满减返活动表")
public class GiftRulePromotions extends Model<GiftRulePromotions> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "活动名称")
    private String activityName;

    @ApiModelProperty(value = "活动时间，0：永久有效，1：指定时间")
    private Integer activityTime;

    @ApiModelProperty(value = "开始时间")
    private Date startTime;

    @ApiModelProperty(value = "结束时间")
    private Date endTime;

    @ApiModelProperty(value = "活动对象，0：所有患者，1：指定会员")
    private Integer activityObject;

    @ApiModelProperty(value = "仅原价商品可使用，0：false，1：true")
    private Integer onlyOriginalPrice;

    @ApiModelProperty(value = "状态,0:进行中 1：未开始 2：已结束")
    private Integer status;

    @ApiModelProperty(value = "诊所id")
    private Integer clinicId;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
