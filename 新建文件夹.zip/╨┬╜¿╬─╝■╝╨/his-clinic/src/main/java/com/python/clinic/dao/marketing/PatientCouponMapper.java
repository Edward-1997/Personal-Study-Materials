package com.python.clinic.dao.marketing;

import com.python.clinic.entity.marketing.PatientCoupon;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 患者优惠券表 Mapper 接口
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-05
 */
public interface PatientCouponMapper extends BaseMapper<PatientCoupon> {

    /**
     * 查询已使用的优惠券数量
     * @author tanglong
     * @param couponId 优惠券id
     * @return java.lang.Integer
     * @since 2020/6/5 11:12
     **/
    Integer getStatisticUseCoupon(Integer couponId);
}
