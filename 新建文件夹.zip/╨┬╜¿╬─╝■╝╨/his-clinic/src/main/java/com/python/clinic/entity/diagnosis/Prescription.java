package com.python.clinic.entity.diagnosis;

import java.math.BigDecimal;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import java.util.List;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 处方
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-26
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_prescription")
@ApiModel(value="Prescription对象", description="处方")
public class Prescription extends Model<Prescription> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "关联id，根据关联类型判断")
    private Integer relationId;

    @ApiModelProperty(value = "关联类型  0：模板表，1：诊断")
    private Integer relationType;

    @ApiModelProperty(value = "类型，0：中药处方，1：西药处方，2：注射处方")
    private Integer type;

    @ApiModelProperty(value = "收费状态")
    private Integer chargeStatus;

    @ApiModelProperty(value = "每日剂量")
    private String dailyDosage;

    @ApiModelProperty(value = "剂量数量")
    private Integer doseCount;

    @ApiModelProperty(value = "用法/注射方式")
    private String usageMethod;

    @ApiModelProperty(value = "单次用量")
    private String singleDose;

    @ApiModelProperty(value = "备注")
    private String remark;

    @ApiModelProperty(value = "是否代煎，0：false，1：true")
    private Integer decoction;

    @ApiModelProperty(value = "联系电话")
    private String contactPhone;

    @ApiModelProperty(value = "规格")
    private String specification;

    @ApiModelProperty(value = "静脉滴注")
    private String ivgtt;

    @ApiModelProperty(value = "频率")
    private String freq;

    @ApiModelProperty(value = "天数")
    private Integer days;

    @ApiModelProperty(value = "总价格")
    private BigDecimal totalPrice;

    @TableField(exist = false)
    @ApiModelProperty(value = "处方详细细节")
    private List<PrescriptionDetails> prescriptionDetails;

    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
