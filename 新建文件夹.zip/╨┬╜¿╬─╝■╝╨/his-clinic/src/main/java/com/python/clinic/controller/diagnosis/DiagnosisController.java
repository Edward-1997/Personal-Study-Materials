package com.python.clinic.controller.diagnosis;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.python.clinic.entity.diagnosis.dto.DiagnosisDetailsDto;
import com.python.clinic.entity.diagnosis.vo.DiagnosisRecordsVo;
import com.python.clinic.service.diagnosis.DiagnosisService;
import com.python.common.response.CommonResult;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * 门诊表 前端控制器
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-22
 */
@RestController
@RequestMapping("/diagnosis")
public class DiagnosisController {

    @Autowired
    private DiagnosisService diagnosisService;


    @ApiOperation(value = "查询患者门诊诊断记录/患者档案", notes = "分页查询，默认一页5条患者记录，按照时间降序，" +
                    "传入patientId，患者id，pageSize:数量，pageNum:起始位置，")
    @GetMapping("/records/{patientId}")
    public CommonResult getPatientRecords(@PathVariable Integer patientId,
                                          @RequestParam(defaultValue = "1") Integer pageNum,
                                          @RequestParam(defaultValue = "5") Integer pageSize){
        IPage<DiagnosisRecordsVo> page = diagnosisService.selectRecordByPatientId(pageSize, pageNum, patientId);
        if(page != null){
            Map<String,Object> map = new HashMap<>();
            map.put("diagnosisRecords",page);
            return CommonResult.success(map,"查询患者门诊记录成功");
        }
        return CommonResult.failed("查询患者无门诊记录");
    }

    @ApiOperation(value = "查询患者门诊诊断详细记录", notes = "传入门诊表id")
    @GetMapping("/record/details")
    public CommonResult getDiagnosisDetails(@RequestParam Integer id){
        DiagnosisDetailsDto diagnosisDetails = diagnosisService.getDiagnosisDetails(id);
        Map<String,Object> map = new HashMap<>();
        map.put("diagnosisDetails",diagnosisDetails);
        return CommonResult.success(map);
    }

}
