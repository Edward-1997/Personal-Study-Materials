package com.python.clinic.dao.stock;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.python.clinic.entity.stock.PurchaseApply;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;

/**
 * <p>
 * 采购申请表 Mapper 接口
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-21
 */
public interface PurchaseApplyMapper extends BaseMapper<PurchaseApply> {

    /**
     * 带条件查询采购申请
     * @param status 状态
     * @param dateType  时间添加类型，0：申请日期，1：审核日期
     * @param startTime 开始时间
     * @param endTime   结束时间
     * @param goodsId   商品id
     * @return
     */
    IPage<PurchaseApply> listPurchaseApply(@Param("page") IPage<PurchaseApply> page, @Param("status")Integer status,
                                          @Param("dateType")Integer dateType, @Param("startTime")Date startTime,
                                          @Param("endTime")Date endTime, @Param("goodsId")String goodsId);



}
