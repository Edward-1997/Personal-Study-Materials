package com.python.clinic.dao.diagnosis;

import com.python.clinic.entity.diagnosis.ItemIndex;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 检查项目指标 Mapper 接口
 * </p>
 *
 * @author hm
 * @since 2020-06-06
 */
public interface ItemIndexMapper extends BaseMapper<ItemIndex> {

    /**
     * 批量插入检查项目指标
     * @param list
     * @param itemId
     * @return
     */
    int insertBatch(@Param("list") List<ItemIndex> list, @Param("itemId")Integer itemId);

}
