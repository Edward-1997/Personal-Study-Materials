package com.python.clinic.service.stock.impl;

import com.python.clinic.entity.stock.OutOfStockBatch;
import com.python.clinic.dao.stock.OutOfStockBatchMapper;
import com.python.clinic.service.stock.OutOfStockBatchService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 科室出库详情批次 服务实现类
 * </p>
 *
 * @author hm
 * @since 2020-05-23
 */
@Service
public class OutOfStockBatchServiceImpl extends ServiceImpl<OutOfStockBatchMapper, OutOfStockBatch> implements OutOfStockBatchService {

}
