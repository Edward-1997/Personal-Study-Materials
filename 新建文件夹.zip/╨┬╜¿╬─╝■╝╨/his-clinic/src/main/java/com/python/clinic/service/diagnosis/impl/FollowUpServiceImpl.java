package com.python.clinic.service.diagnosis.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.python.clinic.dao.patient.PatientMapper;
import com.python.clinic.entity.diagnosis.FollowUp;
import com.python.clinic.dao.diagnosis.FollowUpMapper;
import com.python.clinic.entity.diagnosis.dto.FollowUpDto;
import com.python.clinic.entity.diagnosis.vo.FollowUpRecordsVo;
import com.python.clinic.entity.patient.Patient;
import com.python.clinic.service.diagnosis.FollowUpService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.python.common.response.CommonResult;
import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * <p>
 * 随访表 服务实现类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-22
 */
@Service
public class FollowUpServiceImpl extends ServiceImpl<FollowUpMapper, FollowUp> implements FollowUpService {
    @Autowired
    private FollowUpMapper followUpMapper;
    @Autowired
    private PatientMapper patientMapper;
    @Autowired
    private SqlSessionFactory sqlSessionFactory;
    @Override
    public CommonResult getFollowRecord(Integer id) {
        FollowUp followUp = followUpMapper.selectById(id);
        if(followUp == null){
            return CommonResult.failed("数据异常：获取随访记录失败");
        }
        Map<String,Object> map = new HashMap<>();
        map.put("followRecord",followUp);
        return CommonResult.success(map);
    }

    @Override
    public CommonResult getDoctorFollowList(Date followTime, Integer doctorId) {
        FollowUp followUp = new FollowUp();
        followUp.setFollowUpTime(followTime);
        followUp.setFollowUpPeople(doctorId);

        List<FollowUp> followList = followUpMapper.selectList(new QueryWrapper<>(followUp).orderByDesc("follow_up_time"));
        List<FollowUpRecordsVo> recordsList = null;

        Map<String,Object> map = new HashMap<>();
        if(followList != null){
            recordsList = followList.stream().map(followUpRecord -> {
                FollowUpRecordsVo vo = new FollowUpRecordsVo();
                vo.setPatientId(followUpRecord.getPatientId());
                Patient patient = patientMapper.selectById(followUpRecord.getPatientId());
                vo.setPatientName(patient.getPatientName());
                vo.setStatus(followUpRecord.getStatus());
                return vo;
            }).collect(Collectors.toList());
            //获取待执行的随访记录
            followList = followList.stream().filter(record ->record.getStatus() == 0).collect(Collectors.toList());
            map.put("unExecuteFollowRecords",followList);
        }

        map.put("taskList",recordsList);

        return CommonResult.success(map,"获取医生任务列表成功");
    }

    @Override
    public CommonResult updateFollowRecord(FollowUp followUp) {

        int index = followUpMapper.updateById(followUp);
        if(index == 1){
            return CommonResult.success(null,"修改成功");
        }
        return CommonResult.failed("修改失败");
    }

    @Transactional
    @Override
    public CommonResult insertFollowRecord(FollowUpDto followUpDto) throws ParseException {
        Integer[] split = followUpDto.getIds();
        String[] dateTime = followUpDto.getDateTime();

        try (SqlSession sqlSession = sqlSessionFactory.openSession(ExecutorType.BATCH)){
            FollowUpMapper mapper = sqlSession.getMapper(FollowUpMapper.class);
            for(Integer id:split){
                for(String str : dateTime){
                    followUpDto.setPatientId(id);
                    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
                    simpleDateFormat.setLenient(false);
                    followUpDto.setFollowUpTime(simpleDateFormat.parse(str));

                    mapper.insert(followUpDto);
                }
            }
            sqlSession.commit();
        }
        return CommonResult.success(null,"新增随访计划成功");
    }
}
