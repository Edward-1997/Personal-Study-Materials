package com.python.clinic;

import com.python.clinic.entity.enums.GoodsAndTreatmentTypeEnum;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Test {

    public static void main(String[] args) {
        // =:0 <:-1 >:1  以第一个时间为准
        //判断时间是否冲突 (s1 >= e2 or s2 >= e1)：不冲突，取反则为冲突

        // >= --> >=0
        //
        System.out.println(GoodsAndTreatmentTypeEnum.INSPECT.getValue().equals(3));
    }

}
