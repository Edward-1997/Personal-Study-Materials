package com.python.clinic.dao.marketing;

import com.python.clinic.entity.marketing.MemberSet;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 会员卡设置表 Mapper 接口
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-20
 */
public interface MemberSetMapper extends BaseMapper<MemberSet> {

    /**
     * 查询主键最大的规则记录（规定主键最大为最近的一次记录设置）
     * @author tanglong
     * @return com.python.clinic.entity.patient.MemberSet
     * @since 2020/6/2 14:47
     **/
    MemberSet selectLastRuleRecord();
}
