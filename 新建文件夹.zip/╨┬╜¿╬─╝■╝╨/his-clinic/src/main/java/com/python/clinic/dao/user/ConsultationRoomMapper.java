package com.python.clinic.dao.user;

import com.python.clinic.entity.user.ConsultationRoom;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 诊室表 Mapper 接口
 * </p>
 *
 * @author hm
 * @since 2020-06-03
 */
public interface ConsultationRoomMapper extends BaseMapper<ConsultationRoom> {

}
