package com.python.clinic.service.stock;

import com.python.clinic.entity.stock.PurchaseGoods;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 采购药品/物资表 服务类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-21
 */
public interface PurchaseGoodsService extends IService<PurchaseGoods> {

}
