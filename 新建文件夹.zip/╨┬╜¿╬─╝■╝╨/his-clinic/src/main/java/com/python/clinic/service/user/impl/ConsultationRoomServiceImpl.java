package com.python.clinic.service.user.impl;

import com.python.clinic.entity.user.ConsultationRoom;
import com.python.clinic.dao.user.ConsultationRoomMapper;
import com.python.clinic.service.user.ConsultationRoomService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 诊室表 服务实现类
 * </p>
 *
 * @author hm
 * @since 2020-06-03
 */
@Service
public class ConsultationRoomServiceImpl extends ServiceImpl<ConsultationRoomMapper, ConsultationRoom> implements ConsultationRoomService {

}
