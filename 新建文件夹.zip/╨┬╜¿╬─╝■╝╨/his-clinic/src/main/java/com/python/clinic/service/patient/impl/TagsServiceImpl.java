package com.python.clinic.service.patient.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.python.clinic.dao.patient.PatientTagMapper;
import com.python.clinic.entity.patient.Tags;
import com.python.clinic.dao.patient.TagsMapper;
import com.python.clinic.service.patient.TagsService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.python.common.response.CommonResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 标签表 服务实现类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-21
 */
@Service
public class TagsServiceImpl extends ServiceImpl<TagsMapper, Tags> implements TagsService {
    @Autowired
    private PatientTagMapper patientTagMapper;

    @Autowired
    private TagsMapper tagsMapper;

    @Override
    public CommonResult selectTagListByTagType(Integer tagType) {
        Tags tag = new Tags();
        tag.setTagType(tagType);
        QueryWrapper<Tags> wrapper = new QueryWrapper<>(tag);
        Map<String, List> map = new HashMap<>();
        return CommonResult.success(map.put("tagList",tagsMapper.selectList(wrapper)),"查询成功");
    }

    @Transactional
    @Override
    public boolean deleteTagAndPatientTag(Integer tagId) throws Exception {
        Map<String,Object> map = new HashMap<>();
        map.put("tag_id",tagId);
        int flag = patientTagMapper.deleteByMap(map);
        flag+= tagsMapper.deleteById(tagId);
        if(flag == 0){
            throw new Exception("删除用户标签失败");
        }
        return true;
    }

    @Override
    public CommonResult insertTag(Tags tag) throws Exception{
        if( 1== tagsMapper.insert(tag)){
            return CommonResult.success(null,"新增标签成功");
        }
        throw new Exception("新增标签失败");
    }

    @Override
    public CommonResult updateTag(Tags tag) throws Exception{
        if(1 == tagsMapper.updateById(tag)){
            return CommonResult.success(null,"更新标签成功");
        }
        return CommonResult.failed("更新标签失败");
    }
}
