package com.python.clinic.service.marketing;

import com.python.clinic.entity.marketing.MemberSet;
import com.baomidou.mybatisplus.extension.service.IService;
import com.python.common.response.CommonResult;

/**
 * <p>
 * 会员卡设置表 服务类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-20
 */
public interface MemberSetService extends IService<MemberSet> {

    /**
     * 获取用户最近一次积分设置
     * @author tanglong
     * @return com.python.clinic.entity.patient.MemberSet
     * @since 2020/6/2 14:23
     **/
    MemberSet getRecentRuleSet();

    /**
     * 修改会员卡设置
     * @author tanglong
     * @return com.python.common.response.CommonResult
     * @since 2020/6/2 14:55
     **/
    CommonResult updateMemberSet(MemberSet memberSet);

    /**
     * 传入新增会员卡对象，完成新增会员卡设置
     * @author tanglong
     * @return com.python.common.response.CommonResult
     * @since 2020/6/2 15:15
     **/
    CommonResult insertMemberSet(MemberSet memberSet);
}
