package com.python.clinic.service.stock.impl;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.python.clinic.dao.stock.StockLogDetailsMapper;
import com.python.clinic.dao.stock.StockLogMapper;
import com.python.clinic.dao.stock.WarehousingBatchMapper;
import com.python.clinic.dao.sys.ClinicMapper;
import com.python.clinic.dao.user.UserMapper;
import com.python.clinic.entity.stock.StockLog;
import com.python.clinic.entity.stock.Warehousing;
import com.python.clinic.dao.stock.WarehousingMapper;
import com.python.clinic.entity.stock.WarehousingBatch;
import com.python.clinic.entity.stock.dto.WarehousingDTO;
import com.python.clinic.service.stock.WarehousingService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.python.clinic.utils.CodeUtil;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

/**
 * <p>
 * 入库表 服务实现类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-22
 */
@Service
public class WarehousingServiceImpl extends ServiceImpl<WarehousingMapper, Warehousing> implements WarehousingService {

    @Resource
    private WarehousingMapper warehousingMapper;
    @Resource
    private WarehousingBatchMapper batchMapper;
    @Resource
    private StockLogMapper stockLogMapper;
    @Resource
    private StockLogDetailsMapper stockLogDetailsMapper;
    @Resource
    private UserMapper userMapper;
    @Resource
    private ClinicMapper clinicMapper;


    @Override
    @Transactional(propagation= Propagation.REQUIRED,isolation= Isolation.DEFAULT,rollbackFor= RuntimeException.class)
    public boolean saveWarehousing(WarehousingDTO warehousingDTO) {
        //新增入库单
        Warehousing warehousing = warehousingDTO.getWarehousing();
        //设置入库单状态，1为已入库
        warehousing.setStatus(1);
        warehousingMapper.insert(warehousing);
        //新增入库批次
        for (WarehousingBatch batch : warehousingDTO.getBatchList()) {
            //生成批次编号
            batch.setBatch(CodeUtil.getOtherCode());
            batch.setWarehousingId(warehousingDTO.getWarehousing().getId());
            batchMapper.insert(batch);
        }
        //添加操作日志
        StockLog stockLog = warehousingDTO.getStockLog();
        stockLog.setAction("创建入库单");
        stockLog.setRelationId(warehousingDTO.getWarehousing().getId());
        //设置关联类型,2为入库
        stockLog.setRelationType(2);
        stockLogMapper.insert(stockLog);
        return true;
    }

    @Override
    @Transactional(propagation= Propagation.REQUIRED,isolation= Isolation.DEFAULT,rollbackFor= RuntimeException.class)
    public boolean updateWarehousing(WarehousingDTO warehousingDTO) {
        warehousingMapper.updateById(warehousingDTO.getWarehousing());
        //添加药品修改操作日志
        StockLog stockLog = warehousingDTO.getStockLog();
        stockLog.setRelationId(warehousingDTO.getWarehousing().getId());
        //设置关联类型,2为入库
        stockLog.setRelationType(2);
        stockLogMapper.insert(stockLog);
        //添加修改详情
        stockLogDetailsMapper.saveBatch(warehousingDTO.getStockLogDetailsList(),stockLog.getId());

        return true;
    }

    @Override
    public IPage<Warehousing> selectPage(IPage<Warehousing> page, String startTime, String endTime, Integer supplierId, Integer goodsId) {
        IPage<Warehousing> warehousingIPage = warehousingMapper.selectPage(page, startTime, endTime, supplierId, goodsId);
        for (Warehousing record : warehousingIPage.getRecords()) {
            //查询创建者信息
            QueryWrapper userWrapper = new QueryWrapper();
            userWrapper.select("id","user_name");
            userWrapper.eq("id",record.getCreateId());
            record.setCreator(userMapper.selectOne(userWrapper));
            //查询诊所信息
            QueryWrapper clinicWrapper = new QueryWrapper();
            clinicWrapper.select("id","clinic_name");
            clinicWrapper.eq("id",record.getClinicId());
            record.setClinic(clinicMapper.selectOne(clinicWrapper));
        }
        return warehousingIPage;
    }

}
