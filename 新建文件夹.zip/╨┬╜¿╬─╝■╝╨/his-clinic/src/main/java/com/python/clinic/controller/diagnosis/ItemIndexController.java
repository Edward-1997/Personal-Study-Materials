package com.python.clinic.controller.diagnosis;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 检查项目指标 前端控制器
 * </p>
 *
 * @author hm
 * @since 2020-06-06
 */
@RestController
@RequestMapping("/item-index")
public class ItemIndexController {

}
