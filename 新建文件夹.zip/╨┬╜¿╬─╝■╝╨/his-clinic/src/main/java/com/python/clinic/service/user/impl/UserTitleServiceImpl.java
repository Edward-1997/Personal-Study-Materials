package com.python.clinic.service.user.impl;

import com.python.clinic.entity.user.UserTitle;
import com.python.clinic.dao.user.UserTitleMapper;
import com.python.clinic.service.user.UserTitleService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 用户职称表 服务实现类
 * </p>
 *
 * @author hm
 * @since 2020-06-02
 */
@Service
public class UserTitleServiceImpl extends ServiceImpl<UserTitleMapper, UserTitle> implements UserTitleService {

}
