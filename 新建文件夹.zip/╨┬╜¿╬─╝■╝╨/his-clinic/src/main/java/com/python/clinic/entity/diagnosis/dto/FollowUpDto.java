package com.python.clinic.entity.diagnosis.dto;

import com.baomidou.mybatisplus.annotation.TableField;
import com.python.clinic.entity.diagnosis.FollowUp;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/5/28 10:29
 **/
@Data
public class FollowUpDto extends FollowUp{
    @ApiModelProperty(value = "传入患者组id数组")
    @TableField(exist = false)
    private Integer[] ids;

    @ApiModelProperty(value = "传入时间字符串数组，格式:yyyy-MM-dd")
    @TableField(exist = false)
    private String[] dateTime;
}
