package com.python.clinic.service.marketing.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.python.clinic.entity.marketing.ExceptionGoods;
import com.python.clinic.dao.marketing.ExceptionGoodsMapper;
import com.python.clinic.entity.stock.Goods;
import com.python.clinic.service.marketing.ExceptionGoodsService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.python.clinic.service.stock.GoodsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * <p>
 * 优惠券例外商品 服务实现类
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-05
 */
@Service
public class ExceptionGoodsServiceImpl extends ServiceImpl<ExceptionGoodsMapper, ExceptionGoods> implements ExceptionGoodsService {

    @Autowired
    private ExceptionGoodsMapper exceptionGoodsMapper;
    @Autowired
    private GoodsService goodsService;

    @Override
    public List<Goods> getExceptionGoodsList(Integer useScopeId) {
        ExceptionGoods exceptionGoods = new ExceptionGoods();
        exceptionGoods.setUseScopeId(useScopeId);

        List<ExceptionGoods> exceptionGoodsList = exceptionGoodsMapper.selectList(new QueryWrapper<>(exceptionGoods));

        return exceptionGoodsList.stream().map(exception->goodsService.getById(exception.getGoodsId())
        ).collect(Collectors.toList());

    }
}
