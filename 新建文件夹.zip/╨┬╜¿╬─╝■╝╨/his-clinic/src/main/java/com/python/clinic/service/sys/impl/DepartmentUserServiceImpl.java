package com.python.clinic.service.sys.impl;

import com.python.clinic.entity.sys.DepartmentUser;
import com.python.clinic.dao.sys.DepartmentUserMapper;
import com.python.clinic.service.sys.DepartmentUserService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 科室成员表 服务实现类
 * </p>
 *
 * @author hm
 * @since 2020-06-02
 */
@Service
public class DepartmentUserServiceImpl extends ServiceImpl<DepartmentUserMapper, DepartmentUser> implements DepartmentUserService {

}
