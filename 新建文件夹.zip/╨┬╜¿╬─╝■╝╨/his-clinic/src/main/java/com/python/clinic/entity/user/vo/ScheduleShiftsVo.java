package com.python.clinic.entity.user.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.python.clinic.entity.enums.WeekEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/**
 * @author hm
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ScheduleShiftsVo {

    private WeekEnum week;

    @JsonFormat(pattern = "MM-dd",timezone = "GMT+8")
    private LocalDate workingDate;

    private List<Map<String,Object>> scheduleShifts;

    public ScheduleShiftsVo(WeekEnum week, LocalDate workingDate) {
        this.week = week;
        this.workingDate = workingDate;
    }
}
