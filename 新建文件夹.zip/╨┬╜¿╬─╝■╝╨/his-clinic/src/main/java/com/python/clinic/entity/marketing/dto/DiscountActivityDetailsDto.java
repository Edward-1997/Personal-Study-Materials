package com.python.clinic.entity.marketing.dto;

import com.python.clinic.entity.marketing.DiscountActivities;
import com.python.clinic.entity.marketing.DiscountMember;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/6/10 14:46
 **/
@Data
public class DiscountActivityDetailsDto {

    @ApiModelProperty(value = "折扣活动基本详情")
    private DiscountActivities discountActivities;

    @ApiModelProperty(value = "折扣设置详情，包括折扣设置和单品设置")
    private List<DiscountSettingDto> goodsList;

    @ApiModelProperty(value = "设置折扣会员指定范围")
    private List<DiscountMember> discountMemberList;
}
