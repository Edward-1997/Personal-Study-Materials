package com.python.clinic.dao.sys;

import com.python.clinic.entity.sys.DepartmentUser;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.python.clinic.entity.user.User;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 科室成员表 Mapper 接口
 * </p>
 *
 * @author hm
 * @since 2020-06-02
 */
public interface DepartmentUserMapper extends BaseMapper<DepartmentUser> {

    /**
     * 批量插入科室成员
     * @param list
     * @param departmentId
     * @return
     */
    int saveBatch(@Param("list") List<User> list, @Param("departmentId")Integer departmentId);

    /**
     * 获取科室成员列表
     * @param departmentId
     * @return
     */
    List<User> listDepartmentMembers(Integer departmentId);

}
