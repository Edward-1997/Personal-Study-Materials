package com.python.clinic.entity.diagnosis;

import java.math.BigDecimal;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import java.util.List;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

/**
 * <p>
 * 治疗项目表
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-26
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_treatment_item")
@ApiModel(value="TreatmentItem对象", description="治疗项目表")
public class TreatmentItem extends Model<TreatmentItem> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "类型  3:检查检验；4：治疗理疗；5：套餐；6：其他费用，类型为3时，关联指标项目表；为5时，关联套餐项目表")
    private Integer type;

    @ApiModelProperty(value = "子类型 0:检查，1：检验，2：治疗，3：理疗")
    private Integer subType;

    @ApiModelProperty(value = "项目名")
    @NotEmpty(message = "项目名不能为空")
    private String itemName;

    @ApiModelProperty(value = "医保编码")
    private String insuranceCode;

    @ApiModelProperty(value = "单位")
    private String unit;

    @ApiModelProperty(value = "成本")
    private BigDecimal costPrice;

    @ApiModelProperty(value = "销售价")
    @NotNull(message = "销售价不能为空")
    private BigDecimal salesPrice;

    @ApiModelProperty(value = "是否执行划扣 0；需要  1：不需要")
    private Integer deduction;

    @ApiModelProperty(value = "状态，0：停用，1：启用，2：删除")
    private Integer status;

    @ApiModelProperty(value = "诊所id")
    private Integer clinicId;

    @TableField(exist = false)
    private List<ItemIndex> itemIndexList;

    @TableField(exist = false)
    @ApiModelProperty(value = "指标项数量")
    private Integer indexCount;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
