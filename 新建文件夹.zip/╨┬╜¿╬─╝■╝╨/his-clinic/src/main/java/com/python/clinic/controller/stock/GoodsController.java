package com.python.clinic.controller.stock;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.python.clinic.entity.stock.Goods;
import com.python.clinic.entity.stock.dto.GoodsDTO;
import com.python.clinic.entity.stock.dto.GoodsSelectDTO;
import com.python.clinic.entity.stock.vo.GoodsVo;
import com.python.clinic.service.stock.GoodsService;
import com.python.common.response.CommonResult;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 * 药品/物资表 前端控制器
 * </p>
 *
 * @author hm
 * @since 2020-05-19
 */
@RestController
@RequestMapping("/goods")
@Api(tags = "药品/物资管理")
public class GoodsController {

    Logger logger = LoggerFactory.getLogger(GoodsController.class);

    @Autowired
    private GoodsService goodsService;

    @PostMapping("/saveGoods")
    @ApiOperation(value = "添加药品/物资",notes = "传入goods对象实现添加操作")
    public CommonResult saveGoods(@RequestBody GoodsDTO goodsDto){
        goodsService.saveGoods(goodsDto);
        return CommonResult.success(null,"添加成功");
    }

    @PutMapping("/updateGoods")
    @ApiOperation(value = "修改药品/物资信息",notes = "传入goods对象实现修改操作")
    public CommonResult updateGoods(@RequestBody GoodsDTO goodsDto){
        goodsService.updateGoods(goodsDto);
        return CommonResult.success(null,"修改成功");
    }

    @GetMapping("/getGoods")
    @ApiOperation(value = "药品/物资详情查看",notes = "根据传入的id查询对应药品/物资信息")
    public CommonResult getGoods(Integer id){
        return CommonResult.success(goodsService.getGoods(id));
    }

    @DeleteMapping("/deleteGoods")
    @ApiOperation(value = "删除药品/物资信息",notes = "逻辑删除，通过传入id进行删除")
    public CommonResult deleteGoods(@RequestParam(required = true) Integer id){
        QueryWrapper<Goods> wrapper = new QueryWrapper();
        wrapper.eq("id",id);
        Goods goods = new Goods();
        //逻辑删除，将商品状态修改为0
        goods.setStatus(0);
        return CommonResult.result(goodsService.update(goods,wrapper));
    }

    @GetMapping("/listGoods")
    @ApiOperation(value = "获取药品列表",notes = "分页查询，默认一页10条记录，可以通过传入参数改变。pageSize:数量，pageNo:起始位置")
    public CommonResult listGoods(@RequestParam(defaultValue = "1") Integer pageNum,
                                  @RequestParam(defaultValue = "10") Integer pageSize,
                                  GoodsSelectDTO goodsSelectDTO){
        IPage<GoodsVo> page = new Page<>(pageNum,pageSize);
        return CommonResult.success(goodsService.listGoods(page,goodsSelectDTO));
    }

    @GetMapping("/getHistoricalPrice")
    @ApiOperation("获取商品历史进价")
    public CommonResult getHistoricalPrice(@RequestParam(required = true)Integer goodsId){
        return CommonResult.success(goodsService.getHistoricalPrice(goodsId));
    }

}
