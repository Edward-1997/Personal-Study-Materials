package com.python.clinic.entity.stock.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author hm
 */
@Data
public class GoodsSelectDTO {

    @ApiModelProperty(value = "商品id")
    private Integer goodsId;

    @ApiModelProperty(value = "类型，6：中药，7：西药，8：中成药")
    private Integer type;

    @ApiModelProperty(value = "附属类型 0:中药饮片，1:中药颗粒")
    private Integer subType;

    @ApiModelProperty(value = "诊所id")
    private Integer clinicId;

    @ApiModelProperty(value = "排序字段，sell_price:售价,lately_price:最近进价,lately_expiry_date:最近效期,gross_margin:毛利率," +
            "stock_sum:当前库存,daily_sales:日销量,turnover_days:周转天数")
    private String orderBy;

    @ApiModelProperty(value = "排序方式，asc:顺序,desc:逆序")
    private String orderType;

    @ApiModelProperty(value = "开始页数")
    private Integer pageNo;

    @ApiModelProperty(value = "每页展示条数")
    private Integer pageSize;

}
