package com.python.clinic.service.marketing.impl;

import com.python.clinic.entity.marketing.CouponMember;
import com.python.clinic.dao.marketing.CouponMemberMapper;
import com.python.clinic.service.marketing.CouponMemberService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 优惠券会员表 服务实现类
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-06
 */
@Service
public class CouponMemberServiceImpl extends ServiceImpl<CouponMemberMapper, CouponMember> implements CouponMemberService {

}
