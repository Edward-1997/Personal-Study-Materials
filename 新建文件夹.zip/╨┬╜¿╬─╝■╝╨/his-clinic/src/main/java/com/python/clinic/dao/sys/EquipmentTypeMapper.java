package com.python.clinic.dao.sys;

import com.python.clinic.entity.sys.EquipmentType;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 设备类别表 Mapper 接口
 * </p>
 *
 * @author hm
 * @since 2020-06-02
 */
public interface EquipmentTypeMapper extends BaseMapper<EquipmentType> {

}
