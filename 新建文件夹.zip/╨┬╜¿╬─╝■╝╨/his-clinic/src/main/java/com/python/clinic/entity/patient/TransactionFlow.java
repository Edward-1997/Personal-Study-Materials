package com.python.clinic.entity.patient;

import java.math.BigDecimal;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 交易流水表
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-20
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_transaction_flow")
@ApiModel(value="TransactionFlow对象", description="交易流水表")
public class TransactionFlow extends Model<TransactionFlow> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键")
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "患者会员卡id")
    private Integer patientCardId;

    @ApiModelProperty(value = "交易时间")
    private Date transactionTime;

    @ApiModelProperty(value = "交易类型,共四种，0、消费 1、充值 2、退款 3、退储蓄金")
    private Integer type;

    @ApiModelProperty(value = "客户")
    private Integer customer;

    @ApiModelProperty(value = "支付方式")
    private String payMethod;

    @ApiModelProperty(value = "交易本金")
    private BigDecimal payPrincipal;

    @ApiModelProperty(value = "交易赠金")
    private BigDecimal payGiftAmout;

    @ApiModelProperty(value = "剩余本金")
    private BigDecimal surplusPrincipal;

    @ApiModelProperty(value = "剩余赠金")
    private BigDecimal surplusGiftAmout;

    @ApiModelProperty(value = "销售人 0: 销售不指定，其他为销售员编号")
    private Integer seller;

    @ApiModelProperty(value = "收费人（创建人）")
    private Integer createId;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
