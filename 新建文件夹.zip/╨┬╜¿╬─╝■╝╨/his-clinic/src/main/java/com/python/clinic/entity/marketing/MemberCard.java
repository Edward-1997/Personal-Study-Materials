package com.python.clinic.entity.marketing;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 会员卡
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-20
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_member_card")
@ApiModel(value="MemberCard对象", description="会员卡")
public class MemberCard extends Model<MemberCard> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "会员卡主键")
    @TableId(value = "id")
    private Integer id;

    @ApiModelProperty(value = "会员卡名称")
    private String cardName;

    @ApiModelProperty(value = "获取条件，积分达到某个值")
    private Integer acquisitionConditions;

    @ApiModelProperty(value = "自定义权益")
    private String benefits;

    @ApiModelProperty(value = "诊所id")
    private Integer clinicId;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
