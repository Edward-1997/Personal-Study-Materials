package com.python.clinic.dao.sys;

import com.python.clinic.entity.sys.Appointment;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 预约设置 Mapper 接口
 * </p>
 *
 * @author hm
 * @since 2020-06-03
 */
public interface AppointmentMapper extends BaseMapper<Appointment> {

}
