package com.python.clinic.dao.marketing;

import com.python.clinic.entity.marketing.CouponMember;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 优惠券会员表 Mapper 接口
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-06
 */
public interface CouponMemberMapper extends BaseMapper<CouponMember> {

}
