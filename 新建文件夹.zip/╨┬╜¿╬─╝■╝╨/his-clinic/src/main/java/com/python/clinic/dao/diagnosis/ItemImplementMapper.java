package com.python.clinic.dao.diagnosis;

import com.python.clinic.entity.diagnosis.ItemImplement;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 治疗项目执行记录表 Mapper 接口
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-28
 */
public interface ItemImplementMapper extends BaseMapper<ItemImplement> {

}
