package com.python.clinic.dao.stock;

import com.python.clinic.entity.stock.OutOfStockBatch;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 科室出库详情批次 Mapper 接口
 * </p>
 *
 * @author hm
 * @since 2020-05-23
 */
public interface OutOfStockBatchMapper extends BaseMapper<OutOfStockBatch> {

    /**
     * 根据出库详情查询出库批次
     * @param stockDetailsId 出库详情id
     * @param specifyBatch   是否指定批次
     * @return
     */
    List<Map<String,Object>> listStockBatch(@Param("stockDetailsId")Integer stockDetailsId,@Param("specifyBatch")Boolean specifyBatch);

}
