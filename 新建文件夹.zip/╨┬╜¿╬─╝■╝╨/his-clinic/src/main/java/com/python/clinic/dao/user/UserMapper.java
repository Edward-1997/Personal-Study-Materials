package com.python.clinic.dao.user;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.python.clinic.entity.user.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.python.clinic.entity.user.vo.SchedulingVo;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 诊所用户表 Mapper 接口
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-21
 */
public interface UserMapper extends BaseMapper<User> {

    /**
     * 获取用户id和名称
     * @param id
     * @return
     */
    User getIdAndName(@Param("id")Integer id);

    /**
     * 查询用户列表以及排班信息
     * @param role 角色 医生:doctor，员工:staff
     * @param departmentId 科室id，为null表示全部科室，为0表示其他
     * @param page
     * @return
     */
    IPage<SchedulingVo> listUserByRoleAndDepartmentId(IPage<User> page, @Param("role")String role, @Param("departmentId")Integer departmentId);

}
