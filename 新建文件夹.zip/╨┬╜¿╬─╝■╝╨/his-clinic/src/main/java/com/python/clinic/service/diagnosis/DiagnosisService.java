package com.python.clinic.service.diagnosis;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.python.clinic.entity.diagnosis.Diagnosis;
import com.baomidou.mybatisplus.extension.service.IService;
import com.python.clinic.entity.diagnosis.dto.DiagnosisDetailsDto;
import com.python.clinic.entity.diagnosis.vo.DiagnosisRecordsVo;
import com.python.common.response.CommonResult;

/**
 * <p>
 * 门诊表 服务类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-22
 */
public interface DiagnosisService extends IService<Diagnosis> {
    /**
     * 根据患者id查找门诊记录，并根据诊断时间降序排序
     * @author tanglong
     * @return com.python.common.response.CommonResult
     * @since 2020/5/23 9:31
     **/
    IPage<DiagnosisRecordsVo> selectRecordByPatientId(Integer pageSize, Integer pageNum, Integer patientId);

    /**
     * 根据门诊表id查找详细门诊记录
     * @author tanglong
     * @return com.python.common.response.CommonResult
     * @since 2020/5/26 10:20
     **/
    DiagnosisDetailsDto getDiagnosisDetails(Integer id);
}
