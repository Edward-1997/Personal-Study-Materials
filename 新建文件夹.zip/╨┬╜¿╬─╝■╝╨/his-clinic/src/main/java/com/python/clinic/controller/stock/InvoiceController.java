package com.python.clinic.controller.stock;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 发票表 前端控制器
 * </p>
 *
 * @author hm
 * @since 2020-05-28
 */
@RestController
@RequestMapping("/invoice")
public class InvoiceController {

}
