package com.python.clinic.dao.user;

import com.python.clinic.entity.user.TitleInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 职称信息表 Mapper 接口
 * </p>
 *
 * @author hm
 * @since 2020-06-02
 */
public interface TitleInfoMapper extends BaseMapper<TitleInfo> {

}
