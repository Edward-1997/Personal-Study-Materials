package com.python.clinic.entity.marketing.dto;

import com.python.clinic.entity.marketing.GiftMember;
import com.python.clinic.entity.marketing.GiftRulePromotions;
import com.python.clinic.entity.marketing.UseScope;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/6/6 17:24
 **/
@Data
public class GiftDetailsDto {
    @ApiModelProperty(value = "满减返活动详情")
    private GiftRulePromotions giftRulePromotions;
    @ApiModelProperty(value = "优惠设置列表详情")
    private List<GiftRulesDto> giftRulesList;
    @ApiModelProperty(value = "满减返使用范围")
    private List<UseScope> useScopeList;
    @ApiModelProperty(value = "满减返指定会员卡")
    private List<GiftMember> giftMemberList;
}
