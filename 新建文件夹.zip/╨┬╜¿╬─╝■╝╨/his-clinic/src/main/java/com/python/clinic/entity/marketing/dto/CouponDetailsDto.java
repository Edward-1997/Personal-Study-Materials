package com.python.clinic.entity.marketing.dto;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.python.clinic.entity.marketing.Coupon;
import com.python.clinic.entity.marketing.CouponMember;
import com.python.clinic.entity.marketing.UseScope;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.catalina.LifecycleState;

import java.util.List;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/6/5 14:33
 **/
@Data
public class CouponDetailsDto {
    @ApiModelProperty(value = "优惠券详细信息")
    private Coupon coupon;
    @ApiModelProperty(value = "优惠券使用范围")
    private List<UseScope> useScopeList;
    @ApiModelProperty(value = "优惠券指定会员卡")
    private List<CouponMember> couponMemberList;
}
