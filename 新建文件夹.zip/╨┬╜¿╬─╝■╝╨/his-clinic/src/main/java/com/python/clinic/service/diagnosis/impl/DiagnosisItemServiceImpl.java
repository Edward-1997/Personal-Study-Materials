package com.python.clinic.service.diagnosis.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.python.clinic.dao.diagnosis.TreatmentItemMapper;
import com.python.clinic.entity.diagnosis.DiagnosisItem;
import com.python.clinic.dao.diagnosis.DiagnosisItemMapper;
import com.python.clinic.entity.diagnosis.TreatmentItem;
import com.python.clinic.entity.diagnosis.constant.DiagnosisConstant;
import com.python.clinic.entity.diagnosis.vo.TreatmentItemVo;
import com.python.clinic.service.diagnosis.DiagnosisItemService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * <p>
 * 门诊检查项目表 服务实现类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-26
 */
@Service
public class DiagnosisItemServiceImpl extends ServiceImpl<DiagnosisItemMapper, DiagnosisItem> implements DiagnosisItemService {

    @Autowired
    private TreatmentItemMapper treatmentItemMapper;
    @Autowired
    private DiagnosisItemMapper diagnosisItemMapper;

    @Override
    public List<TreatmentItemVo> getTreatmentList(DiagnosisItem diagnosisItem) {
        List<DiagnosisItem> diagnosisItems = diagnosisItemMapper.selectList(new QueryWrapper<>(diagnosisItem));
        List<TreatmentItemVo> list = null;
        if(diagnosisItems != null){//诊疗项目不为空
            list = diagnosisItems.stream().map(item -> {
                TreatmentItemVo vo = new TreatmentItemVo();
                vo.setId(item.getId());
                vo.setNum(item.getNum());
                vo.setPrice(item.getTotalPrice());
                vo.setStatus(item.getStatus());
                if (item.getRelationType().equals(DiagnosisConstant.TREATMENT_ITEM_TYPE)) {
                    //该治疗项目是诊疗项目
                    TreatmentItem treatmentItem = treatmentItemMapper.selectById(item.getRelationId());
                    vo.setItemName(treatmentItem.getItemName());
                    vo.setType(treatmentItem.getType());
                    vo.setUnit(DiagnosisConstant.TREATMENT_ITEM_UNIT);
                } else {
                    //该项目是材料商品
                    vo.setType(DiagnosisConstant.ItemType.MATERIAL_GOODS);//设置类型为材料商品
                    //以下需要从物资表中查询，暂时不做
//                vo.setUnit();
//                vo.setItemName();
                }
                return vo;
            }).collect(Collectors.toList());
        }
        return list;
    }
}
