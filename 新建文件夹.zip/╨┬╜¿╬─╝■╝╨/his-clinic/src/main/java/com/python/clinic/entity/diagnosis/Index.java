package com.python.clinic.entity.diagnosis;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import javax.validation.constraints.NotEmpty;

/**
 * <p>
 * 指标项表
 * </p>
 *
 * @author hm
 * @since 2020-06-06
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_index")
@ApiModel(value="Index对象", description="指标项表")
public class Index extends Model<Index> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "指标名称")
    @NotEmpty(message = "指标名称不能为空")
    private String indexName;

    @ApiModelProperty(value = "指标代码")
    private String indexCode;

    @ApiModelProperty(value = "定量定性  0：定量  1：定性")
    private Integer quantitative;

    @ApiModelProperty(value = "单位")
    private String unit;

    @ApiModelProperty(value = "最小值")
    private BigDecimal minValue;

    @ApiModelProperty(value = "最大值")
    private BigDecimal maxValue;

    @ApiModelProperty(value = "诊所id")
    private Integer clinicId;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
