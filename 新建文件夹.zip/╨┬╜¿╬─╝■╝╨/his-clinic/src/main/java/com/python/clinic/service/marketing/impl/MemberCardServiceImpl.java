package com.python.clinic.service.marketing.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.python.clinic.dao.marketing.*;
import com.python.clinic.entity.marketing.*;
import com.python.clinic.entity.marketing.constant.MarketingConstant;
import com.python.clinic.entity.marketing.dto.DiscountActivityDetailsDto;
import com.python.clinic.entity.marketing.dto.MemberCardDto;
import com.python.clinic.entity.patient.vo.MemberCardInfoVo;
import com.python.clinic.service.marketing.DiscountActivitiesService;
import com.python.clinic.service.marketing.DiscountMemberService;
import com.python.clinic.service.marketing.DiscountSettingService;
import com.python.clinic.service.marketing.MemberCardService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.python.clinic.service.patient.PatientMemberCardService;
import com.python.clinic.utils.CodeUtil;
import com.python.common.response.CommonResult;
import com.sun.org.apache.bcel.internal.classfile.Code;
import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * <p>
 * 会员卡 服务实现类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-20
 */
@Service
public class MemberCardServiceImpl extends ServiceImpl<MemberCardMapper, MemberCard> implements MemberCardService {
    @Autowired
    private MemberCardMapper memberCardMapper;
    @Autowired
    private DiscountMemberService discountMemberService;
    @Autowired
    private DiscountSettingMapper discountSettingMapper;
    @Autowired
    private DiscountActivitiesService discountActivitiesService;
    @Autowired
    private DiscountStoreMapper discountStoreMapper;
    @Autowired
    private SqlSessionFactory sqlSessionFactory;
    @Autowired
    private PatientMemberCardService patientMemberCardService;
    @Override
    public CommonResult selectMemberCardList(Integer pageSize, Integer pageNum) {
        Map<String,Object> map = new HashMap<>();
        //查询会员卡列表不分页
        if(pageSize == -1 && pageNum == -1){
            List<MemberCard> list = memberCardMapper.selectList(new QueryWrapper<>(new MemberCard()));

            map.put("memberCardList",list);
            return CommonResult.success(map);
        }
        //执行分页查询会员卡列表
        IPage<MemberCard> page = new Page<>(pageNum,pageSize);
        page = memberCardMapper.selectPage(page, new QueryWrapper<>(new MemberCard()));
        //根据会员卡查询折扣权益
        page.convert(memberCard -> {
            MemberCardDto memberCardDto = new MemberCardDto();
            memberCardDto.setMemberCard(memberCard);
            getDiscountInfo(memberCardDto,memberCard.getId());
            //获取拥有该会员卡的会员数
            memberCardDto.setMemberNum(patientMemberCardService.getStatisticsMember(memberCard.getId()));
            return memberCardDto;
        });

        map.put("memberCardTypePage",page);
        return CommonResult.success(map);
    }

    @Override
    public MemberCardDto selectMemberCardInfo(Integer cardId) {
        //查询会员卡基本信息
        MemberCardDto memberCardDto = new MemberCardDto();
        memberCardDto.setMemberCard(memberCardMapper.selectById(cardId));
        //获取会员卡具体折扣信息
        getDiscountInfo(memberCardDto,cardId);
        return memberCardDto;
    }

    @Transactional
    @Override
    public CommonResult insertMemberCard(MemberCardDto memberCardDto) {
        int index = 0;
        //新增会员卡
        MemberCard memberCard = memberCardDto.getMemberCard();
        Integer cardId = CodeUtil.getPrimaryKey();
        memberCard.setId( cardId );
        index += memberCardMapper.insert(memberCard);
        //新增折扣活动
        Integer discountId = CodeUtil.getPrimaryKey();
        DiscountActivities discountActivities = new DiscountActivities();
        discountActivities.setId(discountId);
        discountActivities.setActivityName(MarketingConstant.DiscountActivities.DISCOUNT_LIST);
        discountActivities.setTimeLimit(0);//设定活动时限为永久
        if(!discountActivitiesService.save(discountActivities)){
            throw new RuntimeException();
        }
        //新增折扣会员
        DiscountMember discountMember = new DiscountMember();
        discountMember.setDiscountId(discountId);
        discountMember.setMemberCardId(cardId);
        discountMember.setMemberDiscount(1);//指定为会员卡折扣
        if(!discountMemberService.save(discountMember)){
            throw new RuntimeException();
        }

        //新增折扣列表
        try(SqlSession sqlSession = sqlSessionFactory.openSession(ExecutorType.BATCH);){
            DiscountSettingMapper mapper = sqlSession.getMapper(DiscountSettingMapper.class);
            List<DiscountSetting> discountList = memberCardDto.getDiscountSettingList();
            for(DiscountSetting discountSetting:discountList){
                discountSetting.setDiscountId(discountId);
                mapper.insert(discountSetting);
                index++;
            }
            sqlSession.commit();
            //新增该门诊下折扣活动
            DiscountStore discountStore = new DiscountStore();
            discountStore.setDiscountId(discountId);
            discountStore.setStoreId(memberCard.getClinicId());
            index += discountStoreMapper.insert(discountStore);
            if(index !=(2+discountList.size())){
                throw new RuntimeException("新增会员卡失败");
            }
        }

        return CommonResult.success(null,"新增会员卡成功");
    }

    @Transactional
    @Override
    public CommonResult deleteMemberCard(Integer cardId, Integer discountId) {
        Integer count = patientMemberCardService.getStatisticsMember(cardId);
        if(count !=0){
            return CommonResult.failed("该会员卡下还有患者不能删除");
        }

        int index = 0;
        //删除会员折扣关系表中的数据
        DiscountMember discountMember = new DiscountMember();
        discountMember.setDiscountId(discountId);
        discountMember.setMemberCardId(cardId);
        if(!discountMemberService.remove(new QueryWrapper<>(discountMember))){
            throw new RuntimeException();
        }
        //删除该会员卡的折扣设置列表,折扣有10条
        DiscountSetting discountSetting = new DiscountSetting();
        discountSetting.setDiscountId(discountId);
        index += discountSettingMapper.delete(new QueryWrapper<>(discountSetting));
        //删除该会员卡折扣活动
        if(!discountActivitiesService.removeById(discountId)){
            throw new RuntimeException();
        }
        //删除门诊折扣店下该折扣
        DiscountStore discountStore = new DiscountStore();
        discountStore.setDiscountId(discountId);
        index += discountStoreMapper.delete(new QueryWrapper<>(discountStore));
        //删除该会员卡相关信息
        index += memberCardMapper.deleteById(cardId);

        if(index != 13){
            throw new RuntimeException();
        }
        return CommonResult.success(null,"删除会员卡成功");
    }

    @Transactional
    @Override
    public CommonResult updateMemberCard(MemberCardDto memberCardDto) {
        int index = 0;
        MemberCard memberCard = memberCardDto.getMemberCard();
        index += memberCardMapper.updateById(memberCard);
        try(SqlSession sqlSession = sqlSessionFactory.openSession(ExecutorType.BATCH);){
            DiscountSettingMapper mapper = sqlSession.getMapper(DiscountSettingMapper.class);
            for(DiscountSetting discountSetting:memberCardDto.getDiscountSettingList()){
                //完成10次修改
                mapper.updateById(discountSetting);
                index++;
            }
            sqlSession.commit();
        }

        if(index != 11){
            throw new RuntimeException();
        }

        return CommonResult.success(null,"修改会员卡成功");
    }


    //获取会员卡的具体折扣信息，并将其封装到MemberCardDto对象中
    private void getDiscountInfo(MemberCardDto memberCardDto,Integer cardId){
        //查询会员卡折扣id
        DiscountMember discountMember = new DiscountMember();
        discountMember.setMemberCardId(cardId);
        discountMember = discountMemberService.getOne(new QueryWrapper<>(discountMember));
        //根据id查询会员卡折扣列表
        DiscountSetting discountSetting = new DiscountSetting();
        discountSetting.setDiscountId(discountMember.getDiscountId());
        List<DiscountSetting> discountList = discountSettingMapper.selectList(new QueryWrapper<>(discountSetting));
        memberCardDto.setDiscountSettingList(discountList);
        //获取折扣权益字符串
        memberCardDto.setDiscountBenefits(getBenefits(discountList));
    }

    //将折扣列表中的信息转换为折扣权益字符串
    private String getBenefits(List<DiscountSetting> discountList){
        StringBuilder stringBuilder = new StringBuilder();
        for(DiscountSetting setting : discountList){
            if(setting.getType().equals(MarketingConstant.DiscountType.REGISTER)){
                stringBuilder.append("挂号");
            }else if(setting.getType().equals(MarketingConstant.DiscountType.WESTERN_MEDICINE)){
                stringBuilder.append("西药");
            }else if(setting.getType().equals(MarketingConstant.DiscountType.TRADITIONAL_CHINESE_MEDICINE)){
                stringBuilder.append("中药");
            }else if(setting.getType().equals(MarketingConstant.DiscountType.EXAMINATION)){
                stringBuilder.append("检验");
            }else if(setting.getType().equals(MarketingConstant.DiscountType.CHECKOUT)){
                stringBuilder.append("检查");
            }else if(setting.getType().equals(MarketingConstant.DiscountType.TREATMENT)){
                stringBuilder.append("治疗");
            }else if(setting.getType().equals(MarketingConstant.DiscountType.PHYSIOTHERAPY)){
                stringBuilder.append("理疗");
            }else if(setting.getType().equals(MarketingConstant.DiscountType.MATERIAL)){
                stringBuilder.append("材料");
            }else if(setting.getType().equals(MarketingConstant.DiscountType.COMMODITY)){
                stringBuilder.append("商品");
            }else if(setting.getType().equals(MarketingConstant.DiscountType.MEAL)){
                stringBuilder.append("套餐");
            }

            stringBuilder.append(setting.getDiscount()*10);
            stringBuilder.append(MarketingConstant.DiscountType.DISCOUNT_UNIT);
            stringBuilder.append(",");
        }

        return stringBuilder.substring(0,stringBuilder.lastIndexOf(","));
    }
}
