package com.python.clinic.service.sys;

import com.python.clinic.entity.sys.Calling;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 叫号设置 服务类
 * </p>
 *
 * @author hm
 * @since 2020-06-05
 */
public interface CallingService extends IService<Calling> {

    /**
     * 修改叫号设置
     * @param calling
     * @return
     */
    boolean updateCall(Calling calling);

}
