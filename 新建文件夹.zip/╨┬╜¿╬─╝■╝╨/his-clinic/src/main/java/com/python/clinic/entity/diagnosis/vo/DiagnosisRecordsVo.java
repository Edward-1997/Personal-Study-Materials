package com.python.clinic.entity.diagnosis.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/5/23 9:38
 **/
@Data
public class DiagnosisRecordsVo {
    @ApiModelProperty(value = "主键")
    private Integer id;
    @ApiModelProperty(value = "诊断时间")
    private Date diagnosisDate;
    @ApiModelProperty(value = "诊断")
    private String diagnosis;
    @ApiModelProperty(value = "医生")
    private String doctor;
    @ApiModelProperty(value = "门店")
    private String clinic;

}
