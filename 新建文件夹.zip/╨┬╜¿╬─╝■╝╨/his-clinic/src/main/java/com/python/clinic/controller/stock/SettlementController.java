package com.python.clinic.controller.stock;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.python.clinic.entity.stock.Settlement;
import com.python.clinic.service.stock.SettlementService;
import com.python.common.response.CommonResult;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 * 结算申请表 前端控制器
 * </p>
 *
 * @author hm
 * @since 2020-05-28
 */
@RestController
@RequestMapping("/settlement")
public class SettlementController {

    @Autowired
    private SettlementService settlementService;

    @GetMapping("/listSettlement")
    @ApiOperation(value = "查询结算申请列表",notes = "dateType:日期类型，提交:create、审核:audit，status:状态 0:待审核、1:已结算、2:未通过、3:已作废")
    public CommonResult listSettlement(@RequestParam(defaultValue = "1") Integer pageNo,
                                       @RequestParam(defaultValue = "10") Integer pageSize,
                                       String startTime, String endTime, String dateType, Integer status, Integer supplierId){
        IPage<Settlement> page = new Page<>(pageNo,pageSize);
        return CommonResult.success(settlementService.selectPage(page,startTime,endTime,dateType,status,supplierId));
    }

    @GetMapping("/getSettlement")
    @ApiOperation(value = "获取结算申请数据",notes = "id:结算申请id，type:类型(0:结算申请，1:结算审核)")
    public CommonResult getSettlement(@RequestParam(required = true)Integer id,@RequestParam(required = true)Integer type){
        return CommonResult.success(settlementService.getSettlement(id,type));
    }

    @PostMapping("/saveSettlement")
    @ApiOperation("添加结算申请")
    public CommonResult saveSettlement(@RequestBody Settlement settlement){
        return CommonResult.success(settlementService.saveSettlement(settlement));
    }

    @PutMapping("/updateSettlement")
    @ApiOperation("修改结算申请")
    public CommonResult updateSettlement(@RequestBody Settlement settlement){
        return CommonResult.success(settlementService.updateSettlement(settlement));
    }

}
