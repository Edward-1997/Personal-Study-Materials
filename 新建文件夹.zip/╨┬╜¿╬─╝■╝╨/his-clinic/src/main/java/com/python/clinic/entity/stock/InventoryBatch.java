package com.python.clinic.entity.stock;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

/**
 * <p>
 * 盘点批次表
 * </p>
 *
 * @author hm
 * @since 2020-05-27
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_inventory_batch")
@ApiModel(value="InventoryBatch对象", description="盘点批次表")
@NoArgsConstructor
public class InventoryBatch extends Model<InventoryBatch> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "盘点详情id")
    private Integer inventoryDetailsId;

    @ApiModelProperty(value = "入库批次id")
    private Integer batchId;

    @ApiModelProperty(value = "整装账面数量")
    private Integer beforePackageCount;

    @ApiModelProperty(value = "散装账面数量")
    private Integer beforePieceCount;

    @ApiModelProperty(value = "整装实际数量")
    private Integer packageCount;

    @ApiModelProperty(value = "散装实际数量")
    private Integer pieceCount;

    @ApiModelProperty(value = "整装盈亏数量")
    private Integer packageCountChange;

    @ApiModelProperty(value = "散装盈亏数量")
    private Integer pieceCountChange;

    @ApiModelProperty(value = "盈亏金额(进价)")
    private BigDecimal totalCostPriceChange;

    public InventoryBatch(Integer inventoryDetailsId, Integer batchId, Integer beforePackageCount, Integer beforePieceCount, Integer packageCount, Integer pieceCount, Integer packageCountChange, Integer pieceCountChange, BigDecimal totalCostPriceChange) {
        this.inventoryDetailsId = inventoryDetailsId;
        this.batchId = batchId;
        this.beforePackageCount = beforePackageCount;
        this.beforePieceCount = beforePieceCount;
        this.packageCount = packageCount;
        this.pieceCount = pieceCount;
        this.packageCountChange = packageCountChange;
        this.pieceCountChange = pieceCountChange;
        this.totalCostPriceChange = totalCostPriceChange;
    }

    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
