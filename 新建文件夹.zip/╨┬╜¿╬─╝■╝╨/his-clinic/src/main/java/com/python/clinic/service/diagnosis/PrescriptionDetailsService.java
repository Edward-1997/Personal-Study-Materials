package com.python.clinic.service.diagnosis;

import com.python.clinic.entity.diagnosis.PrescriptionDetails;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 处方详情表 服务类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-26
 */
public interface PrescriptionDetailsService extends IService<PrescriptionDetails> {

}
