package com.python.clinic.exception;

import lombok.Data;

@Data
public class BaseException extends Exception {
    private String errorMessage;
    private int errorCode;

    public BaseException(int errorCode, String errorMessage){
        super(errorMessage);
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }

}

