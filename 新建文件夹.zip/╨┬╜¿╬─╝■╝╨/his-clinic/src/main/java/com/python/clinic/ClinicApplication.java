package com.python.clinic;

import com.baomidou.mybatisplus.extension.plugins.PaginationInterceptor;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/5/20 11:28
 **/
@SpringBootApplication
@MapperScan("com.python.clinic.dao")
public class ClinicApplication {
    public static void main(String[] args) {

        SpringApplication.run(ClinicApplication.class);
    }


    /**
     * 分页插件
     */
    @Bean
    public PaginationInterceptor paginationInterceptor() {
        return new PaginationInterceptor();
    }

}

