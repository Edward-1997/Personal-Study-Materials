package com.python.clinic.entity.marketing.dto;

import com.python.clinic.entity.stock.Goods;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/6/8 14:23
 **/
@Data
public class GiftGoodDto {

    @ApiModelProperty(value = "商品id")
    private Integer goodsId;

    @ApiModelProperty(value = "商品")
    private Goods goods;

    @ApiModelProperty(value = "数量")
    private Integer count;
}
