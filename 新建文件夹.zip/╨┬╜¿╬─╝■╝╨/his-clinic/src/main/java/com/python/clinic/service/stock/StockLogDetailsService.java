package com.python.clinic.service.stock;

import com.baomidou.mybatisplus.extension.service.IService;
import com.python.clinic.entity.stock.StockLogDetails;

/**
 * <p>
 * 入库日志详情表 服务类
 * </p>
 *
 * @author hm
 * @since 2020-05-19
 */
public interface StockLogDetailsService extends IService<StockLogDetails> {

}
