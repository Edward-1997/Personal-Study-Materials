package com.python.clinic.entity.user;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 医生助理表
 * </p>
 *
 * @author hm
 * @since 2020-06-02
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_assistant")
@ApiModel(value="Assistant对象", description="医生助理表")
public class Assistant extends Model<Assistant> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "医生信息id")
    private Integer userInfoId;

    @ApiModelProperty(value = "所助理医生的id")
    private Integer userId;


    @Override
    protected Serializable pkVal() {
        return null;
    }

}
