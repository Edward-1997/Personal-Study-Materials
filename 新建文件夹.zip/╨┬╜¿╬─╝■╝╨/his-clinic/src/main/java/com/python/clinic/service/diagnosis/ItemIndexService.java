package com.python.clinic.service.diagnosis;

import com.python.clinic.entity.diagnosis.ItemIndex;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 检查项目指标 服务类
 * </p>
 *
 * @author hm
 * @since 2020-06-06
 */
public interface ItemIndexService extends IService<ItemIndex> {

}
