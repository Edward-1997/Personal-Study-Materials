package com.python.clinic.entity.marketing;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 优惠券表
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-05
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_coupon")
@ApiModel(value="Coupon对象", description="优惠券表")
public class Coupon extends Model<Coupon> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "优惠券名称")
    private String couponName;

    @ApiModelProperty(value = "优惠价格（面值）")
    private BigDecimal preferentialPrice;

    @ApiModelProperty(value = "使用门槛，为零表示无门槛")
    private BigDecimal useThreshold;

    @ApiModelProperty(value = "仅购买原价商品可用，0：false，1：true")
    private Integer onlyOriginalPrice;

    @ApiModelProperty(value = "使用数量，0：不限使用数量，1：单次仅限使用一张")
    private Integer useCount;

    @ApiModelProperty(value = "有效期天数")
    private Integer validDays;

    @ApiModelProperty(value = "有效期开始时间")
    private Date validStartTime;

    @ApiModelProperty(value = "有效期结束时间")
    private Date validEndTime;

    @ApiModelProperty(value = "发行总量")
    private Integer totalCount;

    @ApiModelProperty(value = "剩余s数量")
    private Integer surplusCount;

    @ApiModelProperty(value = "领取范围，-1：所有患者，其他为指定会员卡id")
    private Integer allPatients;

    @ApiModelProperty(value = "领取数量，为-1时表示不限数量")
    private Integer receiveCount;

    @ApiModelProperty(value = "免费领取，0：false，1：true")
    private Integer freeReceive;

    @ApiModelProperty(value = "领取开始时间")
    private Date receiveStartTime;

    @ApiModelProperty(value = "领取结束时间")
    private Date receiveEndTime;

    @ApiModelProperty(value = "状态 0：可发券 1：停止发券 2：已作废")
    private Integer status;

    @ApiModelProperty(value = "备注")
    private String remark;

    @ApiModelProperty(value = "诊所id")
    private Integer clinicId;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
