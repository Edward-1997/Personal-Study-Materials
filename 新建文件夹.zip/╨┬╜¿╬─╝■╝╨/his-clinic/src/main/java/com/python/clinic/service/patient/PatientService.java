package com.python.clinic.service.patient;


import com.baomidou.mybatisplus.extension.service.IService;
import com.python.clinic.entity.patient.Patient;
import com.python.common.response.CommonResult;

/**
 * <p>
 * 患者表 服务类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-20
 */
public interface PatientService extends IService<Patient> {

    /**
     * 通过患者id值查询患者基本信息
     * @author tanglong
     * @param id
     * @return com.python.common.response.CommonResult
     * @since 2020/5/22 15:42
     **/
    CommonResult selectPatientById(Integer id);

    /**
     * 查询患者列表
     * @author tanglong
     * @return com.python.common.response.CommonResult
     * @throws
     * @since 2020/5/23 9:16
     * @see
     **/
    CommonResult selectPatientList(String sortField,String sortReg,Integer pageSize,Integer pageNum);

    /**
     * 向数据库新增患者信息
     * @author tanglong
     * @param patient
     * @return com.python.common.response.CommonResult
     * @throws
     * @since 2020/5/22 15:43
     * @see
     **/
    CommonResult insertPatient(Patient patient);

    /**
     * 修改患者信息
     * @author tanglong
     * @param patient
     * @return com.python.common.response.CommonResult
     * @since 2020/5/29 10:26
     **/
    CommonResult updatePatient(Patient patient);
}
