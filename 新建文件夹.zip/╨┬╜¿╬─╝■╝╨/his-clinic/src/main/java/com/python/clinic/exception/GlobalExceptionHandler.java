package com.python.clinic.exception;

import com.python.common.response.CommonResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import java.util.List;

/**
 * 全局的的异常拦截器（拦截所有的控制器）（带有@RequestMapping注解的方法上都会拦截）
 * @author tomsun28
 * @date 22:40 2018/4/16
 */
@RestControllerAdvice
@Order(-1)
public class GlobalExceptionHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    /**
     * description 拦截未知的运行时异常
     *
     * @param e 1
     * @return com.usthe.bootshiro.domain.vo.Message
     */
    @ExceptionHandler(RuntimeException.class)
    @ResponseStatus(HttpStatus.OK)
    public CommonResult notFoundException(RuntimeException e) {
        LOGGER.error("运行时异常:",e);
        return CommonResult.failed("服务器开小差");
    }


    @ExceptionHandler(MethodArgumentNotValidException.class)
    public CommonResult<?> handleBindException(MethodArgumentNotValidException ex) {
        // ex.getFieldError():随机返回一个对象属性的异常信息。如果要一次性返回所有对象属性异常信息，则调用ex.getAllErrors()
        BindingResult bindingResult = ex.getBindingResult();
        List<FieldError> fieldErrors = bindingResult.getFieldErrors();
        StringBuilder builder = new StringBuilder();
        for (FieldError error : fieldErrors) {
            builder.append(error.getDefaultMessage() + "\n");
        }
        return CommonResult.failed(builder.toString());
    }

    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public CommonResult<?> handleMethodArgumentTypeMismatchException(MethodArgumentTypeMismatchException ex) {
        LOGGER.error("参数异常",ex);
        return CommonResult.failed("参数异常!!");
    }

    @ExceptionHandler(BaseException.class)
    public CommonResult<?> BaseExceptionException(BaseException ex) {
        LOGGER.error("参数异常",ex.getErrorMessage());
        return CommonResult.failed(ex.getErrorMessage());
    }

}
