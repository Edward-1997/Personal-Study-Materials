package com.python.clinic.controller.stock;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.python.clinic.entity.stock.StockLog;
import com.python.clinic.entity.stock.Warehousing;
import com.python.clinic.entity.stock.dto.WarehousingDTO;
import com.python.clinic.service.stock.WarehousingService;
import com.python.common.response.CommonResult;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Date;

/**
 * <p>
 * 入库表 前端控制器
 * </p>
 *
 * @author hm
 * @since 2020-05-22
 */
@RestController
@RequestMapping("/warehousing")
public class WarehousingController {

    Logger logger = LoggerFactory.getLogger(WarehousingController.class);

    @Autowired
    private WarehousingService warehousingService;

    @PutMapping("/updateWarehousing")
    @ApiOperation("修改入库信息")
    public CommonResult updateWarehousing(@RequestBody WarehousingDTO warehousingDTO){
        return CommonResult.result(warehousingService.updateWarehousing(warehousingDTO));
    }

    @PostMapping("/saveWarehousing")
    @ApiOperation("添加入库单信息")
    public CommonResult saveWarehousing(@RequestBody WarehousingDTO warehousingDTO){
        return CommonResult.result(warehousingService.saveWarehousing(warehousingDTO));
    }

    @GetMapping("/listWarehousing")
    @ApiOperation("查询入库信息列表")
    public CommonResult listWarehousing(@RequestParam(defaultValue = "1") Integer pageNo,
                                        @RequestParam(defaultValue = "10") Integer pageSize,
                                        String startTime,String endTime,Integer supplierId, Integer goodsId){
        IPage<Warehousing> page = new Page(pageNo,pageSize);
        return CommonResult.success(warehousingService.selectPage(page,startTime,endTime,supplierId,goodsId));
    }

}
