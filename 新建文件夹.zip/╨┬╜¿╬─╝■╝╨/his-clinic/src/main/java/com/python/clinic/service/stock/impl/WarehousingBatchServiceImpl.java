package com.python.clinic.service.stock.impl;

import com.python.clinic.dao.stock.StockLogDetailsMapper;
import com.python.clinic.dao.stock.StockLogMapper;
import com.python.clinic.entity.stock.StockLog;
import com.python.clinic.entity.stock.WarehousingBatch;
import com.python.clinic.dao.stock.WarehousingBatchMapper;
import com.python.clinic.entity.stock.dto.WarehousingDTO;
import com.python.clinic.service.stock.WarehousingBatchService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;

/**
 * <p>
 * 入库批次表 服务实现类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-22
 */
@Service
public class WarehousingBatchServiceImpl extends ServiceImpl<WarehousingBatchMapper, WarehousingBatch> implements WarehousingBatchService {

    @Resource
    private WarehousingBatchMapper batchMapper;
    @Resource
    private StockLogMapper stockLogMapper;
    @Resource
    private StockLogDetailsMapper stockLogDetailsMapper;

    @Override
    @Transactional(propagation= Propagation.REQUIRED,isolation= Isolation.DEFAULT,rollbackFor= RuntimeException.class)
    public boolean updateWarehousingBatch(WarehousingDTO warehousingDTO) {
        WarehousingBatch warehousingBatch = warehousingDTO.getBatchList().get(0);
        if (warehousingBatch != null){
            batchMapper.updateById(warehousingBatch);
            //添加药品修改操作日志
            StockLog stockLog = warehousingDTO.getStockLog();
            stockLog.setRelationId(warehousingBatch.getWarehousingId());
            //设置关联类型,2为入库
            stockLog.setRelationType(2);
            stockLogMapper.insert(stockLog);
            //添加修改详情
            stockLogDetailsMapper.saveBatch(warehousingDTO.getStockLogDetailsList(),stockLog.getId());
            return true;
        }
        return false;
    }
}
