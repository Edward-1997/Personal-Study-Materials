package com.python.clinic.dao.diagnosis;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.python.clinic.entity.diagnosis.TreatmentItem;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.python.clinic.entity.diagnosis.dto.TreatmentItemDetailsDto;
import com.python.clinic.entity.diagnosis.vo.SetMealVo;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 治疗项目表 Mapper 接口
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-26
 */
public interface TreatmentItemMapper extends BaseMapper<TreatmentItem> {

    /**
     * 根据患者id查询患者执行记录详情
     * @author tanglong
     * @return java.util.List<com.python.clinic.entity.diagnosis.dto.TreatmentItemDetailsDto>
     * @throws
     * @since 2020/5/27 17:06
     * @see
     **/
    List<TreatmentItemDetailsDto> selectPatientItemList(@Param("patientId") Integer patientId,
                                                        @Param("pageNum") Integer pageNum,
                                                        @Param("pageSize") Integer pageSize);

    Integer selectPatientItemListTotal(@Param("patientId") Integer patientId);

    /**
     * 查询治疗项目列表
     * @param type  类型  3:检查检验；4：治疗理疗；5：套餐；6：其他费用
     * @param subType  子类型 0:检查，1：检验，2：治疗，3：理疗
     * @param itemName 项目名称
     * @param clinicId 诊所id
     * @param page
     * @return
     */
    IPage<TreatmentItem> listTreatmentItem(IPage<TreatmentItem> page,@Param("type")Integer type, @Param("subType")Integer subType,
                                           @Param("itemName")Integer itemName, @Param("clinicId")Integer clinicId);

    /**
     * 查询套餐列表
     * @param itemName  套餐名称
     * @param clinicId  诊所id
     * @param page
     * @return
     */
    IPage<SetMealVo> listSetMeal(IPage<SetMealVo> page,@Param("itemName")Integer itemName, @Param("clinicId")Integer clinicId);

    /**
     * 获取套餐详情
     * @param setMealId
     * @return
     */
    SetMealVo getSetMeal(@Param("setMealId")Integer setMealId);
}
