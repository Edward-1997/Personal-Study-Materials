package com.python.clinic.dao.user;

import com.python.clinic.entity.user.UserTitle;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 用户职称表 Mapper 接口
 * </p>
 *
 * @author hm
 * @since 2020-06-02
 */
public interface UserTitleMapper extends BaseMapper<UserTitle> {

    /**
     * 批量插入用户职称
     * @param list
     * @param userInfoId
     * @return
     */
    int saveBatch(@Param("list")List<UserTitle> list,@Param("userInfoId")Integer userInfoId);

}
