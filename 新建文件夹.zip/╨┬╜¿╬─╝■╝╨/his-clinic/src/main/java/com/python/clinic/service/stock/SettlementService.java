package com.python.clinic.service.stock;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.python.clinic.entity.stock.Settlement;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 结算申请表 服务类
 * </p>
 *
 * @author hm
 * @since 2020-05-28
 */
public interface SettlementService extends IService<Settlement> {

    /**
     * 分页带条件查询结算申请
     * @param page
     * @param startTime 开始时间
     * @param endTime   结束时间
     * @param dateType  日期类型，提交日期：create，审核日期：audit
     * @param status    状态  0：待审核，1：已结算，2：未通过，3：已作废
     * @param supplierId  供应商id
     * @return
     */
    IPage<Settlement> selectPage(IPage<Settlement> page, String startTime, String endTime, String dateType, Integer status, Integer supplierId);

    /**
     * 根据主键id查询结算申请
     * @param id
     * @param type 0:结算申请，1:结算审核
     * @return
     */
    Settlement getSettlement(Integer id,Integer type);

    /**
     * 添加结算申请
     * @param settlement
     * @return
     */
    boolean saveSettlement(Settlement settlement);

    /**
     * 修改结算申请
     * @param settlement
     * @return
     */
    boolean updateSettlement(Settlement settlement);

}
