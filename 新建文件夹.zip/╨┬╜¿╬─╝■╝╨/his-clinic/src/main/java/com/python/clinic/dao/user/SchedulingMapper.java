package com.python.clinic.dao.user;

import com.python.clinic.entity.user.Scheduling;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 排班详情表 Mapper 接口
 * </p>
 *
 * @author hm
 * @since 2020-06-05
 */
public interface SchedulingMapper extends BaseMapper<Scheduling> {

    /**
     * 查询用户排班
     * @param userId
     * @param schedulingDate
     * @return
     */
    List<Map<String,Object>> listScheduling(@Param("userId")Integer userId, @Param("schedulingDate")String schedulingDate);

    /**
     * 批量插入排班
     * @param list
     * @return
     */
    int saveBatch(@Param("list") List<Scheduling> list);

    /**
     * 查询某诊室当前时间之后的排班数量
     * @param roomId
     * @return
     */
    int getNowAfterSchedulingCountByRoomId(Integer roomId);

}
