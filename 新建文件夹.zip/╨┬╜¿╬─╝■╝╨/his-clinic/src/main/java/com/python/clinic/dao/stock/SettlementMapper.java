package com.python.clinic.dao.stock;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.python.clinic.entity.stock.Settlement;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;


/**
 * <p>
 * 结算申请表 Mapper 接口
 * </p>
 *
 * @author hm
 * @since 2020-05-28
 */
public interface SettlementMapper extends BaseMapper<Settlement> {

    /**
     * 分页带条件查询结算申请
     * @param page
     * @param startTime 开始时间
     * @param endTime   结束时间
     * @param dateType  日期类型，提交日期：create，审核日期：audit
     * @param status    状态  0：待审核，1：已结算，2：未通过，3：已作废
     * @param supplierId  供应商id
     * @return
     */
    IPage<Settlement> selectPage(IPage<Settlement> page, @Param("startTime")String startTime, @Param("endTime")String endTime,
                                 @Param("dateType")String dateType,@Param("status")Integer status,@Param("supplierId")Integer supplierId);

    /**
     * 查询结算申请
     * @param id  主键
     * @return
     */
    Settlement getSettlementById(@Param("id")Integer id);

}
