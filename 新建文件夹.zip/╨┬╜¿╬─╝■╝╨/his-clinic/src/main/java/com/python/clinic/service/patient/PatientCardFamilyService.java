package com.python.clinic.service.patient;

import com.python.clinic.entity.patient.PatientCardFamily;
import com.baomidou.mybatisplus.extension.service.IService;
import com.python.common.response.CommonResult;

/**
 * <p>
 * 会员卡家庭成员表 服务类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-20
 */
public interface PatientCardFamilyService extends IService<PatientCardFamily> {

    /**
     * 传入患者id，完成新增患者会员
     * @author tanglong
     * @return com.python.common.response.CommonResult
     * @since 2020/6/1 15:41
     **/
    CommonResult insertPatientFamily(Integer patientId);

    /**
     * 传入患者患者会员卡家庭成员实体类，完成删除患者家庭成员
     * @author tanglong
     * @param patientCardFamily 患者会员卡家庭成员实体类
     * @return com.python.common.response.CommonResult
     * @since 2020/6/1 16:04
     **/
    CommonResult deleteFamilyMembers(PatientCardFamily patientCardFamily);
}
