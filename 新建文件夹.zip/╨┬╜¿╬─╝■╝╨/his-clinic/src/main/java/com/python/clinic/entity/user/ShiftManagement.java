package com.python.clinic.entity.user;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import java.time.LocalTime;
import java.util.Date;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

/**
 * <p>
 * 班次管理
 * </p>
 *
 * @author hm
 * @since 2020-06-03
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_shift_management")
@ApiModel(value="ShiftManagement对象", description="班次管理")
public class ShiftManagement extends Model<ShiftManagement> {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "班次管理主键")
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "班次名称")
    @NotEmpty(message = "班次名不能为空")
    private String shiftsName;

    @ApiModelProperty(value = "开始时间")
    @NotNull(message = "时间不能为空")
    private Date startTime;

    @ApiModelProperty(value = "结束时间")
    @NotNull(message = "时间不能为空")
    private Date endTime;

    @ApiModelProperty(value = "最大服务数，根据时间结算，每分钟最多一个号")
    private Integer maxServiceNum;

    @ApiModelProperty(value = "诊所id")
    private Integer clinicId;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
