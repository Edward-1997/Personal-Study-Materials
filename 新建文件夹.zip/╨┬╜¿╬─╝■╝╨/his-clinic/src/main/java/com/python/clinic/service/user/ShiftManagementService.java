package com.python.clinic.service.user;

import com.python.clinic.entity.user.ShiftManagement;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 班次管理 服务类
 * </p>
 *
 * @author hm
 * @since 2020-06-03
 */
public interface ShiftManagementService extends IService<ShiftManagement> {

    /**
     * 删除班次
     * @param id
     * @return
     */
    boolean deleteShiftManagement(Integer id);

}
