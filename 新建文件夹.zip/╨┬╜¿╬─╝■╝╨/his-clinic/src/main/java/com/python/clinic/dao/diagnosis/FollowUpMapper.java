package com.python.clinic.dao.diagnosis;

import com.python.clinic.entity.diagnosis.FollowUp;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 随访表 Mapper 接口
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-22
 */
public interface FollowUpMapper extends BaseMapper<FollowUp> {

}
