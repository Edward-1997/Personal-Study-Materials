package com.python.clinic.entity.stock.vo;

import com.python.clinic.entity.stock.StockLogDetails;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * @author hm
 */
@Data
public class StockLogVo {

    private Integer id;

    @ApiModelProperty(value = "创建时间")
    private Date createTime;

    @ApiModelProperty(value = "创建人id")
    private Integer createId;

    @ApiModelProperty(value = "创建人")
    private String creator;

    @ApiModelProperty(value = "诊所id")
    private Integer clinicId;

    @ApiModelProperty("诊所名称")
    private String clinic;

    @ApiModelProperty(value = "行为")
    private String action;

    @ApiModelProperty(value = "备注")
    private String remark;

    @ApiModelProperty("操作日志详情")
    private List<StockLogDetails> stockLogDetailsList;

}
