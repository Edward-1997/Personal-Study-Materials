package com.python.clinic.dao.patient;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.python.clinic.entity.patient.PatientMemberCard;

/**
 * <p>
 * 患者会员卡 Mapper 接口
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-20
 */
public interface PatientMemberCardMapper extends BaseMapper<PatientMemberCard> {

    /**
     * 获取该会员卡下患者人数
     * @author tanglong
     * @param cardId 会员卡id
     * @return java.lang.Integer
     * @since 2020/6/4 9:34
     **/
    Integer selectCountForMemberCard(Integer cardId);
}
