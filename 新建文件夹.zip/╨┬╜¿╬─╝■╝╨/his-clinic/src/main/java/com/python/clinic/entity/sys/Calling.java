package com.python.clinic.entity.sys;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 叫号设置
 * </p>
 *
 * @author hm
 * @since 2020-06-05
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_calling")
@ApiModel(value="Calling对象", description="叫号设置")
public class Calling extends Model<Calling> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "开启叫号，0：false，1：true")
    private Boolean enableCalling;

    @ApiModelProperty(value = "患者姓名隐私保护，0：false，1：true")
    private Boolean hidePatientName;

    @ApiModelProperty(value = "已上屏顺序锁定")
    private Boolean enableLockScreen;

    @ApiModelProperty(value = "开启预约迟到惩罚")
    private Boolean enableLatePenalty;

    @ApiModelProperty(value = "迟到时间")
    private Integer lateTime;

    @ApiModelProperty(value = "时间单位，0：分钟，1：小时")
    private Integer unit;

    @ApiModelProperty(value = "叫号顺延")
    private Integer delayNo;

    @ApiModelProperty(value = "显示风格，0：浅色淡雅，1：深色通透")
    private Integer style;

    @ApiModelProperty(value = "诊所id")
    private Integer clinicId;

    @ApiModelProperty(value = "医生展示，0：仅显示有待叫号患者的医生，1：显示所有排班的医生")
    private Integer doctorShow;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
