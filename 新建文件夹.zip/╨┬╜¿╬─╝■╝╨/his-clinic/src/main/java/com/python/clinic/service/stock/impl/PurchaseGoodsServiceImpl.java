package com.python.clinic.service.stock.impl;

import com.python.clinic.entity.stock.PurchaseGoods;
import com.python.clinic.dao.stock.PurchaseGoodsMapper;
import com.python.clinic.service.stock.PurchaseGoodsService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 采购药品/物资表 服务实现类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-21
 */
@Service
public class PurchaseGoodsServiceImpl extends ServiceImpl<PurchaseGoodsMapper, PurchaseGoods> implements PurchaseGoodsService {

}
