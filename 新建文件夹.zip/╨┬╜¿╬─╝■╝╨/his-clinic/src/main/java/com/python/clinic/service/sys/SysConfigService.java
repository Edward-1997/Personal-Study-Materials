package com.python.clinic.service.sys;

import com.python.clinic.entity.sys.SysConfig;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 系统配置 服务类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-21
 */
public interface SysConfigService extends IService<SysConfig> {

}
