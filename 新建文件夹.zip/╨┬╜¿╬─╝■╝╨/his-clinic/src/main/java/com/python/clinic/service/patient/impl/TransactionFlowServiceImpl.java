package com.python.clinic.service.patient.impl;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.python.clinic.dao.patient.TransactionFlowMapper;
import com.python.clinic.entity.patient.TransactionFlow;
import com.python.clinic.service.patient.TransactionFlowService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.python.common.response.CommonResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * 交易流水表 服务实现类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-20
 */
@Service
public class TransactionFlowServiceImpl extends ServiceImpl<TransactionFlowMapper, TransactionFlow> implements TransactionFlowService {
    @Autowired
    private TransactionFlowMapper flowMapper;

    @Override
    public CommonResult getTransactionList(Integer patientCardId,Integer pageSize,Integer pageNum){
        TransactionFlow transactionFlow = new TransactionFlow();
        transactionFlow.setPatientCardId(patientCardId);
        QueryWrapper<TransactionFlow> wrapper = new QueryWrapper(transactionFlow);
        IPage<TransactionFlow> page = new Page<>(pageNum,pageSize);
        IPage<TransactionFlow> transactionList = flowMapper.selectPage(page,
                wrapper.orderByDesc("transaction_time"));
        if(transactionList.getRecords().size() > 0){
            Map<String,Object> map = new HashMap<>();
            map.put("transactionFlow",transactionList);
            return CommonResult.success(map,"查询交易流水成功");
        }

        return CommonResult.failed("未查询到交易流水记录");
    }

//    @Override
//    public CommonResult insertTransactionRecord(TransactionFlow record) {
//        //获得该会员最近的一条流水交易
//        TransactionFlow lastRecord = new TransactionFlow();
//        lastRecord.setPatientCardId(record.getPatientCardId());
//        QueryWrapper<TransactionFlow> wrapper = new QueryWrapper<>(lastRecord).orderByDesc("transaction_time");
//        IPage<TransactionFlow> page = new Page<>(1,1);
//        IPage<TransactionFlow> lastFlow = flowMapper.selectPage(page, wrapper);
//
//        int index = 0;
//
//        if(lastFlow == null){
//            //该患者无交易记录，则直接添加剩余本金和剩余赠金
//            //添加剩余本金，剩余赠金
//            record.setSurplusGiftAmout(record.getPayGiftAmout());
//            record.setSurplusPrincipal(record.getPayPrincipal());
//        }else {
//            //该患者有交易记录，则将充值的本金和赠金添加到剩余本金和赠金中
//            record.setSurplusPrincipal(lastFlow.getRecords().get(0).getSurplusPrincipal().add(record.getPayPrincipal()));
//            record.setSurplusGiftAmout(lastFlow.getRecords().get(0).getSurplusGiftAmout().add(record.getPayGiftAmout()));
//            if(record.getSurplusPrincipal().signum() == -1 || record.getSurplusGiftAmout().signum() == -1){
//                return CommonResult.failed("退款异常：退款金额大于本金");
//            }
//        }
//
//        record.setPayPrincipal(record.getPayPrincipal().abs());
//        record.setPayGiftAmout(record.getPayGiftAmout().abs());
//        record.setTransactionTime(new Date());
//        index = flowMapper.insert(record);
//        if(index == 0 ){
//            return CommonResult.failed("充值失败");
//        }
//        return CommonResult.success("充值成功");
//    }
}
