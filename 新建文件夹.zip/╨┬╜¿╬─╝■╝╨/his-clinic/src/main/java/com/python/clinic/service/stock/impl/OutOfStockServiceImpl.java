package com.python.clinic.service.stock.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.python.clinic.dao.stock.*;
import com.python.clinic.dao.sys.ClinicMapper;
import com.python.clinic.dao.user.UserMapper;
import com.python.clinic.entity.stock.*;
import com.python.clinic.entity.stock.vo.GoodsStockVo;
import com.python.clinic.exception.BaseException;
import com.python.clinic.service.stock.OutOfStockService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.python.clinic.service.stock.StockLogService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * <p>
 * 出库表 服务实现类
 * </p>
 *
 * @author hm
 * @since 2020-05-23
 */
@Service
public class OutOfStockServiceImpl extends ServiceImpl<OutOfStockMapper, OutOfStock> implements OutOfStockService {

    @Resource
    private OutOfStockMapper outOfStockMapper;
    @Resource
    private OutOfStockDetailsMapper outDetailsMapper;
    @Resource
    private OutOfStockBatchMapper outBatchMapper;
    @Resource
    private WarehousingBatchMapper warehousingBatchMapper;
    @Resource
    private UserMapper userMapper;
    @Resource
    private ClinicMapper clinicMapper;
    @Resource
    private StockLogService stockLogService;

    @Override
    public IPage<OutOfStock> selectPage(IPage<OutOfStock> page,String startTime,String endTime,
                                        Integer type,Integer goodsId) {
        IPage<OutOfStock> outOfStockIPage = outOfStockMapper.selectPage(page,startTime,endTime,type,goodsId);
        for (OutOfStock record : outOfStockIPage.getRecords()) {
            //查询创建人
            record.setCreator(userMapper.getIdAndName(record.getCreateId()));
            //查询所属诊所
            record.setClinic(clinicMapper.getIdAndName(record.getClinicId()));
        }
        return outOfStockIPage;
    }

    @Override
    @Transactional(propagation= Propagation.REQUIRED,isolation= Isolation.DEFAULT,rollbackFor= Exception.class)
    public boolean saveOutOfStock(OutOfStock outOfStock) throws BaseException {
        //添加出库
        outOfStockMapper.insert(outOfStock);
        //出库总数量（整装数量）、出库总金额
        BigDecimal count = new BigDecimal(0);
        BigDecimal amount = new BigDecimal(0);

        //出库批次对象
        OutOfStockBatch outOfStockBatch = null;
        //添加出库详情
        for (OutOfStockDetails outOfStockDetails : outOfStock.getDetailsList()) {

            //设置出库id
            outOfStockDetails.setOutStockId(outOfStock.getId());

            if (outOfStockDetails.getSpecifyBatch()){
                //指定出库批次,直接插入

                //入库批次对象
                WarehousingBatch warehousingBatch = new WarehousingBatch();
                //查询入库批次当前库存以及制剂
                GoodsStockVo goodsStockVo = warehousingBatchMapper.getGoodsStockAndPreparation(outOfStockDetails.getBatchId());
                //判断规格是否为空
                boolean preparationIsNull = (goodsStockVo.getPreparation() == null);
                //设置入库批次id
                warehousingBatch.setId(outOfStockDetails.getBatchId());
                //出库数量(最小单位)
                Integer outPieceNum = outOfStockDetails.getPiece() ? outOfStockDetails.getOutNum() : outOfStockDetails.getOutNum() * goodsStockVo.getPreparation();
                count = count.add(preparationIsNull ? new BigDecimal(outPieceNum) : new BigDecimal(outPieceNum).divide(new BigDecimal(goodsStockVo.getPreparation())));
                //计算总金额
                outOfStockDetails.setAmount(new BigDecimal(outPieceNum).multiply(outOfStockDetails.getPurchasePrice()));
                amount = amount.add(outOfStockDetails.getAmount());
                //新增出库详情
                outOfStockDetails.setPurchasePriceUnit(goodsStockVo.getPackageUnit());
                outDetailsMapper.insert(outOfStockDetails);

                //总库存
                Integer pieceStock = preparationIsNull ? goodsStockVo.getPieceCount() : goodsStockVo.getPackageCount() * goodsStockVo.getPreparation() + goodsStockVo.getPieceCount();
                if (outPieceNum > pieceStock){
                    throw new BaseException(500, goodsStockVo.getMedicineCadn()+" 出库数量大于库存！");
                }
                //修改剩余库存
                warehousingBatch.setPackageCount(preparationIsNull ? 0 : (pieceStock-outPieceNum) / goodsStockVo.getPreparation());
                warehousingBatch.setPackageCount(preparationIsNull ? (pieceStock-outPieceNum) : (pieceStock-outPieceNum) / goodsStockVo.getPreparation());
                warehousingBatchMapper.updateById(warehousingBatch);

            }else {
                //不指定出库批次，需判断哪些批次出库

                //商品总库存、商品制剂
                GoodsStockVo goodsStockVoCount = warehousingBatchMapper.getGoodsStockCount(outOfStockDetails.getGoodsId());
                //判断规格是否为空
                boolean preparationIsNull = (goodsStockVoCount.getPreparation() == null);
                //总库存
                Integer pieceStock = preparationIsNull ? goodsStockVoCount.getPieceCount() : goodsStockVoCount.getPackageCount() * goodsStockVoCount.getPreparation() + goodsStockVoCount.getPieceCount();
                //出库数量
                Integer outPieceNum = outOfStockDetails.getPiece() ? outOfStockDetails.getOutNum() : outOfStockDetails.getOutNum() * goodsStockVoCount.getPreparation();
                if (outPieceNum > pieceStock){
                    throw new BaseException(500, goodsStockVoCount.getMedicineCadn()+" 出库数量大于库存！");
                }
                //查询库存数量不为零的批次
                QueryWrapper<WarehousingBatch> warehousingWrapper = new QueryWrapper();
                //查询出库商品库存不为零的批次，按有效期顺序排列
                warehousingWrapper.select("id","package_count","piece_count").ne("package_count",0).or().
                        ne("piece_count",0).eq("goods_id",outOfStockDetails.getGoodsId()).orderByAsc("expiry_date");
                List<WarehousingBatch> warehousingBatches = warehousingBatchMapper.selectList(warehousingWrapper);

                //出库详情金额
                BigDecimal detailsAmount = new BigDecimal(0);
                //先新增出库详情，后面再修改金额以及数量
                outDetailsMapper.insert(outOfStockDetails);
                //累加出库金额
                amount = amount.add(new BigDecimal(outPieceNum).multiply(outOfStockDetails.getPurchasePrice()));
                //出库批次
                for (WarehousingBatch temp : warehousingBatches) {
                    GoodsStockVo goodsStockVo = warehousingBatchMapper.getGoodsStockAndPreparation(temp.getId());
                    //查询当前入库批次总数量(按最小存库单位计算)
                    Integer batchStockPiece = preparationIsNull ? temp.getPieceCount() : temp.getPackageCount() * goodsStockVo.getPreparation() + temp.getPieceCount();
                    if (outPieceNum <= batchStockPiece){
                        //当前批次库存足够扣除出库数量，跳出循环

                        //修改入库批次剩余库存
                        batchStockPiece = batchStockPiece - outPieceNum;
                        temp.setPackageCount(preparationIsNull ? 0 : batchStockPiece / goodsStockVo.getPreparation());
                        temp.setPieceCount(preparationIsNull ? batchStockPiece : batchStockPiece % goodsStockVo.getPreparation());
                        warehousingBatchMapper.updateById(temp);

                        //计算该批次出库金额
                        BigDecimal batchAmount = (preparationIsNull ? new BigDecimal(outPieceNum).multiply(goodsStockVo.getPackagePrice())
                                : new BigDecimal(outPieceNum).multiply(goodsStockVo.getPackagePrice())).divide(new BigDecimal(goodsStockVo.getPreparation()));
                        detailsAmount = detailsAmount.add(batchAmount);

                        //修改出库详情
                        OutOfStockDetails stockDetails = new OutOfStockDetails();
                        stockDetails.setId(outOfStockDetails.getId());
                        stockDetails.setPurchasePriceUnit(goodsStockVo.getPackageUnit());
                        stockDetails.setAmount(detailsAmount);
                        outDetailsMapper.updateById(stockDetails);

                        //累加出库总金额
                        amount = amount.add(detailsAmount);

                        //添加出库批次
                        int packageCount = preparationIsNull ? 0 : outPieceNum / goodsStockVo.getPreparation();
                        int pieceCount =  preparationIsNull ? outPieceNum : outPieceNum % goodsStockVo.getPreparation();
                        outOfStockBatch = new OutOfStockBatch(outOfStockDetails.getId(),temp.getId(),packageCount, pieceCount,
                                                              goodsStockVo.getPackageUnit(), goodsStockVo.getPreparationUnit(), batchAmount);
                        outBatchMapper.insert(outOfStockBatch);

                        break;
                    }else {
                        //当前批次库存不够扣除出库数量
                        outPieceNum = outPieceNum - batchStockPiece;
                        temp.setPackageCount(0);
                        temp.setPieceCount(0);
                        warehousingBatchMapper.updateById(temp);

                        //添加出库批次
                        BigDecimal batchAmount = (preparationIsNull ? new BigDecimal(batchStockPiece).multiply(goodsStockVo.getPackagePrice())
                                : new BigDecimal(batchStockPiece).multiply(goodsStockVo.getPackagePrice()).divide(new BigDecimal(goodsStockVo.getPreparation())) );
                        int packageCount = preparationIsNull ? 0 : batchStockPiece / goodsStockVo.getPreparation();
                        int pieceCount =  preparationIsNull ? batchStockPiece : outPieceNum % goodsStockVo.getPreparation();
                        outOfStockBatch = new OutOfStockBatch(outOfStockDetails.getId(),temp.getId(),packageCount,pieceCount,
                                                              goodsStockVo.getPackageUnit(), goodsStockVo.getPreparationUnit(), batchAmount);
                        outBatchMapper.insert(outOfStockBatch);

                        //累加出库详情金额
                        detailsAmount = detailsAmount.add(batchAmount);

                    }

                }
            }
        }

        //添加完出库详情，计算总金额以及总数量，并修改
        OutOfStock updateOutOfStock = new OutOfStock();
        outOfStock.setId(outOfStock.getId());
        outOfStock.setAmount(amount);
        outOfStock.setOutCount(count.doubleValue());
        outOfStockMapper.updateById(outOfStock);

        //添加操作日志
        StockLog stockLog = new StockLog("创建出库单",new Date(),outOfStock.getCreateId(),outOfStock.getId(),3,outOfStock.getClinicId());
        stockLogService.save(stockLog);
        return true;
    }

    @Override
    public OutOfStock getOutOfStock(Integer id) {
        //1.出库信息    注：科室对象暂时无法创建，后面再进行赋值
        OutOfStock outOfStock = outOfStockMapper.selectById(id);
        if (outOfStock != null){
            outOfStock.setCreator(userMapper.getIdAndName(outOfStock.getCreateId()));
            outOfStock.setClinic(clinicMapper.getIdAndName(outOfStock.getClinicId()));
            outOfStock.setToUser(userMapper.getIdAndName(outOfStock.getToUserId()));
            //2.出库详情
            outOfStock.setDetailsList(outDetailsMapper.listStockDetailsByOutStockId(outOfStock.getId()));
            //3.出库日志
            outOfStock.setLogList(stockLogService.listStockLog(id,3));
        }
        return outOfStock;
    }


}
