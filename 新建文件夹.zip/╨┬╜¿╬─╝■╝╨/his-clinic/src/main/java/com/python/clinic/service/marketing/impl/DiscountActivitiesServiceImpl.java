package com.python.clinic.service.marketing.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.python.clinic.entity.marketing.DiscountActivities;
import com.python.clinic.dao.marketing.DiscountActivitiesMapper;
import com.python.clinic.entity.marketing.DiscountMember;
import com.python.clinic.entity.marketing.DiscountSetting;
import com.python.clinic.entity.marketing.constant.MarketingConstant;
import com.python.clinic.entity.marketing.dto.DiscountActivityDetailsDto;
import com.python.clinic.entity.marketing.vo.DiscountActivitiesVo;
import com.python.clinic.entity.sys.Clinic;
import com.python.clinic.service.marketing.DiscountActivitiesService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.python.clinic.service.marketing.DiscountMemberService;
import com.python.clinic.service.marketing.DiscountSettingService;
import com.python.clinic.service.marketing.MemberCardService;
import com.python.clinic.service.sys.ClinicService;
import com.python.common.response.CommonResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * <p>
 * 折扣活动表 服务实现类
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-02
 */
@Service
public class DiscountActivitiesServiceImpl extends ServiceImpl<DiscountActivitiesMapper, DiscountActivities> implements DiscountActivitiesService {

    @Autowired
    private DiscountActivitiesMapper discountActivitiesMapper;
    @Autowired
    private DiscountMemberService discountMemberService;
    @Autowired
    private DiscountSettingService discountSettingService;
    @Autowired
    private ClinicService clinicService;
    @Autowired
    private MemberCardService memberCardService;

    @Override
    public DiscountActivityDetailsDto getDiscountActivityDetails(Integer id) {
        DiscountActivityDetailsDto detailsDto = new DiscountActivityDetailsDto();
        //设置基本折扣信息
        DiscountActivities discountActivities = discountActivitiesMapper.selectById(id);
        detailsDto.setDiscountActivities(discountActivities);
        //查询活动指定范围
        if(!MarketingConstant.ALL_PATIENT.equals(discountActivities.getActivityObject())){
            DiscountMember discountMember = new DiscountMember();
            discountMember.setDiscountId(id);
            discountMember.setMemberDiscount(0);//不是会员卡折扣
            detailsDto.setDiscountMemberList(discountMemberService.getDiscountMemberList(discountMember));
        }

        //查询折扣设置信息
        DiscountSetting discountSetting = new DiscountSetting();
        discountSetting.setDiscountId(id);
        detailsDto.setGoodsList(discountSettingService.getDiscountSettingList(discountSetting));

        return detailsDto;
    }

    @Override
    public IPage<DiscountActivitiesVo> getDiscountActivities(Integer pageNum, Integer pageSize) {
        IPage<DiscountActivities> pages = new Page<>(pageNum,pageSize);

        pages = discountActivitiesMapper.selectPage(pages,null);

        return pages.convert(discountActivity->{

            DiscountActivitiesVo vo = new DiscountActivitiesVo();
            vo.setId(discountActivity.getId());
            vo.setName(discountActivity.getActivityName());
            vo.setStatus(discountActivity.getStatus());
            //设置活动对象
            if(MarketingConstant.ALL_PATIENT.equals(discountActivity.getActivityObject())){
                vo.setApplicators(Collections.singletonList("所有患者"));
            }else {
                DiscountMember discountMember = new DiscountMember();
                discountMember.setDiscountId(discountActivity.getId());
                List<DiscountMember> discountMemberList = discountMemberService.getDiscountMemberList(discountMember);

                vo.setApplicators(discountMemberList.stream()
                        .map(discount -> memberCardService.getById(discount.getMemberCardId()).getCardName())
                        .collect(Collectors.toList()));
            }
            //设置活动产品数量
            vo.setCount(discountSettingService.getDiscountStatistic(discountActivity.getId()));

            //查询产品冲突信息
            vo.setConflictNum(discountSettingService
                    .getConflictDiscountSettingCount(discountActivity.getId()));

            if(!discountActivity.getActivityShop().equals(0)){//0:所有门店 1：指定门店
                Clinic clinic = clinicService.getById(discountActivity.getActivityShop());
                vo.setClinic(clinic.getClinicName());
            }else {
                vo.setClinic("所有门店");
            }
            vo.setBeginDate(discountActivity.getStartTime());
            vo.setEndDate(discountActivity.getEndTime());

            return vo;
        });
    }
}
