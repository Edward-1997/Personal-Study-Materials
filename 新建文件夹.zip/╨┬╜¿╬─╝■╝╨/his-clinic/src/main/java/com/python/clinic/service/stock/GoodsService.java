package com.python.clinic.service.stock;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.python.clinic.entity.stock.Goods;
import com.python.clinic.entity.stock.dto.GoodsDTO;
import com.python.clinic.entity.stock.dto.GoodsSelectDTO;
import com.python.clinic.entity.stock.vo.GoodsVo;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 药品/物资表 服务类
 * </p>
 *
 * @author hm
 * @since 2020-05-19
 */
public interface GoodsService extends IService<Goods> {

    /**
     * 添加商品以及记录操作日志
     * @param goodsDto
     * @return
     */
    boolean saveGoods(GoodsDTO goodsDto);

    /**
     * 修改商品以及记录操作日志
     * @param goodsDto
     * @return
     */
    boolean updateGoods(GoodsDTO goodsDto);

    /**
     * 查询药品信息和操作日志，返回值为map，包含商品和操作日志数据
     * @param id
     * @return
     */
    Map<String,Object> getGoods(Integer id);

    /**
     * 查询商品列表
     * @param page
     * @param goodsDTO
     * @return
     */
    Map<String,Object> listGoods(IPage<GoodsVo> page, GoodsSelectDTO goodsDTO);


    /**
     * 获取商品历史进价
     * @param goodsId
     * @return
     */
    Map<String,Object> getHistoricalPrice(Integer goodsId);

}
