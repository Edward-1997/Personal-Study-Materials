package com.python.clinic.service.user.impl;

import com.python.clinic.entity.user.TitleInfo;
import com.python.clinic.dao.user.TitleInfoMapper;
import com.python.clinic.service.user.TitleInfoService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 职称信息表 服务实现类
 * </p>
 *
 * @author hm
 * @since 2020-06-02
 */
@Service
public class TitleInfoServiceImpl extends ServiceImpl<TitleInfoMapper, TitleInfo> implements TitleInfoService {

}
