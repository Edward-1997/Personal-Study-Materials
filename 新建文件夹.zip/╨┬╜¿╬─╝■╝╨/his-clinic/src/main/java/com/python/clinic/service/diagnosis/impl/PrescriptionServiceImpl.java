package com.python.clinic.service.diagnosis.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.python.clinic.dao.diagnosis.PrescriptionDetailsMapper;
import com.python.clinic.entity.diagnosis.Prescription;
import com.python.clinic.dao.diagnosis.PrescriptionMapper;
import com.python.clinic.entity.diagnosis.PrescriptionDetails;
import com.python.clinic.service.diagnosis.PrescriptionService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * <p>
 * 处方 服务实现类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-26
 */
@Service
public class PrescriptionServiceImpl extends ServiceImpl<PrescriptionMapper, Prescription> implements PrescriptionService {

    @Autowired
    private PrescriptionMapper prescriptionMapper;
    @Autowired
    private PrescriptionDetailsMapper prescriptionDetailsMapper;

    @Override
    public List<Prescription> getPrescriptionList(Prescription prescription) {
        List<Prescription> prescriptions = prescriptionMapper.selectList(new QueryWrapper<>(prescription));
        if(prescriptions == null){
            return null;
        }

        return prescriptions.stream().parallel().peek(prescriptionDetail ->{
            PrescriptionDetails detail = new PrescriptionDetails();
            detail.setPrescriptionId(prescription.getId());
            List<PrescriptionDetails> detailsList = prescriptionDetailsMapper.selectList(new QueryWrapper<>(detail));
            prescriptionDetail.setPrescriptionDetails(detailsList);
        } ).collect(Collectors.toList());
    }
}
