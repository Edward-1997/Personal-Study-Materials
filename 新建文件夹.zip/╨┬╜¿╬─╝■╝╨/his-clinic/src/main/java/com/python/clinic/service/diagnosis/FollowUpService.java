package com.python.clinic.service.diagnosis;

import com.python.clinic.entity.diagnosis.FollowUp;
import com.baomidou.mybatisplus.extension.service.IService;
import com.python.clinic.entity.diagnosis.dto.FollowUpDto;
import com.python.common.response.CommonResult;

import java.text.ParseException;
import java.util.Date;

/**
 * <p>
 * 随访表 服务类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-22
 */
public interface FollowUpService extends IService<FollowUp> {

    /**
     * 通过随访记录id，获取随访记录详细信息
     * @author tanglong
     * @param id 随访记录id
     * @return com.python.common.response.CommonResult
     * @since 2020/5/26 15:12
     **/
    CommonResult getFollowRecord(Integer id);

    /**
     * 获取医生任务列表以及医生待执行的随访计划
     * @author tanglong
     * @param followTime, doctorId]
     * @return com.python.common.response.CommonResult
     * @since 2020/5/26 14:40
     **/
    CommonResult getDoctorFollowList(Date followTime, Integer doctorId);

    /**
     * 传入需要更改的随访执行计划
     * @author tanglong
     * @return com.python.common.response.CommonResult
     * @since 2020/5/26 14:45
     **/
    CommonResult updateFollowRecord(FollowUp followUp);

    /**
     * 传入新建患者的随访执行计划
     * @author tanglong
     * @return com.python.common.response.CommonResult
     * @since 2020/5/26 14:51
     **/
    CommonResult insertFollowRecord(FollowUpDto followUpDto) throws ParseException;
}
