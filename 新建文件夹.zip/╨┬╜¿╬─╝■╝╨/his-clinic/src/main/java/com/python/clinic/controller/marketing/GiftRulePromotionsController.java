package com.python.clinic.controller.marketing;


import com.python.clinic.entity.marketing.dto.GiftDetailsDto;
import com.python.clinic.service.marketing.GiftRulePromotionsService;
import com.python.common.response.CommonResult;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * 满减返活动表 前端控制器
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-05
 */
@RestController
@RequestMapping("/gift_rule_promotions")
public class GiftRulePromotionsController {

    @Autowired
    private GiftRulePromotionsService giftRulePromotionsService;

    @ApiOperation(value="获取满减返回活动详情",notes = "传入满减返活动id")
    @GetMapping("/details/{id}")
    public CommonResult getGiftDetails(@PathVariable Integer id){
        Map<String,Object> map = new HashMap<>();
        map.put("giftDetails",giftRulePromotionsService.getGiftDetails(id));
        return CommonResult.success(map,"查询成功");
    }

    //由于支付收费这部分内容还未开始，这部分暂时未完成
    @ApiOperation(value = "获取满减返活动列表",notes = "分页查询活动列表，默认一页10条数据")
    @GetMapping("/list")
    public CommonResult getGiftList(@RequestParam(defaultValue = "1") Integer pageNum,
                                    @RequestParam(defaultValue = "2") Integer pageSize,
                                    @RequestParam(defaultValue = "-1") Integer status){
        Map<String,Object> map = new HashMap<>();
        map.put("giftList",giftRulePromotionsService.getGiftList(status,pageNum,pageSize));
        return CommonResult.success(map,"查询成功");
    }

    @ApiOperation(value = "新增满减返活动",notes = "传入GiftDetailsDto对象，完成新增满减返活动操作")
    @PostMapping("/save")
    public CommonResult insertGiftPromotion(@RequestBody GiftDetailsDto giftDetailsDto){
        return giftRulePromotionsService.insertGiftPromotion(giftDetailsDto);
    }

    @ApiOperation(value = "终止满减返活动",notes = "传入满减返活动id，完成终止满减返活动操作")
    @PutMapping("/termination/{id}")
    public CommonResult terminateGift(@PathVariable Integer id){
        return giftRulePromotionsService.terminateGiftActivity(id);
    }

    @ApiOperation(value = "更新满减返活动",notes = "传入更新后的GiftDetailsDto对象，完成更新操作")
    @PutMapping("/edit")
    public CommonResult updateGiftPromotion(@RequestBody GiftDetailsDto giftDetailsDto){
        return giftRulePromotionsService.updateGiftPromotion(giftDetailsDto);
    }
}
