package com.python.clinic.entity.marketing;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 优惠设置表
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-05
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_preferential_set")
@ApiModel(value="PreferentialSet对象", description="优惠设置表")
public class PreferentialSet extends Model<PreferentialSet> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "满减活动id")
    private Integer giftId;

    @ApiModelProperty(value = "满减价格阈值")
    private BigDecimal orderThresholdPrice;

    @ApiModelProperty(value = "满减")
    private Integer fullReduce;

    @ApiModelProperty(value = "满返")
    private Integer fullReturn;

    @ApiModelProperty(value = "满赠")
    private Integer fullGive;

    @ApiModelProperty(value = "循环")
    private Integer cycle;

    @ApiModelProperty(value = "立减")
    private BigDecimal discountedPrice;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
