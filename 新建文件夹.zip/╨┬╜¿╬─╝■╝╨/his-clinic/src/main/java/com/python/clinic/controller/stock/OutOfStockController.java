package com.python.clinic.controller.stock;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.python.clinic.entity.stock.OutOfStock;
import com.python.clinic.exception.BaseException;
import com.python.clinic.service.stock.OutOfStockService;
import com.python.common.response.CommonResult;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 * 出库表 前端控制器
 * </p>
 *
 * @author hm
 * @since 2020-05-23
 */
@RestController
@RequestMapping("/outOfStock")
@Api(tags = "出库")
public class OutOfStockController {

    @Autowired
    private OutOfStockService outOfStockService;

    @GetMapping("/listOutOfStock")
    @ApiOperation(value = "出库列表查询",notes = "startTime:开始时间，endTime:结束时间，type:类型，goodsId:商品id")
    public CommonResult listOutOfStock(@RequestParam(defaultValue = "1") Integer pageNo,
                                       @RequestParam(defaultValue = "10") Integer pageSize,
                                       String startTime,String endTime,Integer type,Integer goodsId){
        IPage<OutOfStock> page = new Page<>(pageNo,pageSize);
        return CommonResult.success(outOfStockService.selectPage(page,startTime,endTime,type,goodsId));
    }

    @PostMapping("/saveOutOfStock")
    @ApiOperation(value = "添加出库信息")
    public CommonResult saveOutOfStock(@RequestBody OutOfStock outOfStock) throws BaseException {
        return CommonResult.result(outOfStockService.saveOutOfStock(outOfStock));
    }

    @GetMapping("/getOutOfStock")
    @ApiOperation(value = "获取出库信息")
    public CommonResult getOutOfStock(@RequestParam(required = true)Integer id){
        return CommonResult.success(outOfStockService.getOutOfStock(id));
    }

}
