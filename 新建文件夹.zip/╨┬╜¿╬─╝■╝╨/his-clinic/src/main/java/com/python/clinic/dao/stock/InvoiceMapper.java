package com.python.clinic.dao.stock;

import com.python.clinic.entity.stock.Invoice;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 发票表 Mapper 接口
 * </p>
 *
 * @author hm
 * @since 2020-05-28
 */
public interface InvoiceMapper extends BaseMapper<Invoice> {

    /**
     * 批量插入关联发票
     * @param list
     * @param settlementId
     * @return
     */
    int saveBatch(@Param("list") List<Invoice> list, @Param("settlementId") Integer settlementId);

}
