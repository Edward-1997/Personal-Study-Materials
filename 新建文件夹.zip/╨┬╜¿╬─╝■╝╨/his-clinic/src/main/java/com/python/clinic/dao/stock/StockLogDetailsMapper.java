package com.python.clinic.dao.stock;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.python.clinic.entity.stock.StockLogDetails;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 入库日志详情表 Mapper 接口
 * </p>
 *
 * @author hm
 * @since 2020-05-19
 */
public interface StockLogDetailsMapper extends BaseMapper<StockLogDetails> {

    /**
     * 批量插入库存操作日志详情
     * @param list
     * @param logId
     */
    void saveBatch(@Param("list") List<StockLogDetails> list, @Param("logId") Integer logId);

    /**
     * 根据日志id查询日志操作详情
     * @param logId
     * @return
     */
    List<StockLogDetails> listLogDetails(@Param("logId")Integer logId);

}
