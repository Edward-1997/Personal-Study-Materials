package com.python.clinic.dao.marketing;

import com.python.clinic.entity.marketing.DiscountSetting;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.List;

/**
 * <p>
 * 折扣设置表 Mapper 接口
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-02
 */
public interface DiscountSettingMapper extends BaseMapper<DiscountSetting> {

    /**
     * 获取折扣活动中折扣产品的数量
     * @author tanglong
     * @return java.lang.Integer
     * @since 2020/6/11 10:18
     **/
    Integer getDiscountGoodsCount(Integer discountId);

    /**
     * 获取该折扣活动中折扣产品有冲突数量
     * @author tanglong
     * @return java.lang.Integer
     * @since 2020/6/11 16:35
     **/
    Integer getDiscountConflictCount(Integer discountId);

    List<DiscountSetting> getDiscountConflictList(Integer discountId);
}
