package com.python.clinic.dao.diagnosis;

import com.python.clinic.entity.diagnosis.Index;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 指标项表 Mapper 接口
 * </p>
 *
 * @author hm
 * @since 2020-06-06
 */
public interface IndexMapper extends BaseMapper<Index> {

}
