package com.python.clinic.dao.marketing;

import com.python.clinic.entity.marketing.GiftCoupon;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 优惠赠品表 Mapper 接口
 * </p>
 *
 * @author tnaglong
 * @since 2020-06-05
 */
public interface GiftCouponMapper extends BaseMapper<GiftCoupon> {

}
