package com.python.clinic.service.user.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.python.clinic.dao.user.*;
import com.python.clinic.entity.user.User;
import com.python.clinic.entity.user.UserTags;
import com.python.clinic.entity.user.UserTitle;
import com.python.clinic.entity.user.dto.UserDTO;
import com.python.clinic.service.user.UserService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 * 诊所用户表 服务实现类
 * </p>
 *
 * @author tnaglong
 * @since 2020-05-21
 */
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {

    @Resource
    private UserMapper userMapper;
    @Resource
    private UserInfoMapper userInfoMapper;
    @Resource
    private UserTitleMapper userTitleMapper;
    @Resource
    private UserTagsMapper userTagsMapper;

    @Override
    @Transactional(propagation= Propagation.REQUIRED,isolation= Isolation.DEFAULT,rollbackFor= RuntimeException.class)
    public boolean saveUser(UserDTO userDTO) {
        //1.添加用户
        userDTO.getUser().setStatus(1);
        userMapper.insert(userDTO.getUser());
        //2.添加用户基本信息
        userDTO.getUserInfo().setUserId(userDTO.getUser().getId());
        userInfoMapper.insert(userDTO.getUserInfo());
        //3.添加职称信息
        List<UserTitle> userTitleList = userDTO.getUserTitleList();
        if (userTitleList != null && userTitleList.isEmpty()){
            userTitleMapper.saveBatch(userTitleList,userDTO.getUserInfo().getId());
        }
        //4.添加标签
        List<UserTags> userTagsList = userDTO.getUserTagsList();
        if (userTagsList != null && userTagsList.isEmpty()){
            userTagsMapper.saveBatch(userTagsList,userDTO.getUserInfo().getId());
        }

        return true;
    }

    @Override
    @Transactional(propagation= Propagation.REQUIRED,isolation= Isolation.DEFAULT,rollbackFor= RuntimeException.class)
    public boolean updateUser(UserDTO userDTO) {
        //1.修改用户
        userMapper.updateById(userDTO.getUser());
        //2.修改用户基本信息
        userInfoMapper.updateById(userDTO.getUserInfo());
        //3.先删除所有职称，再添加
        QueryWrapper<UserTitle> userTitleWrapper = new QueryWrapper<>();
        userTitleWrapper.eq("user_info_id",userDTO.getUserInfo().getId());
        userTitleMapper.delete(userTitleWrapper);
        List<UserTitle> userTitleList = userDTO.getUserTitleList();
        if (userTitleList != null && userTitleList.isEmpty()){
            userTitleMapper.saveBatch(userTitleList,userDTO.getUserInfo().getId());
        }
        //4.先删除所有标签，再添加
        QueryWrapper<UserTags> userTagsWrapper = new QueryWrapper<>();
        userTagsWrapper.eq("user_info_id",userDTO.getUserInfo().getId());
        userTagsMapper.delete(userTagsWrapper);
        List<UserTags> userTagsList = userDTO.getUserTagsList();
        if (userTagsList != null && userTagsList.isEmpty()){
            userTagsMapper.saveBatch(userTagsList,userDTO.getUserInfo().getId());
        }

        return true;
    }

}
