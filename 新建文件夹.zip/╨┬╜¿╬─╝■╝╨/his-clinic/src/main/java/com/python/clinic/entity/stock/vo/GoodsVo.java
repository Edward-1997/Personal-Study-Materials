package com.python.clinic.entity.stock.vo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotEmpty;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author hm
 */
@Data
public class GoodsVo {

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "药品通用名称")
    private String medicineCadn;

    @ApiModelProperty(value = "类型，6：中药，7：西药，8：中成药")
    private Integer type;

    @ApiModelProperty(value = "附属类型 0:中药饮片，1:中药颗粒")
    private Integer subType;

    @ApiModelProperty(value = "名称")
    private String name;

    @ApiModelProperty(value = "生产厂家")
    private String manufacturer;

    @ApiModelProperty(value = "剂量")
    private Double dosage;

    @ApiModelProperty(value = "剂量单位")
    private String dosageUnit;

    @ApiModelProperty(value = "药品制剂/物资包装数量")
    private Integer preparation;

    @ApiModelProperty(value = "药品制剂单位/物资最小单位")
    private String preparationUnit;

    @ApiModelProperty(value = "包装单位")
    private String packageUnit;

    @ApiModelProperty(value = "零售价格")
    private BigDecimal sellPrice;

    @ApiModelProperty(value = "规格")
    private String specifications;

    @ApiModelProperty(value = "最近进价")
    private BigDecimal latelyPrice;

    @ApiModelProperty(value = "最近效期")
    private Date latelyExpiryDate;

    @ApiModelProperty(value = "整装库存")
    private Integer packageCount;

    @ApiModelProperty(value = "散装库存")
    private Integer pieceCount;

    @ApiModelProperty(value = "毛利率")
    private Double grossMargin;

    @ApiModelProperty(value = "日销量")
    private Double dailySales;

    @ApiModelProperty(value = "周转天数")
    private Double turnoverDays;

}
