package com.python.clinic.service.user;

import com.python.clinic.entity.user.UserTags;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author hm
 * @since 2020-06-02
 */
public interface UserTagsService extends IService<UserTags> {

}
