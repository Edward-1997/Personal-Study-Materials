package com.python.clinic.service.stock;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.python.clinic.entity.stock.OutOfStock;
import com.baomidou.mybatisplus.extension.service.IService;
import com.python.clinic.exception.BaseException;

/**
 * <p>
 * 出库表 服务类
 * </p>
 *
 * @author hm
 * @since 2020-05-23
 */
public interface OutOfStockService extends IService<OutOfStock> {

    /**
     * 分页带条件查询出库列表
     * @param page
     * @param startTime 开始时间
     * @param endTime   结束时间
     * @param type      类型  0：科室，1：报损，2：退货
     * @param goodsId   商品id
     * @return
     */
    IPage<OutOfStock> selectPage(IPage<OutOfStock> page,String startTime,String endTime,
                                 Integer type,Integer goodsId);


    /**
     * 添加出库
     * @param outOfStock
     * @return
     * @throws BaseException
     */
    boolean saveOutOfStock(OutOfStock outOfStock) throws BaseException;

    /**
     * 查询出库信息
     * @param id 出库id
     * @return
     */
    OutOfStock getOutOfStock(Integer id);
}
