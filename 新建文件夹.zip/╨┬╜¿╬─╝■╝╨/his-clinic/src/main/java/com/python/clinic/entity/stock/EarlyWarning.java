package com.python.clinic.entity.stock;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * <p>
 * 库存预警设置
 * </p>
 *
 * @author hm
 * @since 2020-05-19
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("his_early_warning")
@ApiModel(value="EarlyWarning对象", description="库存预警设置")
public class EarlyWarning extends Model<EarlyWarning> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "库存预警设置，0：系统设置，1：自定义设置")
    private Integer inventoryAlertSetting;

    @ApiModelProperty(value = "药品周转天数")
    private Integer inventoryAlert;

    @ApiModelProperty(value = "开启库存最小值预警，false：关闭，true：开启")
    private Boolean enableMinInventoryAlert;

    @ApiModelProperty(value = "药品库存，小于此数时警报")
    private Integer drugInventory;

    @ApiModelProperty(value = "库存药品单位")
    private String unit;

    @ApiModelProperty(value = "效期预警设置，0：系统设置，1：自定义设置")
    private Integer validityWarningSetting;

    @ApiModelProperty(value = "药品有效期时间")
    private Integer validityWarning;

    @ApiModelProperty(value = "药品id")
    private Integer goodsId;

    public EarlyWarning(Integer inventoryAlert, Integer validityWarning) {
        this.inventoryAlert = inventoryAlert;
        this.validityWarning = validityWarning;
    }

    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
