package com.python.clinic.service.diagnosis.impl;

import com.python.clinic.entity.diagnosis.Index;
import com.python.clinic.dao.diagnosis.IndexMapper;
import com.python.clinic.service.diagnosis.IndexService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 指标项表 服务实现类
 * </p>
 *
 * @author hm
 * @since 2020-06-06
 */
@Service
public class IndexServiceImpl extends ServiceImpl<IndexMapper, Index> implements IndexService {

}
