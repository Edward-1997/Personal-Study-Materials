package com.python.clinic.entity.patient.vo;

import com.python.clinic.entity.patient.Patient;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/5/22 9:53
 **/
@Data
public class MemberCardInfoVo {
    @ApiModelProperty(value = "会员id")
    private Integer id;

    @ApiModelProperty(value = "会员姓名")
    private String name;

    @ApiModelProperty(value = "会员卡id")
    private Integer cardId;

    @ApiModelProperty(value = "会员卡名称")
    private String cardName;

    @ApiModelProperty(value = "卡号/手机号")
    private String phone;

    @ApiModelProperty(value = "性别，0：男，1：女")
    private Integer gender;

    @ApiModelProperty(value = "年龄")
    private Integer age;

    @ApiModelProperty(value = "生日")
    private Date birth;

    @ApiModelProperty(value = "自定义权益")
    private String benefits;

    @ApiModelProperty(value = "诊所名称")
    private String clinicName;

    @ApiModelProperty(value = "当前积分")
    private Integer integral;

    @ApiModelProperty(value = "累计积分")
    private Integer totalIntegral;

    @ApiModelProperty(value = "本金")
    private BigDecimal principal;

    @ApiModelProperty(value = "赠送金额")
    private BigDecimal giftAmount;

    @ApiModelProperty(value = "开卡日期")
    private Date createDate;

    @ApiModelProperty(value = "备注")
    private String remark;

    @ApiModelProperty(value = "患者家庭成员信息")
    private List<Patient> memberShareInfos;

}
