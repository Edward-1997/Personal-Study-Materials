package com.python.clinic.service.stock;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.python.clinic.entity.stock.Inventory;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 盘点表 服务类
 * </p>
 *
 * @author hm
 * @since 2020-05-27
 */
public interface InventoryService extends IService<Inventory> {

    /**
     * 分页带条件查询盘点列表
     * @param page
     * @param startTime 开始时间
     * @param endTime   结束时间
     * @param goodsId   商品id
     * @return
     */
    IPage<Inventory> selectPage(IPage<Inventory> page, String startTime, String endTime, Integer goodsId);

    /**
     * 添加盘点
     * @param inventory
     * @return
     */
    boolean saveInventory(Inventory inventory) throws Exception;

    /**
     * 通过主键id查询盘点单
     * @param id
     * @return
     */
    Inventory getInventoryById(Integer id);

}
