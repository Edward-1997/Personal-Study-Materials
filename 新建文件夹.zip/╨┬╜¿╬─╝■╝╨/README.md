# HIS

#### 介绍
医院信息管理系统

## 一、项目架构

### 项目架构图

![项目架构图](document/images/his架构图.jpg)

### 组织结构图

```lua
HIS
├── HIS-Nacos -- 注册中心[端口:8848]
├── his-gateway-server -- 路由网关[端口：10011]
|    ├── component -- 鉴权相关组件，JWT校验，定期获取公钥
|    ├── config -- 资源服务器配置
|    └── reponse -- 结果实体类
├── his-authorization-server -- 微服务授权中心[端口：8070]
|    ├── controller -- api接口
|    ├── core -- 授权核心，授权服务的配置、定期更新密钥
|    ├── validate -- 校验码管理，提供校验码生成、存储、校验，发送
|    └── reponse -- 结果实体类
├── his-admin-server -- 微服务监控中心
├── his-sentinel-dashboard -- 流量监控控制台[端口：8080]
|     ├── alibaba-sentinel -- 阿里Sentinel控制台（由源码构建无需更改）
|     └── custom -- 监控数据持久化
└──HIS-Grafana -- 流量监控数据展示平台[端口:3000]
```



### 后端技术栈

| 技术                  | 说明                 | 官网文档 |
| :-------------------- | -------------------- | -------- |
| Spring Cloud          | Spring分布式治理方案 |          |
| Spring Cloud Alibaba  | 微服务一站式解决方案 |          |
| Sentinel-dashboard    | 微服务流量监控平台   |          |
| Nacos                 | 注册中心             |          |
| Seata                 | 事务管理             |          |
| Spring Boot           | 容器+MVC框架         |          |
| Spring Boot Admin     | 微服务性能监控       |          |
| JWT                   | 验签、解析JwtToken   |          |
| Swagger2              | 交互式API文档        |          |
| Spring Cloud Security | 安全框架             |          |
| MyBatis               | ORM框架              |          |
| MyBatisGenerator      | 数据层代码生成       |          |
| PageHelper            | MyBatis物理分页插件  |          |
| Druid                 | 数据库连接池         |          |
| Grafana              | 监控数据展示平台      |          |
| InfluxDB              | 时序数据库           |          |
| influxdb-java         | InfluxDB Java客户端  |          |
| Redis                 | 分布式缓存数据库     |          |
| Elasticsearch         | 搜索引擎             |          |
| Maven                 | 项目管理工具         |          |
| Junit                 | 单元测试框架         |          |
| Logback               | 日志框架             |          |
| Java doc              | API帮助文档          |          |
| Docker                | 应用容器引擎         |          |
| Jenkins               | 自动化部署工具       |          |


### 前端技术栈

| 技术       | 版本        | 说明                |
| ---------- | ----------- | ------------------- |
| Vue        | 2.6.10      | 前端框架            |
| Vue-router | 3.0.2       | 前端路由框架        |
| Vuex       | 3.1.0       | vue状态管理组件     |
| Vue-cli    | ————        | Vue脚手架           |
| Element-ui | 2.7.0       | 前端UI框架          |
| Echarts    | 4.2.1       | 数据可视化框架      |
| Uni-app    | ————        | 跨平台前端框架      |
| Mockjs     | 1.0.1-beta3 | 模拟后端数据        |
| Axios      | 0.18.0      | 基于Promise的Http库 |
| Js-cookie  | 2.2.0       | Cookie组件          |
| Jsonlint   | 1.6.3       | Json解析组件        |
| screenfull | 4.2.0       | 全屏组件            |
| Xlsx       | 0.14.1      | Excel表导出组件     |
| Webpack    | ————        | 模板打包器          |

## 二. 项目展示

1.  xxxx
2.  xxxx
3.  xxxx

## 三. 环境搭建

### 开发工具

| 工具            | 版本          | 说明                 |
| --------------- | ------------- | -------------------- |
| IDEA            | 2019.1.1      | 后端开发IDE          |
| Git             | 2.21.0        | 代码托管平台         |
| Google   Chrome | 75.0.3770.100 | 浏览器、前端调试工具 |
| Navicat         | 11.1.13       | 数据库连接工具       |
| ProcessOn       | ——            | 架构图等绘制工具     |
|                 | 2.9.2         | 接口测试工具         |

#### 参与贡献

1.  Fork 本仓库
2.  新建 Feat_xxx 分支
3.  提交代码
4.  新建 Pull Request


#### 码云特技

1.  使用 Readme\_XXX.md 来支持不同的语言，例如 Readme\_en.md, Readme\_zh.md
2.  码云官方博客 [blog.gitee.com](https://blog.gitee.com)
3.  你可以 [https://gitee.com/explore](https://gitee.com/explore) 这个地址来了解码云上的优秀开源项目
4.  [GVP](https://gitee.com/gvp) 全称是码云最有价值开源项目，是码云综合评定出的优秀开源项目
5.  码云官方提供的使用手册 [https://gitee.com/help](https://gitee.com/help)
6.  码云封面人物是一档用来展示码云会员风采的栏目 [https://gitee.com/gitee-stars/](https://gitee.com/gitee-stars/)
