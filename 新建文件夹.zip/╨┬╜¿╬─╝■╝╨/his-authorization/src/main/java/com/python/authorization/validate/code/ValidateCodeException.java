package com.python.authorization.validate.code;

import org.springframework.security.core.AuthenticationException;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/4/29 10:48
 **/
public class ValidateCodeException extends AuthenticationException {
    public ValidateCodeException(String msg) {
        super(msg);
    }
}
