package com.python.authorization.core.component;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/5/10 17:14
 **/
public interface AuthorizationServerConstant {
    //资源微服务获取公钥的默认url
    String DEFAULT_PUBLIC_KEY_URL = "/python/secret";
    //cron表达式，设置更新密钥的时间周期,从0分钟开始每2分钟运行一次
    String DEFAULT_PUBLIC_KEY_GENERATE_CRON = "0 0/3 * * * ?";
    //默认密钥对的名称
    String DEFAULT_KEY_PAIR_NAME = "keyPair";
    //默认登录跳转的url
    String DEFAULT_LOGIN_URL = "/acquire/login";
}
