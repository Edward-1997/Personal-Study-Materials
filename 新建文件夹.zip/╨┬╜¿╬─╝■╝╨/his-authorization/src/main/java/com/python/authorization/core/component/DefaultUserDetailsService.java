package com.python.authorization.core.component;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Collection;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/5/5 19:39
 **/
public class DefaultUserDetailsService implements UserDetailsService {

    private PasswordEncoder passwordEncoder;

    //private UserMapper userMapper;去数据库里查询用户名密码

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        String password = "123456";
        String encode = passwordEncoder.encode(password);

        return new User(username, encode,
                AuthorityUtils.commaSeparatedStringToAuthorityList("admin,ROLE_USER"));
    }

    /**
     * 继承SpringSecurity提供的默认User类，通过重写其中的{@link UserDetails#isAccountNonExpired()}，
     * {@link UserDetails#isAccountNonLocked()}，{@link UserDetails#isCredentialsNonExpired()},
     * {@link UserDetails#isEnabled()}，来自定义用户的属性。
     *
     * @author tanglong
     * @version 1.0
     * @see User
     * @since 2020/5/5 21:39
     **/
    private class DefaultUserDetails implements UserDetails {

        @Override
        public Collection<? extends GrantedAuthority> getAuthorities() {
            return null;
        }

        @Override
        public String getPassword() {
            return null;
        }

        @Override
        public String getUsername() {
            return null;
        }

        @Override
        public boolean isAccountNonExpired() {
            return false;
        }

        @Override
        public boolean isAccountNonLocked() {
            return false;
        }

        @Override
        public boolean isCredentialsNonExpired() {
            return false;
        }

        @Override
        public boolean isEnabled() {
            return false;
        }
    }

    public PasswordEncoder getPasswordEncoder() {
        return passwordEncoder;
    }

    public void setPasswordEncoder(PasswordEncoder passwordEncoder) {
        this.passwordEncoder = passwordEncoder;
    }
}
