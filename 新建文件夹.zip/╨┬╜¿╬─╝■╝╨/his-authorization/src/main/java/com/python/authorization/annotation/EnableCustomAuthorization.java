package com.python.authorization.annotation;

import com.python.authorization.core.config.AuthorizationServerBeanConfig;
import com.python.authorization.core.config.AuthorizationServerConfig;
import com.python.authorization.core.config.DefaultCustomSecurityConfig;
import com.python.authorization.core.config.ResourceServerConfig;
import org.springframework.context.annotation.Import;
import org.springframework.security.oauth2.config.annotation.web.configuration.AuthorizationServerEndpointsConfiguration;
import org.springframework.security.oauth2.config.annotation.web.configuration.AuthorizationServerSecurityConfiguration;

import java.lang.annotation.*;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/5/20 10:07
 **/
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Import({
        AuthorizationServerBeanConfig.class,
        AuthorizationServerConfig.class,
        DefaultCustomSecurityConfig.class,
        ResourceServerConfig.class
})
public @interface EnableCustomAuthorization {
}
