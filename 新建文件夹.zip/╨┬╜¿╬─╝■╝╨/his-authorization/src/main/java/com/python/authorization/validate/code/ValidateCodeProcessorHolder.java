package com.python.authorization.validate.code;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import java.util.Map;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/4/30 9:24
 **/
@Component
public class ValidateCodeProcessorHolder {

    /**
     * 依赖搜索
     * Spring启动时，会查找容器中所有的ValidateCodeProcessor接口的实现，并把Bean的名字作为key，放到map中
     */
    @Autowired
    private Map<String, ValidateCodeProcessor> validateCodeProcessors;

    /**
     * @param type 校验码的类型
     * @return
     */
    public ValidateCodeProcessor findValidateCodeProcessor(String type) {
        String name = type.toLowerCase() + ValidateCodeProcessor.class.getSimpleName();
        ValidateCodeProcessor processor = validateCodeProcessors.get(name);

        Assert.notNull(processor, "验证码处理器" + name + "不存在");
        return processor;
    }
}
