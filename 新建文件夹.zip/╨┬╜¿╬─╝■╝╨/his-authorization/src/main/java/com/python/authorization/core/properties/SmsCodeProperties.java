package com.python.authorization.core.properties;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/4/30 14:55
 **/
public class SmsCodeProperties {
    //默认验证码长度
    private int length = 6;
    //默认过期时间
    private int expire = 10 * 60;
    //要使用验证码的url，多个url用逗号隔开，ant pattern
    private String url = "/oauth/token";

    public int getLength() {
        return length;
    }

    public void setLength(int lenght) {
        this.length = lenght;
    }

    public int getExpire() {
        return expire;
    }

    public void setExpire(int expire) {
        this.expire = expire;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
