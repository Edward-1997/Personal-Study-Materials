package com.python.authorization.validate.code;

import com.python.authorization.core.properties.SecurityProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import org.springframework.web.context.request.ServletWebRequest;

import java.util.concurrent.TimeUnit;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/5/6 16:43
 **/
@Component
public class RedisValidateCodeRepository implements ValidateCodeRepository {

    @Autowired
    private RedisTemplate redisTemplate;
    @Autowired
    private SecurityProperties securityProperties;

    private static final String CODE_KEY = "VALIDATE_CODE_KEY";

    @Override
    public void save(ServletWebRequest webRequest, ValidateCode code) {
        ValueOperations ops = redisTemplate.opsForValue();
        String deviceId = "123456";//这个由前端传过来

        Assert.notNull(deviceId, "用户设备Id不能为空");

        ops.set(CODE_KEY + ":" + code.getCodeType() + ":" + deviceId, code.getCode(),
                securityProperties.getCode().getSms().getExpire(), TimeUnit.SECONDS);
    }

    @Override
    public ValidateCode load(ServletWebRequest webRequest, String codeType) {
        String deviceId = "123456";//这个由前端传过来
        boolean hasKey = redisTemplate.hasKey(CODE_KEY + ":" + codeType + ":" + deviceId);
        if (hasKey) {
            String code = (String) redisTemplate.opsForValue().get(CODE_KEY + ":" + codeType + ":" + deviceId);
            return new ValidateCode(code, -1);
        }

        return null;
    }

    @Override
    public void remove(ServletWebRequest webRequest, ValidateCode code) {
        String deviceId = "123456";//这个由前端传过来
        boolean hasKey = redisTemplate.hasKey(CODE_KEY + ":" + code.getCodeType() + ":" + deviceId);
        if (hasKey) {
            redisTemplate.delete(CODE_KEY + ":" + code.getCodeType() + ":" + deviceId);
        }
    }
}
