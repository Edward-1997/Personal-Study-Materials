package com.python.authorization.core.properties;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/5/7 19:58
 **/
public class JwtTokenProperties {
    //token默认的有效时间默认是1天
    private int expire = 24 * 60 * 60;
    //token的刷新时间
    private int refresh = 30 * 24 * 60 * 60;
    //密钥的长度,默认是2048
    private int keySize = 1024;
    //默认使用非对称加密，使用RSA算法创建私钥和公钥，保存在本地
    private String pubKeyPath = "D:\\IDEA\\python-enterprise\\HIS\\his-authorization-server\\key\\python_his_rsa.pub";
    private String priKeyPath = "D:\\IDEA\\python-enterprise\\HIS\\his-authorization-server\\key\\python_his_rsa.pri";

    public int getKeySize() {
        return keySize;
    }

    public void setKeySize(int keySize) {
        this.keySize = keySize;
    }

    public int getExpire() {
        return expire;
    }

    public void setExpire(int expire) {
        this.expire = expire;
    }

    public int getRefresh() {
        return refresh;
    }

    public void setRefresh(int refresh) {
        this.refresh = refresh;
    }

    public String getPubKeyPath() {
        return pubKeyPath;
    }

    public void setPubKeyPath(String pubKeyPath) {
        this.pubKeyPath = pubKeyPath;
    }

    public String getPriKeyPath() {
        return priKeyPath;
    }

    public void setPriKeyPath(String priKeyPath) {
        this.priKeyPath = priKeyPath;
    }

}
