package com.python.authorization.core.component;

import com.python.authorization.core.properties.SecurityProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.security.oauth2.provider.token.store.JwtAccessTokenConverter;
import org.springframework.stereotype.Component;

import java.security.KeyPair;


/**
 * 定时任务调度类，通过更新容器内的keyPair {@link KeyPair},用于定期更新加密JwtToken的RSA非对称加密密钥
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/5/9 16:34
 **/
@Component
public class ScheduledTask implements ApplicationContextAware {
    private Logger logger = LoggerFactory.getLogger(ScheduledTask.class);
    private ApplicationContext ctx;
    @Autowired
    private RSAUtils rsaUtils;
    @Autowired
    private SecurityProperties securityProperties;

    /**
     * 向spring的ioc容器中注册bean，
     *
     * @param target   要注册bean的目标类实例对象
     * @param beanName 要注册bean的名字
     * @return void
     * @throws
     * @author tanglong
     * @see
     * @since 2020/5/10 16:01
     **/
    private <T> void registerBean(T target, String beanName) {
        if (!ctx.containsBean(beanName)) {
            BeanDefinitionBuilder beanDefinitionBuilder = BeanDefinitionBuilder.genericBeanDefinition(target.getClass());
            DefaultListableBeanFactory autowireCapableBeanFactory = (DefaultListableBeanFactory) ctx.getAutowireCapableBeanFactory();
            autowireCapableBeanFactory.registerBeanDefinition(beanName, beanDefinitionBuilder.getBeanDefinition());
            autowireCapableBeanFactory.registerSingleton(beanName, target);
        }
    }

    /**
     * 向spring的ioc容器中注册bean，
     *
     * @param beanName
     * @return void
     * @throws
     * @author tanglong
     * @see
     * @since 2020/5/10 16:01
     **/
    private void removeBean(String beanName) {
        if (ctx.containsBean(beanName)) {
            //通过beanFactory中的方法，移除spring容器中beanName的beanDefinition
            DefaultListableBeanFactory autowireCapableBeanFactory = (DefaultListableBeanFactory) ctx.getAutowireCapableBeanFactory();
            autowireCapableBeanFactory.removeBeanDefinition(beanName);
            //销毁IOC容器中的单例bean
            autowireCapableBeanFactory.destroySingleton(beanName);
        }
    }

    /**
     * 定时调度任务，设定在设定时间内，周期的更新密钥的内容，密钥通过{@link RSAUtils}工具类随机生成
     * 通过{@link DefaultListableBeanFactory} beanFactory，将ioc容器中的KeyPair定期更新，达到定
     * 时更新密钥的效果
     * cron表达式，设置更新密钥的时间周期,从0分钟开始每2分钟运行一次
     **/
    @Scheduled(cron = AuthorizationServerConstant.DEFAULT_PUBLIC_KEY_GENERATE_CRON)
    public void task() {

        removeBean(AuthorizationServerConstant.DEFAULT_KEY_PAIR_NAME);
        KeyPair keyPair = null;
        try {
            keyPair = rsaUtils.generateKey(securityProperties.getJwt().getPubKeyPath(),
                    securityProperties.getJwt().getPriKeyPath(), securityProperties.getJwt().getKeySize());
            JwtAccessTokenConverter tokenConverter = (JwtAccessTokenConverter) ctx.getBean("tokenConverter");
            tokenConverter.setKeyPair(keyPair);
        } catch (Exception e) {
            e.printStackTrace();
        }

        registerBean(keyPair, AuthorizationServerConstant.DEFAULT_KEY_PAIR_NAME);
        logger.info("向容器中注册了bean：" + ctx.getBean(AuthorizationServerConstant.DEFAULT_KEY_PAIR_NAME));
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.ctx = applicationContext;
    }
}
