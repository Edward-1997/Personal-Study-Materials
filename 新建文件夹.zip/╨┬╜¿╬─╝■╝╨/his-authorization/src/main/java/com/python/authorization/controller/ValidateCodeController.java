package com.python.authorization.controller;

import com.python.authorization.validate.code.ValidateCodeProcessor;
import com.python.authorization.validate.code.ValidateCodeProcessorHolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.ServletWebRequest;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/4/29 14:40
 **/
@RestController
public class ValidateCodeController {
    @Autowired
    private ValidateCodeProcessorHolder holder;

    /**
     * 创建验证码，根据验证码类型不同，调用不同的 {@link ValidateCodeProcessor}接口实现
     *
     * @param response
     * @param request
     * @param type
     * @throws Exception
     */
    @GetMapping("/code/{type}")
    public void createCode(HttpServletRequest request, HttpServletResponse response, @PathVariable String type)
            throws Exception {
        holder.findValidateCodeProcessor(type).create(new ServletWebRequest(request, response));
    }
}
