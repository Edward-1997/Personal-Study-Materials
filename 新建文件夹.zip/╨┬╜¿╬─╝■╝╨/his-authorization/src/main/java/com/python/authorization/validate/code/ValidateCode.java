package com.python.authorization.validate.code;

import java.time.LocalDateTime;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/4/29 15:52
 **/
public class ValidateCode {
    //校验码
    private String code;
    //过期时间点
    private LocalDateTime expireTime;

    private String codeType = "sms";

    public ValidateCode(String code, long expire) {
        this.code = code;
        this.expireTime = LocalDateTime.now().plusSeconds(expire);
    }

    public ValidateCode(String code, LocalDateTime expire) {
        this.code = code;
        this.expireTime = expire;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public LocalDateTime getExpireTime() {
        return expireTime;
    }

    public void setExpireTime(LocalDateTime expireTime) {
        this.expireTime = expireTime;
    }

    public String getCodeType() {
        return codeType;
    }

    public void setCodeType(String codeType) {
        this.codeType = codeType;
    }

    public boolean isExpire() {
        //判断当前时间是否在expireTime后面
        return LocalDateTime.now().isAfter(expireTime);
    }

    @Override
    public String toString() {
        return "ValidateCode{" +
                "code='" + code + '\'' +
                ", expireTime=" + expireTime +
                ", codeType='" + codeType + '\'' +
                '}';
    }
}
