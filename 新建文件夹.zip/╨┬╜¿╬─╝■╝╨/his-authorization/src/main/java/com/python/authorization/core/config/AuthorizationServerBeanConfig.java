package com.python.authorization.core.config;

import com.python.authorization.core.component.DefaultUserDetailsService;
import com.python.authorization.core.component.TokenConverter;
import com.python.authorization.core.properties.SecurityProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.provider.ClientDetailsService;
import org.springframework.security.oauth2.provider.token.AuthorizationServerTokenServices;
import org.springframework.security.oauth2.provider.token.DefaultTokenServices;
import org.springframework.security.oauth2.provider.token.TokenEnhancerChain;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.security.oauth2.provider.token.store.JwtTokenStore;
import org.springframework.security.web.DefaultRedirectStrategy;
import org.springframework.security.web.RedirectStrategy;
import org.springframework.util.AntPathMatcher;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

import java.util.Arrays;

/**
 * bean配置类，主要配置了认证、授权相关的bean的信息
 *
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/5/7 18:44
 **/
@Configuration
@ComponentScan(value = "com.python.authorization")
public class AuthorizationServerBeanConfig {
    @Autowired
    private ClientDetailsService clientDetailsService;
    @Autowired
    private SecurityProperties securityProperties;
    @Autowired
    private TokenConverter tokenConverter;

    /**
     * 配置token的存储方法,把用户信息都存储在token当中
     **/
    @Bean
    public TokenStore tokenStore() {
        return new JwtTokenStore(tokenConverter);
    }

    @Bean
    public AntPathMatcher matcher() {
        return new AntPathMatcher();
    }

    @Bean
    public RedirectStrategy redirectStrategy() {
        return new DefaultRedirectStrategy();
    }


    //配置token管理服务
    @Bean
    public AuthorizationServerTokenServices authorizationServerTokenServices() {
        DefaultTokenServices defaultTokenServices = new DefaultTokenServices();
        defaultTokenServices.setClientDetailsService(clientDetailsService);
        defaultTokenServices.setSupportRefreshToken(true);

        //配置token的存储方法
        defaultTokenServices.setTokenStore(tokenStore());
        defaultTokenServices.setAccessTokenValiditySeconds(securityProperties.getJwt().getExpire());
        defaultTokenServices.setRefreshTokenValiditySeconds(securityProperties.getJwt().getRefresh());

        //配置token, 把内置token转换为JwtToken
        TokenEnhancerChain tokenEnhancerChain = new TokenEnhancerChain();
        tokenEnhancerChain.setTokenEnhancers(Arrays.asList(tokenConverter));
        defaultTokenServices.setTokenEnhancer(tokenEnhancerChain);
        return defaultTokenServices;
    }

    //配置spring内置的密码编解码器
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    //配置用户信息服务，里面封装了用户的登录信息
    @Bean
    public UserDetailsService userDetailsService() {
        DefaultUserDetailsService userDetailsService = new DefaultUserDetailsService();
        userDetailsService.setPasswordEncoder(passwordEncoder());
        return userDetailsService;
    }

    //允许跨域调用的过滤器
    @Bean
    public CorsFilter corsFilter() {
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        CorsConfiguration config = new CorsConfiguration();
        config.addAllowedOrigin("*");
        config.setAllowCredentials(true);
        config.addAllowedHeader("*");
        config.addAllowedMethod("*");
        source.registerCorsConfiguration("/**", config);
        FilterRegistrationBean bean = new FilterRegistrationBean(new CorsFilter(source));
        bean.setOrder(0);
        return new CorsFilter(source);
    }


}
