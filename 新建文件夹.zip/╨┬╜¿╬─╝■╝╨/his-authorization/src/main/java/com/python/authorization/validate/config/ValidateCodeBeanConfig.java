package com.python.authorization.validate.config;

import com.python.authorization.core.properties.SecurityProperties;
import com.python.authorization.validate.code.image.ImageValidateCodeGenerator;
import com.python.authorization.validate.code.image.ImageValidateCodeProcessor;
import com.python.authorization.validate.code.sms.DefaultSmsValidateCodeSend;
import com.python.authorization.validate.code.sms.SmsValidateCodeGenerator;
import com.python.authorization.validate.code.sms.SmsValidateCodeProcessor;
import com.python.authorization.validate.code.sms.SmsValidateCodeSender;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/4/29 14:49
 **/
@Configuration
public class ValidateCodeBeanConfig {
    @Autowired
    private SecurityProperties securityProperties;

    @Bean
    @ConditionalOnMissingBean(ImageValidateCodeGenerator.class)
    public ImageValidateCodeGenerator imageValidateCodeGenerator() {
        ImageValidateCodeGenerator imageCodeGenerator = new ImageValidateCodeGenerator();
        imageCodeGenerator.setSecurityProperties(securityProperties);
        return imageCodeGenerator;
    }

    @Bean
    @ConditionalOnMissingBean(SmsValidateCodeGenerator.class)
    public SmsValidateCodeGenerator smsValidateCodeGenerator() {
        return new SmsValidateCodeGenerator();
    }

    @Bean
    @ConditionalOnMissingBean(SmsValidateCodeSender.class)
    public SmsValidateCodeSender defaultSmsValidateCodeSend() {
        return new DefaultSmsValidateCodeSend();
    }

    @Bean
    public ImageValidateCodeProcessor imageValidateCodeProcessor() {
        return new ImageValidateCodeProcessor();
    }

    @Bean
    public SmsValidateCodeProcessor smsValidateCodeProcessor() {
        SmsValidateCodeProcessor validateCodeProcessor = new SmsValidateCodeProcessor();
        validateCodeProcessor.setSmsCodeSender(defaultSmsValidateCodeSend());
        return validateCodeProcessor;
    }

}
