package com.python.authorization.validate.code;


/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/5/2 10:31
 **/
public interface ValidateCodeGenerator {
    //生成图片校验码
    ValidateCode generate();
}
