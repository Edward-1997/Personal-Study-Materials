package com.python.authorization.validate.code.image;


import com.python.authorization.validate.code.ValidateCode;

import java.awt.image.BufferedImage;
import java.time.LocalDateTime;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/4/29 9:47
 **/
public class ImageValidateCode extends ValidateCode {
    private BufferedImage image;

    public ImageValidateCode(BufferedImage image, String code, long expire) {
        super(code, expire);
        this.image = image;
        setCodeType("image");
    }

    public ImageValidateCode(BufferedImage image, String code, LocalDateTime expire) {
        super(code, expire);
        this.image = image;
    }

    public BufferedImage getImage() {
        return image;
    }

    public void setImage(BufferedImage image) {
        this.image = image;
    }

}
