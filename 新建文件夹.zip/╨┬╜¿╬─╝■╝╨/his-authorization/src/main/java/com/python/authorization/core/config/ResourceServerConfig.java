package com.python.authorization.core.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;


/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/5/20 10:31
 **/
@Configuration
@EnableResourceServer
public class ResourceServerConfig{

}
