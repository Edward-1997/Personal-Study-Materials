package com.python.authorization.validate.code;

import org.springframework.web.context.request.ServletWebRequest;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/5/3 10:56
 **/
public interface ValidateCodeProcessor {

    /**
     * 创建校验码
     *
     * @param request
     * @throws Exception
     */
    void create(ServletWebRequest request) throws Exception;

    /**
     * 校验验证码
     *
     * @param servletWebRequest
     * @throws Exception
     */
    void validate(ServletWebRequest servletWebRequest) throws ValidateCodeException;

}
