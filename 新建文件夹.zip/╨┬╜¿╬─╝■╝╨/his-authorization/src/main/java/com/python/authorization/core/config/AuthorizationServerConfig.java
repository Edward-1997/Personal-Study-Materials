package com.python.authorization.core.config;

import com.python.authorization.core.properties.SecurityProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.config.annotation.configurers.ClientDetailsServiceConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configuration.AuthorizationServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableAuthorizationServer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerEndpointsConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.token.AuthorizationServerTokenServices;

/**
 * 认证服务器配置
 *
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/5/7 17:06
 **/
@Configuration
@EnableAuthorizationServer
@ComponentScan
public class AuthorizationServerConfig extends AuthorizationServerConfigurerAdapter {
    @Autowired
    private PasswordEncoder passwordEncoder;
    //密码模式需要配置认证管理器
    @Autowired
    private AuthenticationManager authenticationManager;
    @Autowired
    private AuthorizationServerTokenServices authorizationServerTokenServices;
    @Autowired
    private SecurityProperties securityProperties;

    //配置客户端
    @Override
    public void configure(ClientDetailsServiceConfigurer clients) throws Exception {
        clients.inMemory()
                //client的id和密码
                .withClient(securityProperties.getClient().getClient_id())
                .secret(passwordEncoder.encode(securityProperties.getClient().getClient_secret()))
                //给client一个resourceIds,这个在client的配置里要用的
                .resourceIds(securityProperties.getClient().getResourceIds())
                //password密码模式,直接拿用户的账号密码授权
                .authorizedGrantTypes(securityProperties.getClient().getGrantType())
                //授权的范围,每个resource会设置自己的范围.
                .scopes(securityProperties.getClient().getScopes())
                //这个是设置要不要弹出确认授权页面的.
                .autoApprove(false);
    }

    //把上面的各个组件组合在一起
    @Override
    public void configure(AuthorizationServerEndpointsConfigurer endpoints) throws Exception {
        endpoints.authenticationManager(authenticationManager)//认证管理器
                .tokenServices(authorizationServerTokenServices)//token管理
                .allowedTokenEndpointRequestMethods(HttpMethod.POST);
    }

    //配置哪些接口可以被访问
    @Override
    public void configure(AuthorizationServerSecurityConfigurer security) throws Exception {
        security.tokenKeyAccess("permitAll()")//  /oauth/token_key公开
                .checkTokenAccess("permitAll()")//  /oauth/check_token公开
                .allowFormAuthenticationForClients();//允许表单认证
    }


}
