package com.python.authorization.core.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/4/28 7:50
 **/
@ConfigurationProperties(prefix = "com.python.security")
public class SecurityProperties {
    //默认不用鉴权的url表
    private String[] excluded = {
            "/auth/**", "/code/**",
            "/python/secret", "/validate/failure",
            "/register"};
    //校验码配置类
    private ValidateCodeProperties code = new ValidateCodeProperties();
    //配置JwtToken中的相关属性
    private JwtTokenProperties jwt = new JwtTokenProperties();
    //配置客户端相关属性
    private ClientDetailsProperties client = new ClientDetailsProperties();

    public String[] getExcluded() {
        return excluded;
    }

    public void setExcluded(String[] excluded) {
        this.excluded = excluded;
    }

    public ValidateCodeProperties getCode() {
        return code;
    }

    public void setCode(ValidateCodeProperties code) {
        this.code = code;
    }

    public JwtTokenProperties getJwt() {
        return jwt;
    }

    public void setJwt(JwtTokenProperties jwt) {
        this.jwt = jwt;
    }

    public ClientDetailsProperties getClient() {
        return client;
    }

    public void setClient(ClientDetailsProperties client) {
        this.client = client;
    }
}
