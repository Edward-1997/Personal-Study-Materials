package com.python.authorization.core.properties;

/**
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/5/7 20:11
 **/
public class ClientDetailsProperties {
    //客户端id
    private String client_id = "DEFAULT_PYTHON_HIS_CLIENT";
    //客户端secret
    private String client_secret = "DEFAULT_PYTHON_HIS_SECRET_KEY";
    //resourceId，配置可以访问微服务资源的ID
    private String[] resourceIds = {
            "resource"
    };
    //配置授权认证模式，这里默认是password
    private String[] grantType = {"password"};
    //配置资源允许的访问范围，默认是all
    private String[] scopes = {"all"};

    public String getClient_id() {
        return client_id;
    }

    public void setClient_id(String client_id) {
        this.client_id = client_id;
    }

    public String getClient_secret() {
        return client_secret;
    }

    public void setClient_secret(String client_secret) {
        this.client_secret = client_secret;
    }

    public String[] getResourceIds() {
        return resourceIds;
    }

    public void setResourceIds(String[] resourceIds) {
        this.resourceIds = resourceIds;
    }

    public String[] getGrantType() {
        return grantType;
    }

    public void setGrantType(String[] grantType) {
        this.grantType = grantType;
    }

    public String[] getScopes() {
        return scopes;
    }

    public void setScopes(String[] scopes) {
        this.scopes = scopes;
    }
}
