package com.python.authorization.core.component;

import org.springframework.security.crypto.codec.Base64;
import org.springframework.security.jwt.crypto.sign.RsaSigner;
import org.springframework.security.jwt.crypto.sign.RsaVerifier;
import org.springframework.security.oauth2.provider.token.store.JwtAccessTokenConverter;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import java.security.KeyPair;
import java.security.PrivateKey;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;

/**
 * 配置把普通token转换成JwtToken，使用非对称加密token,resource服务会用这个秘钥校验token
 *
 * @author tanglong
 * @version 1.0
 * @see
 * @since 2020/5/9 17:13
 **/
@Component
public class TokenConverter extends JwtAccessTokenConverter {

    @Override
    public void setKeyPair(KeyPair keyPair) {
        PrivateKey privateKey = keyPair.getPrivate();
        Assert.state(privateKey instanceof RSAPrivateKey, "KeyPair must be an RSA ");

        super.setSigner(new RsaSigner((RSAPrivateKey) privateKey));
        RSAPublicKey publicKey = (RSAPublicKey) keyPair.getPublic();

        super.setVerifier(new RsaVerifier(publicKey));
        super.setVerifierKey("-----BEGIN PUBLIC KEY-----\n" + new String(Base64.encode(publicKey.getEncoded()))
                + "\n-----END PUBLIC KEY-----");
    }
}
